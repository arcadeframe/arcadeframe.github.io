"""Abre o Multi Estúdio numa janela própria (ou no navegador, se faltar o pywebview)."""
import os
import sys
import threading
import time
import webbrowser
from http.server import ThreadingHTTPServer
from pathlib import Path

if sys.platform.startswith("win"):
    # aberto pelo atalho (pythonw, sem janela preta): o que o app escreve vai para app.log
    if sys.stdout is None or sys.stderr is None:
        try:
            _log = open(Path(__file__).resolve().parent.parent / "app.log", "a", encoding="utf-8", buffering=1)
            sys.stdout = sys.stderr = _log
        except Exception:
            pass
    # ffmpeg, uv e outros programas não abrem janela preta a cada uso
    import subprocess
    _Popen_original = subprocess.Popen.__init__

    def _sem_janela(self, *a, **kw):
        if not kw.get("creationflags"):
            kw["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)
        _Popen_original(self, *a, **kw)
    subprocess.Popen.__init__ = _sem_janela

sys.path.insert(0, str(Path(__file__).resolve().parent))
import servidor_app as srv  # noqa: E402

PORTA = int(os.environ.get("MULTI_PORTA") or 8790)   # 8765 é do Decupa (plugin do Premiere)
URL = f"http://127.0.0.1:{PORTA}/"


def ja_aberto():
    """True só se quem responde na porta é o próprio Multi Estúdio."""
    import json
    import urllib.request
    try:
        with urllib.request.urlopen(URL + "api/status", timeout=2) as r:
            return "projetos" in json.loads(r.read())
    except Exception:
        return False


def blindar_saida():
    """Ao fechar o app no meio de um trabalho (separação, voz), o macOS mostrava "python fechou inesperadamente".
    Encerra o processo direto, sem rodar os destrutores do torch enquanto outra tarefa ainda usa ele."""
    try:
        import ctypes
        import torch  # noqa: F401  (carrega antes, para o nosso encerramento rodar primeiro)
        libc = ctypes.CDLL(None)
        # registra o _exit da própria libc (sem passar pelo Python, que já pode estar desligado nessa hora)
        libc.atexit.argtypes = [ctypes.c_void_p]
        libc.atexit(ctypes.cast(libc._exit, ctypes.c_void_p))
    except Exception:
        pass


def menu_do_botao_direito():
    """O pywebview apaga o menu do botão direito inteiro (só sobrava "Preenchimento automático").
    Aqui ele volta com Colar, Copiar, Recortar etc.; só sai o que é de programador (Inspecionar, Recarregar)."""
    try:
        from webview.platforms import cocoa

        def willOpenMenu_withEvent_(self, menu, event):
            for item in list(menu.itemArray()):
                ident = str(item.identifier() or "")
                if "Inspect" in ident or "Reload" in ident or "Back" in ident or "Forward" in ident:
                    menu.removeItem_(item)
        cocoa.BrowserView.WebKitHost.willOpenMenu_withEvent_ = willOpenMenu_withEvent_
    except Exception as e:
        print("menu do botão direito:", e, flush=True)


def subir_servidor():
    srv.PROJETOS.mkdir(exist_ok=True)
    srv.carregar_fila()
    servidor = ThreadingHTTPServer(("127.0.0.1", PORTA), srv.Manipulador)
    threading.Thread(target=servidor.serve_forever, daemon=True).start()


def encerrar_ajudantes():
    """Desliga a voz rápida e a dublagem ao vivo antes de sair."""
    try:
        sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "kit"))
        import zonos
        zonos.desligar()
    except Exception:
        pass
    try:
        p = srv._AOVIVO.get("proc")
        if p and p.poll() is None:
            p.terminate()
    except Exception:
        pass


def ocupado():
    try:
        if any(x.get("estado") in ("rodando", "baixando", "esperando") for x in srv.FILA):
            return True
        if any(t.get("estado") == "rodando" for t in srv.TRABALHOS.values()):
            return True
        p = srv._AOVIVO.get("proc")           # dublagem ao vivo em uso (ela sai sozinha depois de 15 min parada)
        return bool(p and p.poll() is None)
    except Exception:
        return False


def processo_vivo(pid):
    try:
        os.kill(pid, 0)
        return True
    except Exception:
        return False


_J = {"visivel": True, "dono": 0, "janela": None}


def _no_dock(mostrar):
    """Liga e desliga o ícone no Dock (no modo escondido o app fica invisível)."""
    try:
        import AppKit
        from PyObjCTools import AppHelper

        def f():
            app = AppKit.NSApplication.sharedApplication()
            app.setActivationPolicy_(AppKit.NSApplicationActivationPolicyRegular if mostrar
                                     else AppKit.NSApplicationActivationPolicyAccessory)
            if mostrar:
                app.activateIgnoringOtherApps_(True)
        AppHelper.callAfter(f)
    except Exception as e:
        print("Dock:", e, flush=True)


def mostrar_janela():
    _J["visivel"] = True
    _no_dock(True)
    try:
        _J["janela"].show()
    except Exception as e:
        print("mostrar a janela:", e, flush=True)


def esconder_janela():
    _J["visivel"] = False
    try:
        _J["janela"].hide()
    except Exception as e:
        print("esconder a janela:", e, flush=True)
    _no_dock(False)


def abrir_de_novo_mostra_a_janela():
    """App escondido (aberto pela extensão): quando você abre o Multi Estúdio de novo, a janela aparece."""
    try:
        from webview.platforms import cocoa

        def applicationShouldHandleReopen_hasVisibleWindows_(self, app, visiveis):
            mostrar_janela()
            return True
        cocoa.BrowserView.AppDelegate.applicationShouldHandleReopen_hasVisibleWindows_ = applicationShouldHandleReopen_hasVisibleWindows_
    except Exception as e:
        print("reabrir:", e, flush=True)


def vigiar_dono():
    """Aberto pela extensão: sai sozinho quando o Chrome fecha, a janela está escondida e não há trabalho rodando."""
    while True:
        time.sleep(5)
        if _J["dono"] and not _J["visivel"] and not processo_vivo(_J["dono"]) and not ocupado():
            encerrar_ajudantes()
            os._exit(0)


def vigiar_servidor_de_fora():
    """A janela abriu usando o servidor do modo escondido: se ele sair (Chrome fechou), a janela assume."""
    while True:
        time.sleep(3)
        if not ja_aberto():
            try:
                subir_servidor()
            except Exception as e:
                print("assumir o servidor:", e, flush=True)
            return


def main():
    try:
        import ponte_chrome
        if PORTA == 8790:           # a versão de teste (outra porta) não mexe na ponte da extensão
            ponte_chrome.instalar(os.environ.get("MULTI_APP") or Path(__file__).resolve().parent.parent / "Multi Estúdio.app")
    except Exception as e:
        print("ponte com o Chrome:", e, flush=True)
    escondido = "--sem-janela" in sys.argv
    if escondido and "--dono" in sys.argv:
        try:
            _J["dono"] = int(sys.argv[sys.argv.index("--dono") + 1])
        except Exception:
            _J["dono"] = 0
    if not ja_aberto():
        subir_servidor()
    else:
        threading.Thread(target=vigiar_servidor_de_fora, daemon=True).start()
    try:
        import webview
    except Exception:
        webbrowser.open(URL)
        while True:
            time.sleep(3600)
    blindar_saida()
    janela = webview.create_window("Multi Estúdio", URL, width=1320, height=860, min_size=(980, 680),
                                   background_color="#0E0F11", hidden=escondido)
    _J["janela"] = janela
    _J["visivel"] = not escondido
    abrir_de_novo_mostra_a_janela()

    if escondido:
        threading.Thread(target=vigiar_dono, daemon=True).start()
    def sair():
        encerrar_ajudantes()
        os._exit(0)
    janela.events.closed += sair
    menu_do_botao_direito()
    webview.start((lambda: _no_dock(False)) if escondido else None)
    sair()


if __name__ == "__main__":
    main()
