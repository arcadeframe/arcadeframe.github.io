"""Ponte com a extensão do Chrome: deixa a extensão abrir o Multi Estúdio escondido quando precisa dele.

O Chrome só conversa com um programa do computador por um "host" registrado numa pasta dele.
O app registra esse host sozinho toda vez que abre (nada de Terminal). O host fica fora de Documentos,
para o Chrome não precisar de permissão de pasta, e abre o app pelo próprio macOS (comando open).
"""
import json
import os
import stat
import sys
from pathlib import Path

NOME = "br.com.multiestudio.host"
try:
    from guarda import ID_EXTENSAO                   # um lugar só para o ID (kit/guarda.py)
except Exception:
    ID_EXTENSAO = "eghenmidbnmlmghehpnbipbdoecgcpkp"
APOIO = Path.home() / "Library" / "Application Support" / "MultiEstudio"
PASTAS_CHROME = [Path.home() / "Library" / "Application Support" / n / "NativeMessagingHosts"
                 for n in ("Google/Chrome", "Chromium", "BraveSoftware/Brave-Browser", "Microsoft Edge")]

HOST = r'''# Host da extensão Multi Estúdio (gerado pelo app; não edite).
import json, os, struct, subprocess, sys, time, urllib.request
APP = %(app)r
URL = "http://127.0.0.1:8790/api/status"

def vivo():
    try:
        with urllib.request.urlopen(URL, timeout=1.5) as r:
            return "projetos" in json.loads(r.read())
    except Exception:
        return False

def ler():
    b = sys.stdin.buffer.read(4)
    if len(b) < 4:
        return None
    return json.loads(sys.stdin.buffer.read(struct.unpack("<I", b)[0]) or b"{}")

def responder(d):
    b = json.dumps(d).encode()
    sys.stdout.buffer.write(struct.pack("<I", len(b)) + b)
    sys.stdout.buffer.flush()

while True:
    m = ler()
    if m is None:
        break                      # o Chrome fechou (ou a extensão desligou): o app escondido sai quando ficar parado
    ok = vivo()
    if not ok:
        subprocess.Popen(["/usr/bin/open", "-g", "-j", "-a", APP, "--args", "--sem-janela", "--dono", str(os.getpid())],
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        for _ in range(80):
            time.sleep(0.5)
            if vivo():
                ok = True
                break
    responder({"ok": ok})
'''


def instalar(pasta_app):
    """Registra o host. `pasta_app` = caminho do Multi Estúdio.app. Devolve True se registrou em algum navegador."""
    if sys.platform != "darwin":
        return False                # Windows: o registro do host entra junto com a versão Windows da extensão
    try:
        APOIO.mkdir(parents=True, exist_ok=True)
        (APOIO / "host.py").write_text(HOST % {"app": str(pasta_app)}, encoding="utf-8")
        sh = APOIO / "host.sh"
        sh.write_text(f'#!/bin/bash\nexec "{os.path.realpath(sys.executable)}" "{APOIO / "host.py"}"\n', encoding="utf-8")
        sh.chmod(sh.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
        manifesto = {"name": NOME, "description": "Multi Estúdio", "path": str(sh), "type": "stdio",
                     "allowed_origins": [f"chrome-extension://{ID_EXTENSAO}/"]}
        feito = False
        for pasta in PASTAS_CHROME:
            if pasta.parent.exists():
                pasta.mkdir(exist_ok=True)
                (pasta / f"{NOME}.json").write_text(json.dumps(manifesto, indent=1), encoding="utf-8")
                feito = True
        return feito
    except Exception as e:
        print("ponte com o Chrome:", e, flush=True)
        return False
