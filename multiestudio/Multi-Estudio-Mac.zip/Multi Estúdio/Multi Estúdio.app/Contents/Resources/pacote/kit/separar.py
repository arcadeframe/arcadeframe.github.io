"""
Separação de faixas (voz e instrumentos), 100% local, com o Demucs (licença MIT).

Modos:
  voz           -> instrumental.wav + voz.wav                 (modelo htdemucs, 4 fontes)
  instrumentos  -> voz, bateria, baixo, guitarra, piano, outros (modelo htdemucs_6s)

Na primeira vez o modelo é baixado (uns 80 MB por modelo) e fica guardado no Mac.

Uso:
  python separar.py musica.wav pasta_saida [voz|instrumentos]
"""

import json
import sys
import time
from pathlib import Path

import librosa
import numpy as np
import soundfile as sf

import ritmo

NOMES = {"vocals": "voz", "drums": "bateria", "bass": "baixo",
         "guitar": "guitarra", "piano": "piano", "other": "outros"}
ORDEM = ["voz", "bateria", "baixo", "guitarra", "piano", "outros", "instrumental"]
MODELO = {"voz": "htdemucs", "instrumentos": "htdemucs_6s"}


def _dispositivos():
    import torch
    lista = []
    if getattr(torch.backends, "mps", None) and torch.backends.mps.is_available():
        lista.append("mps")
    lista.append("cpu")
    return lista


def separar(entrada, pasta_saida, modo="voz", aviso=None):
    """Separa `entrada` e grava as faixas em `pasta_saida`.
    `aviso(fração 0-1, texto)` é chamado durante o processo.
    Devolve {"faixas": [{"nome", "arquivo", "energia"}], "tem_voz": bool, "segundos": s}."""
    import torch
    import demucs.apply as dapply
    ritmo.aplicar_threads()
    from demucs.apply import apply_model
    from demucs.pretrained import get_model

    aviso = aviso or (lambda f, t: None)
    pasta_saida = Path(pasta_saida)
    pasta_saida.mkdir(parents=True, exist_ok=True)
    t0 = time.time()

    aviso(0.02, "Carregando o separador (na primeira vez ele é baixado)")
    modelo = get_model(MODELO[modo])
    modelo.eval()

    aviso(0.05, "Lendo a música")
    y, _ = librosa.load(str(entrada), sr=modelo.samplerate, mono=False)
    if y.ndim == 1:
        y = np.stack([y, y])
    mix = torch.from_numpy(y.astype(np.float32))
    ref = mix.mean(0)
    media, desvio = ref.mean(), ref.std() + 1e-8
    mix = (mix - media) / desvio

    # progresso: o Demucs usa tqdm sobre os pedaços da música
    tqdm_original = dapply.tqdm.tqdm

    def tqdm_com_aviso(iteravel, **kw):
        total = kw.get("total") or (len(iteravel) if hasattr(iteravel, "__len__") else None)
        t_ant = time.time()
        for i, item in enumerate(iteravel):
            if total:
                aviso(0.08 + 0.85 * i / total, "Separando as faixas")
            yield item
            ritmo.respirar(time.time() - t_ant)
            t_ant = time.time()

    dapply.tqdm.tqdm = tqdm_com_aviso
    try:
        fontes = None
        for disp in _dispositivos():
            try:
                with torch.no_grad():
                    fontes = apply_model(modelo, mix[None], device=disp, split=True,
                                         overlap=0.25, shifts=1, progress=True)[0]
                break
            except Exception:
                if disp == "cpu":
                    raise
                aviso(0.08, "Tentando de novo pelo processador")
    finally:
        dapply.tqdm.tqdm = tqdm_original

    fontes = (fontes * desvio + media).cpu().numpy()
    aviso(0.95, "Gravando as faixas")
    faixas, energia_total = [], float(np.sqrt(np.mean(y ** 2)) + 1e-9)
    por_nome = {}
    for nome_en, audio in zip(modelo.sources, fontes):
        por_nome[NOMES.get(nome_en, nome_en)] = audio
    if modo == "voz":
        instrumental = sum(a for n, a in por_nome.items() if n != "voz")
        por_nome = {"instrumental": instrumental, "voz": por_nome["voz"]}
    for nome in (["instrumental", "voz"] if modo == "voz" else ORDEM):
        if nome not in por_nome:
            continue
        audio = por_nome[nome]
        pico = float(np.abs(audio).max())
        if pico > 0.999:
            audio = audio * (0.999 / pico)
        arq = pasta_saida / f"{nome}.wav"
        sf.write(str(arq), audio.T, modelo.samplerate, subtype="PCM_16")
        faixas.append({"nome": nome, "arquivo": arq.name,
                       "energia": round(float(np.sqrt(np.mean(audio ** 2))) / energia_total, 3)})
    voz = next((f for f in faixas if f["nome"] == "voz"), None)
    resultado = {"modo": modo, "faixas": faixas, "tem_voz": bool(voz and voz["energia"] > 0.12),
                 "segundos": round(time.time() - t0, 1)}
    (pasta_saida / "separacao.json").write_text(json.dumps(resultado, ensure_ascii=False, indent=2), encoding="utf-8")
    aviso(1.0, "Pronto")
    return resultado


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)
    modo = sys.argv[3] if len(sys.argv) > 3 else "voz"
    r = separar(sys.argv[1], sys.argv[2], modo, aviso=lambda f, t: print(f"{int(f * 100):3d}% {t}", flush=True))
    print(json.dumps(r, ensure_ascii=False))
