"""
Instalador de módulos do Multi Estúdio.

O app chega pequeno (só o módulo básico, de baixar vídeos). Na tela Módulos a pessoa escolhe o resto, e cada
módulo baixa as próprias peças direto das fontes oficiais: bibliotecas (pypi.org), modelos de IA
(huggingface.co) e programas (github.com). A lista do que cada um instala está em catalogo.py.

  resumo()            lista para a tela: instalado, disponível neste sistema, tamanho, andamento
  instalar(id)        instala em segundo plano (um por vez); acompanhe por resumo()
  remover(id)         apaga os modelos e programas do módulo (as bibliotecas ficam: outros módulos usam)
  instalados()        ids instalados
"""
import importlib.util
import io
import json
import os
import platform
import shutil
import subprocess
import sys
import threading
import time
import traceback
import urllib.request
import zipfile
from pathlib import Path

import catalogo
import espaco

KIT = Path(__file__).resolve().parent
BASE = KIT.parent
ESTADO = KIT / "modulos_instalados.json"
TAMANHOS = KIT / ".tamanhos_modelos.json"
LOG = BASE / "instalacao.log"
SISTEMA = "mac" if sys.platform == "darwin" else "windows" if sys.platform.startswith("win") else "linux"
PERFIL = "mac-apple" if SISTEMA == "mac" and platform.machine() == "arm64" else SISTEMA
if os.environ.get("MULTI_PERFIL"):                    # só para os testes automáticos: fingir outro sistema
    PERFIL = os.environ["MULTI_PERFIL"]
    SISTEMA = PERFIL.split("-")[0]
NOME_SISTEMA = {"mac": "Mac", "windows": "Windows", "linux": "Linux"}[SISTEMA]

_TRAVA = threading.Lock()
_JOB = {"id": None, "acao": "", "etapa": "", "progresso": 0.0, "erro": "", "quando": 0.0}
_ULTIMO_ERRO = {}


def catalogo_por_id(mid):
    return next((m for m in catalogo.MODULOS if m["id"] == mid), None)


# ------------------------------------------------------------------ estado --

def _evidencia(m):
    """Instalação antiga (antes de existir a tela Módulos): descobre pelo que já está no computador."""
    tem = lambda *nomes: all(importlib.util.find_spec(n) is not None for n in nomes)       # noqa: E731
    try:
        if m["id"] == "base":
            return tem("yt_dlp")
        if m["id"] == "dublagem":
            return tem("demucs", "mlx_whisper", "mlx_lm", "mlx_audio")
        if m["id"] == "narracao":
            return tem("mlx_audio") and espaco.pasta_modelo("mlx-community/VoxCPM2-8bit").exists()
        if m["id"] == "voz_rapida":
            import zonos
            return zonos.instalado()
    except Exception:
        pass
    return False


def _ler_estado():
    try:
        return json.loads(ESTADO.read_text(encoding="utf-8"))
    except Exception:
        d = {m["id"]: {"quando": "antes da tela Módulos"} for m in catalogo.MODULOS if _evidencia(m)}
        d.setdefault("base", {"quando": "instalador"})
        _gravar_estado(d)
        return d


def _gravar_estado(d):
    try:
        ESTADO.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
    except Exception:
        traceback.print_exc()


def instalados():
    return set(_ler_estado())


# Os modelos de IA ficam no cache do Hugging Face, que é do usuário (não do app): duas instalações no mesmo
# computador (ex.: o app e uma versão de teste) usam os mesmos arquivos. Este registro diz quem usa cada um,
# para "Remover" num não apagar o que o outro ainda usa.
def _registro():
    return espaco.cache_hf().parent / "multiestudio_instalacoes.json"


def _ler_registro():
    try:
        d = json.loads(_registro().read_text(encoding="utf-8"))
    except Exception:
        d = {}
    return {r: [c for c in casas if Path(c, "kit").exists()] for r, casas in d.items()}


def _gravar_registro(d):
    try:
        _registro().parent.mkdir(parents=True, exist_ok=True)
        _registro().write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
    except Exception:
        traceback.print_exc()


def _registrar_uso():
    """Esta instalação usa os modelos dos módulos que tem instalados."""
    d = _ler_registro()
    mudou = False
    for m in catalogo.MODULOS:
        if m["id"] in instalados():
            for r in m.get("modelos", []) + m.get("reserva", []):
                if str(BASE) not in d.setdefault(r, []):
                    d[r].append(str(BASE))
                    mudou = True
    if mudou:
        _gravar_registro(d)


def _outros_usam(repo):
    return any(c != str(BASE) for c in _ler_registro().get(repo, []))


def tem(mid):
    return mid in instalados()


def disponivel(m):
    return PERFIL in m.get("onde", []) or SISTEMA in m.get("onde", [])


# ------------------------------------------------------------------ tamanhos --

def _tamanhos():
    try:
        return json.loads(TAMANHOS.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _tamanho_no_site(repo, padroes=None):
    """Bytes do modelo no Hugging Face (guardado em arquivo: pergunta uma vez só)."""
    chave = repo + ("|" + ",".join(padroes) if padroes else "")
    t = _tamanhos()
    if chave in t:
        return t[chave]
    try:
        import fnmatch
        from huggingface_hub import HfApi
        info = HfApi().model_info(repo, files_metadata=True)
        total = sum((s.size or 0) for s in info.siblings
                    if not padroes or any(fnmatch.fnmatch(s.rfilename, p) for p in padroes))
        t = _tamanhos()
        t[chave] = total
        TAMANHOS.write_text(json.dumps(t), encoding="utf-8")
        return total
    except Exception:
        return 0


def _buscar_tamanhos():
    for m in catalogo.MODULOS:
        for r in m.get("modelos", []):
            _tamanho_no_site(r)
        for rp in m.get("repos", []):
            hf = rp.get("arquivos_hf")
            if hf:
                _tamanho_no_site(hf["repo"], hf["padroes"])


_BUSCA = {"feita": False}


def _previsto(m):
    """GB que o módulo vai ocupar (bibliotecas + modelos). Modelos ainda sem tamanho conhecido contam zero."""
    t = _tamanhos()
    total = float(m.get("libs_gb", 0)) * 1e9
    if all(t.get(r) for r in m.get("modelos", [])):
        total += sum(t[r] for r in m.get("modelos", []))
    else:
        total += float(m.get("modelos_gb", 0)) * 1e9          # ainda sem o tamanho real: usa a estimativa
    for rp in m.get("repos", []):
        hf = rp.get("arquivos_hf")
        if hf:
            total += t.get(hf["repo"] + "|" + ",".join(hf["padroes"]), 0) or hf.get("gb", 0) * 1e9
    return total


def _ocupado(m):
    total = sum(espaco.tamanho(espaco.pasta_modelo(r)) for r in m.get("modelos", []) + m.get("reserva", []))
    total += sum(espaco.tamanho(espaco.cache_torch() / a) for a in m.get("torch", []))
    total += sum(espaco.tamanho(BASE / rp["pasta"]) for rp in m.get("repos", []))
    return total


def resumo():
    if not _BUSCA["feita"]:
        _BUSCA["feita"] = True
        threading.Thread(target=_buscar_tamanhos, daemon=True).start()
        threading.Thread(target=_registrar_uso, daemon=True).start()
    ja = instalados()
    saida = []
    for m in catalogo.MODULOS:
        disp = disponivel(m)
        breve = SISTEMA in m.get("em_breve", [])
        if not disp and not breve:
            continue                                   # módulo que não existe neste sistema: nem aparece
        inst = m["id"] in ja
        job = dict(_JOB) if _JOB["id"] == m["id"] else None
        falta = [catalogo_por_id(d)["nome"] for d in m.get("depende", []) if d not in ja]
        saida.append({"id": m["id"], "nome": m["nome"], "descricao": m["descricao"], "fixo": bool(m.get("fixo")),
                      "instalado": inst, "disponivel": disp,
                      "motivo": "" if disp else f"Em breve no {NOME_SISTEMA}",
                      "gb": espaco.gb(_ocupado(m)) if inst else 0, "previsto_gb": espaco.gb(_previsto(m)),
                      "falta": falta, "trabalhando": job, "erro": _ULTIMO_ERRO.get(m["id"], "")})
    return {"sistema": SISTEMA, "nome_sistema": NOME_SISTEMA, "modulos": saida, "ocupado": bool(_JOB["id"])}


# ------------------------------------------------------------------ instalar --

def _uv():
    u = shutil.which("uv")
    if u:
        return u
    for c in (Path.home() / ".local" / "bin" / ("uv.exe" if SISTEMA == "windows" else "uv"),
              Path.home() / ".cargo" / "bin" / "uv"):
        if c.exists():
            return str(c)
    return None


def _registrar(texto):
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(f"{time.strftime('%d/%m %H:%M:%S')} {texto}\n")
    except Exception:
        pass


def _rodar(cmd, cwd=None, minutos=60):
    _registrar("$ " + " ".join(str(c) for c in cmd))
    amb = dict(os.environ)
    amb["PATH"] = str(Path(sys.executable).parent) + os.pathsep + str(Path.home() / ".local" / "bin") + os.pathsep + amb.get("PATH", "")
    amb.pop("VIRTUAL_ENV", None)
    r = subprocess.run([str(c) for c in cmd], cwd=cwd, env=amb, capture_output=True, text=True, timeout=minutos * 60)
    _registrar((r.stdout or "")[-1500:] + (r.stderr or "")[-3000:])
    if r.returncode != 0:
        fim = ((r.stderr or "") + (r.stdout or "")).strip().splitlines()[-3:]
        raise RuntimeError("; ".join(x.strip() for x in fim)[:300] or f"comando falhou ({r.returncode})")
    return r


def _pip(pacotes):
    """Instala bibliotecas no Python do app. No Mac usa as versões exatas da máquina onde o app foi validado."""
    if isinstance(pacotes, str):
        pacotes = ["-r", str(KIT / pacotes)]
    limite = KIT / f"versoes-{SISTEMA}.txt"
    extra = ["--constraint", str(limite)] if limite.exists() else []
    uv = _uv()
    cmd = [uv, "pip", "install", "--python", sys.executable] if uv else [sys.executable, "-m", "pip", "install"]
    try:
        _rodar(cmd + extra + list(pacotes))
    except RuntimeError:
        if not extra:
            raise
        _registrar("com as versões travadas não deu; tentando com as versões mais novas")
        _rodar(cmd + list(pacotes))


def _baixar_zip(url, destino):
    """Baixa um .zip do GitHub (versão fixa) e abre em `destino`, sem a pasta de cima que o GitHub coloca."""
    destino = Path(destino)
    _registrar(f"baixando {url}")
    req = urllib.request.Request(url, headers={"User-Agent": "MultiEstudio"})
    with urllib.request.urlopen(req, timeout=120) as r:
        dados = r.read()
    destino.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(io.BytesIO(dados)) as z:
        raiz = z.namelist()[0].split("/")[0] + "/"
        for info in z.infolist():
            rel = info.filename[len(raiz):] if info.filename.startswith(raiz) else info.filename
            if not rel:
                continue
            alvo = (destino / rel).resolve()
            if destino.resolve() not in alvo.parents and alvo != destino.resolve():
                continue                               # nome estranho dentro do zip: ignora
            if info.is_dir():
                alvo.mkdir(parents=True, exist_ok=True)
                continue
            alvo.parent.mkdir(parents=True, exist_ok=True)
            with z.open(info) as origem, open(alvo, "wb") as f:
                shutil.copyfileobj(origem, f)
            modo = info.external_attr >> 16
            if modo & 0o111:                           # mantém os scripts executáveis
                alvo.chmod(alvo.stat().st_mode | 0o755)


class _Medidor:
    """Enquanto um download grande roda, mede a pasta e transforma em porcentagem."""
    def __init__(self, pasta, total, ini, fim, texto):
        self.pasta, self.total, self.ini, self.fim, self.texto = pasta, total, ini, fim, texto
        self.vivo = True
        threading.Thread(target=self._laco, daemon=True).start()

    def _laco(self):
        while self.vivo:
            if self.total:
                feito = min(self.total, espaco.tamanho(self.pasta))        # o que já estava baixado conta como feito
                _JOB["progresso"] = round(self.ini + (self.fim - self.ini) * feito / self.total, 3)
                _JOB["etapa"] = f"{self.texto} · {feito / 1e9:.1f} de {self.total / 1e9:.1f} GB"
            time.sleep(1.5)

    def parar(self):
        self.vivo = False


def _instalar(m):
    def passo(texto, p):
        _JOB.update({"etapa": texto, "progresso": round(p, 3)})
        _registrar(f"[{m['id']}] {texto}")

    # 1) bibliotecas
    if m.get("pip"):
        passo("Baixando as bibliotecas (pode levar alguns minutos)", 0.02)
        _pip(m["pip"])
    # 2) programas do GitHub
    for rp in m.get("repos", []):
        pasta = BASE / rp["pasta"]
        if not (pasta / ".instalado").exists():
            passo("Baixando o programa do GitHub", 0.12)
            _baixar_zip(rp["zip"], pasta)
            for sub, url in (rp.get("extras") or {}).items():
                _baixar_zip(url, pasta / sub)
            if rp.get("preparar"):
                passo("Preparando o programa (bibliotecas dele)", 0.18)
                cmd = list(rp["preparar"])
                if cmd[0] == "uv":
                    cmd[0] = _uv() or "uv"
                _rodar(cmd, cwd=str(pasta))
            (pasta / ".instalado").write_text(time.strftime("%Y-%m-%d"), encoding="utf-8")
        hf = rp.get("arquivos_hf")
        if hf:
            from huggingface_hub import snapshot_download
            total = _tamanho_no_site(hf["repo"], hf["padroes"]) or int(hf.get("gb", 0) * 1e9)
            med = _Medidor(pasta / hf["destino"], total, 0.25, 0.98, "Baixando os arquivos da voz")
            try:
                snapshot_download(hf["repo"], allow_patterns=hf["padroes"], local_dir=str(pasta / hf["destino"]))
            finally:
                med.parar()
    # 3) modelos de IA
    modelos = m.get("modelos", [])
    if modelos:
        from huggingface_hub import snapshot_download
        tams = [_tamanho_no_site(r) for r in modelos]
        soma, feito = max(1, sum(tams)), 0
        for r, t in zip(modelos, tams):
            ini, fim = 0.3 + 0.65 * feito / soma, 0.3 + 0.65 * (feito + t) / soma
            nome = r.split("/")[-1]
            passo(f"Baixando o modelo {nome}", ini)
            med = _Medidor(espaco.pasta_modelo(r), t, ini, fim, f"Baixando o modelo {nome}")
            try:
                snapshot_download(r)
            finally:
                med.parar()
            feito += t
    # 4) acerto final (ex.: o separador de voz baixa o arquivo dele)
    if m.get("preparar_py"):
        passo("Baixando o separador de voz", 0.97)
        _rodar([sys.executable, "-c", m["preparar_py"]], minutos=20)


def _trabalhar(mid, acao):
    m = catalogo_por_id(mid)
    try:
        if acao == "instalar":
            _instalar(m)
            d = _ler_estado()
            d[mid] = {"quando": time.strftime("%Y-%m-%d %H:%M")}
            _gravar_estado(d)
            _registrar_uso()
        else:
            _remover(m)
        _ULTIMO_ERRO.pop(mid, None)
        _registrar(f"[{mid}] {acao}: pronto")
    except Exception as e:
        traceback.print_exc()
        _registrar(f"[{mid}] ERRO: {e}")
        _ULTIMO_ERRO[mid] = _mensagem(e)
    finally:
        _JOB.update({"id": None, "acao": "", "etapa": "", "progresso": 0.0})


def _mensagem(e):
    t = str(e)
    if any(x in t for x in ("getaddrinfo", "Temporary failure", "Connection", "timed out", "Max retries", "urlopen error")):
        return "Sem internet ou o site não respondeu. Confira a conexão e tente de novo."
    if "No space left" in t or "Errno 28" in t:
        return "Faltou espaço no disco."
    return "Não deu certo: " + t[:220]


def _comecar(mid, acao):
    m = catalogo_por_id(mid)
    if not m:
        raise ValueError("Módulo desconhecido.")
    with _TRAVA:
        if _JOB["id"]:
            raise RuntimeError("Já tem um módulo sendo instalado. Espere terminar.")
        _JOB.update({"id": mid, "acao": acao, "etapa": "Começando", "progresso": 0.0, "erro": "", "quando": time.time()})
    threading.Thread(target=_trabalhar, args=(mid, acao), daemon=True).start()


def instalar(mid):
    m = catalogo_por_id(mid)
    if not m or not disponivel(m):
        raise ValueError(f"Este módulo ainda não existe para {NOME_SISTEMA}.")
    falta = [catalogo_por_id(d)["nome"] for d in m.get("depende", []) if not tem(d)]
    if falta:
        raise ValueError("Instale antes: " + ", ".join(falta))
    _comecar(mid, "instalar")


def _remover(m):
    _JOB.update({"etapa": "Apagando os arquivos do módulo", "progresso": 0.3})
    outros = [x for x in catalogo.MODULOS if x["id"] != m["id"] and x["id"] in instalados()]
    em_uso = {r for x in outros for r in x.get("modelos", []) + x.get("reserva", [])}
    reg = _ler_registro()
    for r in m.get("modelos", []) + m.get("reserva", []):
        if r not in em_uso and not _outros_usam(r):          # outra instalação (ex.: a de teste) ainda usa: fica
            espaco.apagar_modelo(espaco.pasta_modelo(r))
        if str(BASE) in reg.get(r, []) and r not in em_uso:
            reg[r].remove(str(BASE))
    _gravar_registro(reg)
    for rp in m.get("repos", []):
        if m["id"] == "voz_rapida":
            try:
                import zonos
                zonos.desligar()
            except Exception:
                pass
        shutil.rmtree(BASE / rp["pasta"], ignore_errors=True)
    torch_em_uso = {a for x in outros for a in x.get("torch", [])}
    for a in m.get("torch", []):
        if a not in torch_em_uso:
            (espaco.cache_torch() / a).unlink(missing_ok=True)
    d = _ler_estado()
    d.pop(m["id"], None)
    _gravar_estado(d)


def remover(mid):
    m = catalogo_por_id(mid)
    if not m or m.get("fixo"):
        raise ValueError("Este módulo não pode ser removido.")
    presos = [x["nome"] for x in catalogo.MODULOS if mid in x.get("depende", []) and tem(x["id"])]
    if presos:
        raise ValueError("Remova antes: " + ", ".join(presos))
    _comecar(mid, "remover")
