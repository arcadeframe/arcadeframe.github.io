"""
Compacta vídeos com o chip de vídeo do Mac (mesmo caminho do Leve Maker): H.265 pelo VideoToolbox,
com plano B em H.264 pelo chip e, por último, x264 no processador.

Sempre na MESMA resolução em que o vídeo foi baixado (para ver menor, baixe já na resolução menor).
Níveis (parecidos com as notas do Leve Maker):
  leve   ~ nota 96: imagem igual à original, ~35% menor
  media  ~ nota 93: diferença só olhando de perto, ~55% menor
  forte  ~ nota 90: para arquivo, ~70% menor
Regra do Leve Maker: se não economizar pelo menos 15%, fica o original.
"""
import re
import subprocess
import tempfile
from pathlib import Path

from dublar import ffmpeg

# fração da taxa do vídeo original (H.265 pelo chip rende o dobro do H.264 que o YouTube entrega)
NIVEIS = {"leve": {"fator": 0.65}, "media": {"fator": 0.45}, "forte": {"fator": 0.30}}
MIN_KBPS = {360: 250, 480: 350, 720: 600, 1080: 1000, 1440: 2000, 2160: 3500}
ECONOMIA_MINIMA = 0.15


def sondar(arq):
    r = subprocess.run([ffmpeg(), "-hide_banner", "-i", str(arq)], capture_output=True, text=True)
    txt = r.stderr
    dur = re.search(r"Duration: (\d+):(\d+):([\d.]+)", txt)
    segundos = int(dur.group(1)) * 3600 + int(dur.group(2)) * 60 + float(dur.group(3)) if dur else 0
    linha_v = next((l for l in txt.splitlines() if "Video:" in l), "")
    res = re.search(r"(\d{3,5})x(\d{3,5})", linha_v)
    kb_v = re.search(r"(\d+) kb/s", linha_v)
    kb_total = re.search(r"bitrate: (\d+) kb/s", txt)
    return {"segundos": segundos, "largura": int(res.group(1)) if res else 0, "altura": int(res.group(2)) if res else 0,
            "kbps": int(kb_v.group(1)) if kb_v else (int(kb_total.group(1)) - 160 if kb_total else 0)}


def compactar_video(entrada, saida, nivel, aviso=None):
    """Grava `saida` compactada. Devolve dict com tamanhos, ou None se não valeu a pena (aí `saida` não fica)."""
    entrada, saida = Path(entrada), Path(saida)
    n = NIVEIS[nivel]
    info = sondar(entrada)
    piso = next((v for h, v in sorted(MIN_KBPS.items()) if info["altura"] <= h), 3500)
    kbps = max(piso, int((info["kbps"] or 4000) * n["fator"]))
    if info["kbps"] and kbps >= info["kbps"] * (1 - ECONOMIA_MINIMA):
        return None
    filtro = []
    taxa = ["-b:v", f"{kbps}k", "-maxrate", f"{int(kbps * 1.6)}k", "-bufsize", f"{kbps * 2}k"]
    tentativas = [["-c:v", "hevc_videotoolbox", "-tag:v", "hvc1"] + taxa,
                  ["-c:v", "h264_videotoolbox"] + taxa,
                  ["-c:v", "libx264", "-preset", "veryfast"] + taxa]
    erro = ""
    for cod in tentativas:
        cmd = [ffmpeg(), "-y", "-hide_banner", "-i", str(entrada), "-map", "0:v:0", "-map", "0:a?"] + filtro + cod + \
              ["-c:a", "copy", "-movflags", "+faststart", "-progress", "pipe:1", "-nostats", str(saida)]
        log = tempfile.TemporaryFile(mode="w+")          # arquivo, não pipe: evita travar se o ffmpeg falar muito
        p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=log, text=True)
        for linha in p.stdout:
            if aviso and linha.startswith("out_time_us=") and info["segundos"]:
                try:
                    aviso(min(1.0, int(linha.split("=")[1]) / 1e6 / info["segundos"]))
                except ValueError:
                    pass
        ok = p.wait() == 0
        log.seek(0)
        erro = log.read()[-300:]
        log.close()
        if ok and saida.exists() and saida.stat().st_size > 0:
            antes, depois = entrada.stat().st_size, saida.stat().st_size
            if depois > antes * (1 - ECONOMIA_MINIMA):
                saida.unlink()
                return None
            return {"antes_mb": round(antes / 1e6, 1), "depois_mb": round(depois / 1e6, 1),
                    "codec": cod[1], "nivel": nivel}
        if saida.exists():
            saida.unlink()
    raise RuntimeError("Não consegui compactar o vídeo: " + erro)


def compactar_no_lugar(arq, nivel, aviso=None):
    """Troca o arquivo pelo compactado (sem deixar duplicado). Devolve o resultado ou None."""
    arq = Path(arq)
    tmp = arq.with_name(arq.stem + ".compactando.mp4")
    r = compactar_video(arq, tmp, nivel, aviso)
    if not r:
        return None
    final = arq.with_suffix(".mp4")
    tmp.replace(final)
    if final != arq and arq.exists():
        arq.unlink()
    r["arquivo"] = str(final)
    return r
