"""
Boas maneiras com o YouTube (e outros sites), para não cair na verificação "confirme que não é um robô".

- Um download do YouTube por vez no app inteiro (o pré-download espera o atual terminar).
- Intervalo mínimo entre downloads e pausa curta entre os pedidos de cada download.
- Remédio automático (com_remedio): se o YouTube recusar, o app tenta sozinho os outros caminhos (IPv4, IPv6 e
  outros "jeitos" de pedir o vídeo), um por vez, e guarda o que funcionou. Só se todos falharem o vídeo vira erro.
- A pausa automática antiga (10 min, 30 min, 1 h, 2 h) está desligada (PAUSAS zerado): quem decide tentar de novo é você.
Este módulo não é recarregado pelo app (guarda o estado enquanto ele está aberto) e grava o estado em Dublados/youtube.json.
"""
import json
import re
import threading
import time
from contextlib import contextmanager
from pathlib import Path

ARQ = Path(__file__).resolve().parent.parent / "Dublados" / "youtube.json"
INTERVALO_MIN = 20          # segundos entre um download do YouTube e o próximo
PAUSAS = [0, 0, 0, 0]       # sem pausa automática (pedido do Ronay): o vídeo recusado vira erro com "Tentar de novo"
ESQUECER = 6 * 3600         # bloqueio antigo não aumenta a próxima pausa
_TRAVA = threading.Lock()
_EST = {"ultimo_fim": 0.0}


class YouTubePausado(RuntimeError):
    def __init__(self, ate):
        super().__init__(f"YouTube pediu verificação (Sign in to confirm you're not a bot). Pausa até {time.strftime('%H:%M', time.localtime(ate))}")
        self.ate = ate


def eh_youtube(url):
    return bool(re.search(r"(youtube\.com|youtu\.be|youtube-nocookie\.com)", str(url)))


def _ler():
    try:
        return json.loads(ARQ.read_text(encoding="utf-8"))
    except Exception:
        return {"pausa_ate": 0, "seguidas": 0}


def _gravar(d):
    try:
        ARQ.parent.mkdir(exist_ok=True)
        ARQ.write_text(json.dumps(d), encoding="utf-8")
    except Exception:
        pass


def liberar():
    """Botão "Tentar agora": tira a pausa (se o YouTube recusar de novo, volta a pausar)."""
    d = _ler()
    d["pausa_ate"] = 0
    _gravar(d)


def pausa_ate():
    if not any(PAUSAS):
        return 0.0
    return float(_ler().get("pausa_ate", 0))


def em_pausa():
    return pausa_ate() > time.time()


EXTRAS = {}        # link -> {"referer", "titulo"}: vídeos achados pela extensão em outros sites


def registrar(url, referer="", titulo=""):
    if referer or titulo:
        EXTRAS[str(url)] = {"referer": str(referer or ""), "titulo": str(titulo or "")}


def titulo_de(url):
    return (EXTRAS.get(str(url)) or {}).get("titulo") or ""


def opcoes(url=None):
    """Opções extras do yt-dlp: pausa curta entre os pedidos de um mesmo download."""
    o = {"sleep_interval_requests": 0.8}
    ref = (EXTRAS.get(str(url)) or {}).get("referer")
    if ref:                       # muitos sites só entregam o vídeo para quem vem da página dele
        o["http_headers"] = {"Referer": ref}
    # comprovante de navegador (bgutil): o YouTube desconfia menos e pede menos "confirme que não é um robô"
    casa = Path(__file__).resolve().parent.parent / "motores" / "bgutil" / "server"
    if (casa / "package.json").exists():
        o["extractor_args"] = {"youtubepot-bgutilscript": {"server_home": [str(casa)]}}
    return o


@contextmanager
def vez_do_youtube(url, aviso=None):
    """Use em volta de cada download. Para sites que não são o YouTube, não faz nada."""
    if not eh_youtube(url):
        yield
        return
    if em_pausa():
        raise YouTubePausado(pausa_ate())
    with _TRAVA:
        espera = INTERVALO_MIN - (time.time() - _EST["ultimo_fim"])
        if espera > 0:
            if aviso:
                aviso(f"Aguardando {int(espera)} s para não sobrecarregar o YouTube")
            time.sleep(espera)
        if em_pausa():
            raise YouTubePausado(pausa_ate())
        try:
            yield
            d = _ler()
            if d.get("seguidas"):
                d["seguidas"] = 0
                _gravar(d)
        except Exception as e:
            if eh_bloqueio(str(e)):
                bloqueado()
                raise YouTubePausado(pausa_ate()) from e
            raise
        finally:
            _EST["ultimo_fim"] = time.time()


# ------------------------------------------------------------------ remédio automático --
# Quando o YouTube recusa ("confirme que você não é um robô"), quase sempre é um dos endereços da internet que
# ficou marcado (o IPv6, por exemplo), não o computador. O app tenta sozinho os outros caminhos, um por vez e com
# intervalo, e guarda o que funcionou para começar por ele da próxima vez. Sem login e sem conta nenhuma.
ROTAS = [
    {"id": "ipv4", "nome": "internet IPv4", "op": {"source_address": "0.0.0.0"}},
    {"id": "ipv6", "nome": "internet IPv6", "op": {"source_address": "::"}},
    {"id": "ipv4-tv", "nome": "IPv4, jeito de TV", "op": {"source_address": "0.0.0.0"},
     "ea": {"youtube": {"player_client": ["tv", "web_embedded"]}}},
    {"id": "ipv4-celular", "nome": "IPv4, jeito de celular", "op": {"source_address": "0.0.0.0"},
     "ea": {"youtube": {"player_client": ["mweb", "web_safari"]}}},
]


def rotas_em_ordem():
    """A rota que funcionou por último vem primeiro."""
    boa = _ler().get("rota")
    return sorted(ROTAS, key=lambda r: r["id"] != boa)


def com_rota(opcoes, rota):
    """Opções do yt-dlp com a rota aplicada (junta os extractor_args em vez de trocar)."""
    o = {**opcoes, **rota.get("op", {})}
    if rota.get("ea"):
        o["extractor_args"] = {**(opcoes.get("extractor_args") or {}), **rota["ea"]}
    return o


def com_remedio(url, fazer, aviso=None, espera=4.0):
    """Roda fazer(opcoes_da_rota). Para o YouTube: se ele recusar por achar que é robô, tenta as outras rotas
    sozinho. `fazer` recebe uma função que aplica a rota nas opções do yt-dlp. `aviso(texto)` é opcional.
    Se todas falharem, sobe o primeiro erro de bloqueio (aí o item vira erro, com "Tentar de novo")."""
    if not eh_youtube(url):
        return fazer(lambda o: o)
    fila = list(rotas_em_ordem())
    primeiro, k, repetiu = None, 0, False
    while fila:
        rota = fila.pop(0)
        k += 1
        try:
            r = fazer(lambda o, rota=rota: com_rota(o, rota))
            if _ler().get("rota") != rota["id"]:
                d = _ler()
                d["rota"] = rota["id"]
                _gravar(d)
            if k > 1:
                print(f"YouTube: passou pela rota {rota['id']} na tentativa {k}", flush=True)
            return r
        except Exception as e:
            txt = str(e)
            recusa = eh_bloqueio(txt) or isinstance(e, YouTubePausado)
            proibido = "HTTP Error 403" in txt             # o YouTube negou o arquivo do vídeo no meio do download
            if primeiro is None and not (recusa or proibido):
                raise                              # erro comum (vídeo privado, link errado): não adianta trocar de rota
            primeiro = primeiro or e
            print(f"YouTube: rota {rota['id']} falhou: {txt[:160]}", flush=True)
            if proibido and not repetiu:           # o 403 costuma passar repetindo o mesmo caminho uma vez
                repetiu = True
                fila.insert(0, rota)
            if fila:
                if aviso:
                    try:
                        aviso(f"YouTube recusou, tentando de novo por outro caminho (tentativa {k + 1})")
                    except Exception:
                        pass
                time.sleep(espera)
    raise primeiro


def eh_bloqueio(msg):
    return any(t in msg for t in ("not a bot", "Sign in to confirm", "HTTP Error 429", "Too Many Requests"))


def bloqueado():
    d = _ler()
    n = int(d.get("seguidas", 0))
    if time.time() - float(d.get("ultimo", 0)) > ESQUECER:
        n = 0
    d["ultimo"] = time.time()
    d["pausa_ate"] = time.time() + PAUSAS[min(n, len(PAUSAS) - 1)]
    d["seguidas"] = n + 1
    _gravar(d)
    return d["pausa_ate"]
