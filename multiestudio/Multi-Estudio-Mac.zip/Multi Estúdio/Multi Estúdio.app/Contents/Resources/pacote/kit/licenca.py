"""
Serial do Multi Estúdio: o mesmo esquema do Leve Maker e do Seletor (chave Ed25519 do Ronay).

O serial traz o nome, o começo, o fim (ou sem prazo) e, se quiser, o código do computador, tudo assinado
com Ed25519 (RFC 8032). O app só tem a chave pública (a "fechadura"): confere o serial, mas não consegue
criar um. A chave secreta é a mesma do Seletor e do Leve Maker e fica só no computador do Ronay (o master),
que usa o app sem serial e ganha o painel "Gerar serial".

Serial comum: não leva o código do computador. Ao ativar, a ativação fica presa a este computador
(copiar a pasta para outro não leva a licença junto).
Relógio voltado: o app guarda o último dia de uso em dois lugares; data de hoje para trás = bloqueio.

Produto 'M' e prefixo ME-: serial do Leve Maker (LM-) ou do Seletor não abre o Multi Estúdio, e vice-versa.
Ed25519 em Python puro (sem biblioteca extra), conferido contra os vetores de teste da RFC 8032.
"""
import hashlib
import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path

PUBLICA = bytes([0x19, 0x5f, 0xaf, 0x24, 0x92, 0x7b, 0x61, 0x56, 0x46, 0x4f, 0xc5, 0x3d, 0x8f, 0x79, 0x25, 0x16,
                 0x25, 0x29, 0xfb, 0x7b, 0xb3, 0x5f, 0xcf, 0x8f, 0xe8, 0x24, 0x06, 0x37, 0x6b, 0x47, 0x34, 0x4e])
EPOCA_UNIX = 20454            # dias de 1970-01-01 até 2026-01-01 (a "época" do serial, igual ao Leve Maker)
VITALICIO = 0xFFFF
VERSAO = 2
PRODUTO = ord("M")
PREFIXO = "ME"
ARQUIVO_CHAVE = "chave-de-convites.key"

# ------------------------------------------------------------------ Ed25519 (RFC 8032, seção 6) --
_p = 2 ** 255 - 19
_L = 2 ** 252 + 27742317777372353535851937790883648493
_d = -121665 * pow(121666, _p - 2, _p) % _p
_I = pow(2, (_p - 1) // 4, _p)


def _h(m):
    return hashlib.sha512(m).digest()


def _somar(P, Q):
    A, B = (P[1] - P[0]) * (Q[1] - Q[0]) % _p, (P[1] + P[0]) * (Q[1] + Q[0]) % _p
    C, D = 2 * P[3] * Q[3] * _d % _p, 2 * P[2] * Q[2] % _p
    E, F, G, H = B - A, D - C, D + C, B + A
    return (E * F % _p, G * H % _p, F * G % _p, E * H % _p)


def _vezes(s, P):
    Q = (0, 1, 1, 0)
    while s > 0:
        if s & 1:
            Q = _somar(Q, P)
        P = _somar(P, P)
        s >>= 1
    return Q


def _igual(P, Q):
    return (P[0] * Q[2] - Q[0] * P[2]) % _p == 0 and (P[1] * Q[2] - Q[1] * P[2]) % _p == 0


def _x(y, sinal):
    if y >= _p:
        return None
    x2 = (y * y - 1) * pow(_d * y * y + 1, _p - 2, _p)
    if x2 == 0:
        return None if sinal else 0
    x = pow(x2, (_p + 3) // 8, _p)
    if (x * x - x2) % _p != 0:
        x = x * _I % _p
    if (x * x - x2) % _p != 0:
        return None
    if (x & 1) != sinal:
        x = _p - x
    return x


_gy = 4 * pow(5, _p - 2, _p) % _p
_gx = _x(_gy, 0)
_G = (_gx, _gy, 1, _gx * _gy % _p)


def _comprimir(P):
    zi = pow(P[2], _p - 2, _p)
    x, y = P[0] * zi % _p, P[1] * zi % _p
    return int.to_bytes(y | ((x & 1) << 255), 32, "little")


def _descomprimir(s):
    if len(s) != 32:
        return None
    y = int.from_bytes(s, "little")
    sinal = y >> 255
    y &= (1 << 255) - 1
    x = _x(y, sinal)
    return None if x is None else (x, y, 1, x * y % _p)


def _expandir(secreta):
    h = _h(secreta)
    a = int.from_bytes(h[:32], "little")
    a &= (1 << 254) - 8
    a |= 1 << 254
    return a, h[32:]


def publica_de(secreta):
    a, _ = _expandir(secreta)
    return _comprimir(_vezes(a, _G))


def assinar(secreta, msg):
    a, prefixo = _expandir(secreta)
    A = _comprimir(_vezes(a, _G))
    r = int.from_bytes(_h(prefixo + msg), "little") % _L
    R = _comprimir(_vezes(r, _G))
    k = int.from_bytes(_h(R + A + msg), "little") % _L
    return R + int.to_bytes((r + k * a) % _L, 32, "little")


def conferir(publica, msg, assinatura):
    if len(publica) != 32 or len(assinatura) != 64:
        return False
    A, R = _descomprimir(publica), _descomprimir(assinatura[:32])
    if not A or not R:
        return False
    s = int.from_bytes(assinatura[32:], "little")
    if s >= _L:
        return False
    k = int.from_bytes(_h(assinatura[:32] + publica + msg), "little") % _L
    return _igual(_vezes(s, _G), _somar(R, _vezes(k, A)))


# ------------------------------------------------------------------ base32 (RFC 4648, sem "=") --
ALFA = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567"


def b32(dados):
    out, buf, bits = [], 0, 0
    for b in dados:
        buf, bits = (buf << 8) | b, bits + 8
        while bits >= 5:
            out.append(ALFA[(buf >> (bits - 5)) & 31])
            bits -= 5
    if bits:
        out.append(ALFA[(buf << (5 - bits)) & 31])
    return "".join(out)


def unb32(s):
    out, buf, bits = bytearray(), 0, 0
    for c in s:
        c = {"0": "O", "1": "I", "8": "B"}.get(c.upper(), c.upper())       # letras que a pessoa confunde
        if c not in ALFA:
            return None
        buf, bits = (buf << 5) | ALFA.index(c), bits + 5
        if bits >= 8:
            out.append((buf >> (bits - 8)) & 0xFF)
            bits -= 8
    return bytes(out)


def agrupar(s, n):
    return "-".join(s[i:i + n] for i in range(0, len(s), n))


# ------------------------------------------------------------------ datas --
def hoje():
    return max(0, min(VITALICIO - 1, int(time.time()) // 86400 - EPOCA_UNIX))


def data_txt(dia):
    if dia == VITALICIO:
        return "sem prazo"
    t = time.gmtime((dia + EPOCA_UNIX) * 86400)
    return f"{t.tm_mday:02d}/{t.tm_mon:02d}/{t.tm_year}"


# ------------------------------------------------------------------ computador --
def id_bruto():
    try:
        if sys.platform == "darwin":
            t = subprocess.run(["/usr/sbin/ioreg", "-rd1", "-c", "IOPlatformExpertDevice"], capture_output=True, text=True,
                               timeout=10).stdout
            m = re.search(r'"IOPlatformUUID"\s*=\s*"([^"]+)"', t)
            if m:
                return m.group(1)
        elif sys.platform.startswith("win"):
            import winreg
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography", 0,
                                winreg.KEY_READ | getattr(winreg, "KEY_WOW64_64KEY", 0)) as k:
                return str(winreg.QueryValueEx(k, "MachineGuid")[0])
    except Exception:
        pass
    for f in ("/etc/machine-id", "/var/lib/dbus/machine-id"):
        try:
            return Path(f).read_text().strip()
        except Exception:
            pass
    return ""


def codigo_maquina(ident=None):
    """Código curto deste computador (ex.: K7QF2-9XMPA)."""
    h = hashlib.sha256(f"multiestudio:{id_bruto() if ident is None else ident}".encode()).digest()
    return agrupar(b32(h[:6])[:10], 5)


def _bytes_maquina(codigo):
    limpo = re.sub(r"[^A-Za-z0-9]", "", codigo or "")
    if len(limpo) != 10:
        return None
    v = unb32(limpo)
    return v[:6] if v and len(v) >= 6 else None


# ------------------------------------------------------------------ serial --
def gerar(secreta, nome, dias=None, maquina="", dia_hoje=None):
    """Gera o serial (só no computador com a chave secreta). dias=None: sem prazo."""
    if maquina.strip():
        maq = _bytes_maquina(maquina)
        if maq is None:
            raise ValueError("O código do computador tem 10 letras e números, como K7QF2-9XMPA.")
    else:
        maq = bytes(6)
    ini = hoje() if dia_hoje is None else dia_hoje
    fim = VITALICIO if dias is None else min(VITALICIO - 1, ini + int(dias))
    nome_b = nome.strip().encode("utf-8")[:40]
    while nome_b:
        try:
            nome_b.decode("utf-8")
            break
        except UnicodeDecodeError:
            nome_b = nome_b[:-1]                          # não corta letra acentuada no meio
    p = bytes([VERSAO, PRODUTO]) + ini.to_bytes(2, "big") + fim.to_bytes(2, "big") + maq + nome_b
    return f"{PREFIXO}-" + agrupar(b32(p + assinar(secreta, p)), 6)


def _ler_um(codigo, publica):
    s = re.sub(r"[^A-Za-z0-9]", "", codigo or "").upper()
    if not s.startswith(PREFIXO):
        return None
    raw = unb32(s[len(PREFIXO):])
    if not raw or len(raw) < 12 + 64:
        return None
    # o base32 pode sobrar 1 byte de enchimento no fim: a assinatura são os 64 bytes antes dele
    for corte in (0, 1):
        dados = raw[:len(raw) - corte] if corte else raw
        p, sig = dados[:-64], dados[-64:]
        if len(p) >= 12 and p[0] == VERSAO and p[1] == PRODUTO and conferir(publica, p, sig):
            return {"nome": p[12:].decode("utf-8", "replace"), "inicio": int.from_bytes(p[2:4], "big"),
                    "fim": int.from_bytes(p[4:6], "big"),
                    "maquina": "" if not any(p[6:12]) else agrupar(b32(p[6:12])[:10], 5)}
    return None


def ler(texto, publica=PUBLICA):
    """Lê o serial; aceita a mensagem inteira do WhatsApp colada (acha o "ME-..." no meio do texto)."""
    s = _ler_um(texto, publica)
    if s:
        return s
    for m in re.finditer(r"ME-[A-Za-z0-9-]+", (texto or "").upper()):
        s = _ler_um(m.group(0), publica)
        if s:
            return s
    return None


# ------------------------------------------------------------------ estado neste computador --
def pasta_dados():
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Application Support" / "MultiEstudio"
    if sys.platform.startswith("win"):
        return Path(os.environ.get("APPDATA") or Path.home()) / "MultiEstudio"
    return Path.home() / ".config" / "multiestudio"


def _lugares_da_chave(dados):
    casa = Path.home()
    lugares = [dados / ARQUIVO_CHAVE]
    if sys.platform == "darwin":
        sup = casa / "Library" / "Application Support"
        lugares += [sup / "Seletor" / ARQUIVO_CHAVE, sup / "com.galdino.levemaker" / ARQUIVO_CHAVE]
    elif sys.platform.startswith("win"):
        ad = Path(os.environ.get("APPDATA") or casa)
        lugares += [ad / "Seletor" / ARQUIVO_CHAVE, ad / "com.galdino.levemaker" / ARQUIVO_CHAVE]
    return lugares


def _ler_chave(arq):
    try:
        t = Path(arq).read_text(encoding="utf-8").strip()
        k = bytes.fromhex(t)
    except Exception:
        return None
    return k if len(k) == 32 and publica_de(k) == PUBLICA else None


def chave_admin(dados=None):
    """Chave secreta do master, se este computador tiver (a do Multi Estúdio, do Seletor ou do Leve Maker)."""
    for lugar in _lugares_da_chave(dados or pasta_dados()):
        k = _ler_chave(lugar)
        if k:
            return k
    return None


def instalar_chave(arquivo, dados=None):
    dados = dados or pasta_dados()
    k = _ler_chave(arquivo)
    if not k:
        raise ValueError("Esta não é a chave de convites da Galdino.")
    dados.mkdir(parents=True, exist_ok=True)
    alvo = dados / ARQUIVO_CHAVE
    alvo.write_text(k.hex(), encoding="utf-8")
    try:
        alvo.chmod(0o600)
    except Exception:
        pass


def _ultimo_uso(dados, extra=()):
    dias = []
    for f in (dados / ".uso", dados / ".uso2"):
        try:
            dias.append(int(f.read_text().strip()))
        except Exception:
            pass
    for f in extra:                                       # a fila de trabalhos também conta: apagar os .uso não adianta
        try:
            dias.append(max(0, int(Path(f).stat().st_mtime) // 86400 - EPOCA_UNIX))
        except Exception:
            pass
    return max(dias) if dias else None


def _marcar_uso(dados, dia):
    try:
        dados.mkdir(parents=True, exist_ok=True)
        for f in (dados / ".uso", dados / ".uso2"):
            f.write_text(str(dia))
    except Exception:
        pass


_CACHE = {"t": 0.0, "e": None}


def estado(dados=None, extra=(), ident=None, dia_hoje=None, publica=PUBLICA, usar_cache=False):
    """{"ok", "admin", "nome", "validade", "dias_restantes", "motivo", "codigo_maquina"}.
    motivo: "", "sem_serial", "invalido", "outra_maquina", "vencido", "relogio"."""
    if usar_cache and _CACHE["e"] and time.time() - _CACHE["t"] < 60:
        return _CACHE["e"]
    dados = dados or pasta_dados()
    cod = codigo_maquina(ident)
    hj = hoje() if dia_hoje is None else dia_hoje
    base = {"ok": False, "admin": False, "nome": "", "validade": "", "dias_restantes": None, "motivo": "", "codigo_maquina": cod}

    def fim(e):
        if usar_cache:
            _CACHE.update({"t": time.time(), "e": e})
        return e
    if publica == PUBLICA and chave_admin(dados):
        return fim({**base, "ok": True, "admin": True, "nome": "Master", "validade": "sem prazo"})
    try:
        texto = (dados / "serial.txt").read_text(encoding="utf-8")
    except Exception:
        return fim({**base, "motivo": "sem_serial"})
    s = ler(texto, publica)
    if not s:
        return fim({**base, "motivo": "invalido"})
    base.update({"nome": s["nome"], "validade": data_txt(s["fim"])})
    try:
        ativado_em = (dados / "serial.maq").read_text().strip()
    except Exception:
        ativado_em = None
    dono = s["maquina"] or ativado_em or cod
    if dono != cod:
        return fim({**base, "motivo": "outra_maquina"})
    ultimo = _ultimo_uso(dados, extra)
    if ultimo is not None and hj + 1 < ultimo:          # relógio voltado (1 dia de folga por fuso horário)
        return fim({**base, "motivo": "relogio"})
    if ultimo is None or hj > ultimo:
        _marcar_uso(dados, hj)
    if s["fim"] == VITALICIO:
        return fim({**base, "ok": True})
    resta = s["fim"] - max(hj, ultimo or 0)
    return fim({**base, "ok": resta >= 0, "dias_restantes": max(0, resta), "motivo": "" if resta >= 0 else "vencido"})


def ativar(texto, dados=None, extra=(), ident=None, dia_hoje=None, publica=PUBLICA):
    dados = dados or pasta_dados()
    hj = hoje() if dia_hoje is None else dia_hoje
    s = ler(texto, publica)
    if not s:
        raise ValueError("Serial inválido. Confira se copiou o serial inteiro, do ME até o fim.")
    cod = codigo_maquina(ident)
    if s["maquina"] and s["maquina"] != cod:
        raise ValueError("Este serial foi feito para outro computador. Peça um serial novo para a Galdino.")
    if s["fim"] != VITALICIO and s["fim"] < hj:
        raise ValueError(f"Este serial venceu em {data_txt(s['fim'])}. Peça um serial novo.")
    dados.mkdir(parents=True, exist_ok=True)
    (dados / "serial.maq").write_text(cod)
    velho = None
    try:
        velho = ler((dados / "serial.txt").read_text(encoding="utf-8"), publica)
    except Exception:
        pass
    if not (velho and velho["maquina"] == s["maquina"] and (velho["fim"] == VITALICIO or (s["fim"] != VITALICIO and velho["fim"] >= s["fim"]))):
        m = re.search(r"ME-[A-Za-z0-9-]+", texto.upper())
        (dados / "serial.txt").write_text(m.group(0) if m else texto.strip().upper(), encoding="utf-8")
        _marcar_uso(dados, hj)                            # serial novo perdoa um relógio que tinha ficado adiantado
    _CACHE["e"] = None
    return estado(dados, extra, ident, hj, publica)


def mensagem(nome, serial, validade):
    prazo = "sem prazo" if validade == "sem prazo" else f"válido até {validade}"
    return (f"Olá, {nome}! Seu serial do Multi Estúdio ({prazo}):\n\n{serial}\n\n"
            "Abra o Multi Estúdio, cole esta mensagem inteira e clique em Ativar.")


if __name__ == "__main__":
    print(json.dumps(estado(), ensure_ascii=False, indent=1))
