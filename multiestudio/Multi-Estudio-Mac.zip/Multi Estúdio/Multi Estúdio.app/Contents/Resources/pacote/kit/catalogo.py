"""
Catálogo dos módulos do Multi Estúdio: o que cada um é, o que instala e de onde baixa.
Só dados (sem código), para o instalador (modulos.py) e a tela de espaço (espaco.py) lerem o mesmo lugar.

Campos de cada módulo:
  onde      em que sistema ele existe: "mac-apple" (Mac com chip Apple), "mac", "windows", "linux"
  pip       bibliotecas Python (baixadas de pypi.org)
  modelos   modelos de IA (baixados de huggingface.co). `reserva` conta no espaço, mas só baixa se for usado
  torch     arquivos do separador de voz (baixados de dl.fbaipublicfiles.com pelo Demucs)
  repos     programas baixados do GitHub numa versão fixa: {"pasta", "zip", "extras", "preparar", "arquivos_hf"}
  depende   módulos que precisam estar instalados antes
  libs_gb   tamanho aproximado das bibliotecas, só para mostrar na tela antes de instalar
  modelos_gb  tamanho aproximado dos modelos, usado só enquanto o app não conseguiu perguntar o tamanho real ao site
"""

VOZ_STACK = ["mlx-audio", "misaki", "espeakng-loader", "phonemizer-fork", "num2words", "librosa", "scipy", "pyloudnorm"]

MODULOS = [
    {"id": "base", "nome": "Baixar vídeos", "fixo": True,
     "descricao": "Baixa vídeo ou só o áudio do YouTube e de mais de mil sites, com fila e extensão do Chrome",
     "onde": ["mac-apple", "mac", "windows", "linux"],
     "pip": "requisitos-base.txt", "libs_gb": 0.3},

    {"id": "dublagem", "nome": "Dublar vídeos",
     "descricao": "Transcreve, traduz e dubla o vídeo em português, com legenda. Tudo no seu computador",
     "onde": ["mac-apple"], "em_breve": ["windows"], "depende": ["base"],
     "pip": ["torch", "torchaudio", "demucs==4.0.1", "mlx-whisper", "mlx-lm"] + VOZ_STACK, "libs_gb": 1.6, "modelos_gb": 12.0,
     "modelos": ["mlx-community/parakeet-tdt-0.6b-v3", "mlx-community/whisper-large-v3-turbo",
                 "mlx-community/Qwen3.5-9B-MLX-4bit", "mlx-community/Qwen3-4B-Instruct-2507-4bit",
                 "mlx-community/Kokoro-82M-bf16"],
     "reserva": ["mlx-community/gemma-4-e4b-it-4bit"],
     "torch": ["955717e8-8726e21a.th"], "preparar_py": "from demucs.pretrained import get_model; get_model('htdemucs')"},

    {"id": "narracao", "nome": "Narração e voz natural",
     "descricao": "Aba Narração (texto vira locução), criar e clonar vozes, e o modo Caprichado da dublagem",
     "onde": ["mac-apple"], "em_breve": ["windows"], "depende": ["base"],
     "pip": VOZ_STACK, "libs_gb": 1.2, "modelos_gb": 2.5,
     "modelos": ["mlx-community/VoxCPM2-8bit", "mlx-community/Kokoro-82M-bf16"]},

    {"id": "voz_rapida", "nome": "Voz rápida natural",
     "descricao": "Deixa a voz dos modos Rápido e Equilibrado e da dublagem ao vivo bem mais natural (ZONOS3)",
     "onde": ["mac-apple"], "em_breve": ["windows"], "depende": ["base"], "libs_gb": 1.3,
     "repos": [{"pasta": "motores/zonos3",
                "zip": "https://github.com/Zyphra/ZONOS3-Mini/archive/a50e14117d99181ba7f28047b451ba03ba1a09a9.zip",
                "extras": {"third_party/fusealign-multilingual":
                           "https://github.com/Zyphra/fusealign-multilingual/archive/64d311875e55e797dafae2a7c3b0c1e45967459f.zip"},
                "preparar": ["uv", "sync", "--locked", "--package", "zonos3-mlx", "--group", "phonemize"],
                "arquivos_hf": {"repo": "Zyphra/ZONOS3-Mini", "destino": "servers/ggml",
                                "padroes": ["gguf/backbone-ptq.gguf", "gguf/spk-encoder.gguf", "gguf/zac.gguf", "gguf/voices/*"],
                                "gb": 2.9}}]},
]

import os as _os
if _os.environ.get("MULTI_MODULO_TESTE"):             # só para os testes automáticos do instalador
    MODULOS.append({"id": "teste", "nome": "Módulo de teste", "descricao": "Pequeno, para testar o instalador",
                    "onde": ["mac-apple", "mac", "windows", "linux"], "depende": ["base"], "libs_gb": 0.01,
                    "pip": ["num2words"],
                    "repos": [{"pasta": "motores/teste",
                               "zip": _os.environ.get("MULTI_ZIP_TESTE", "https://github.com/Brainicism/bgutil-ytdlp-pot-provider/archive/refs/tags/2.0.2.zip")}]})

FONTES = {"pip": "pypi.org", "modelos": "huggingface.co", "repos": "github.com", "torch": "dl.fbaipublicfiles.com (Demucs)"}
