"""
Potência: quanto do computador o app pode usar (10 a 100%).
Funciona por "respiro": depois de cada pedaço de trabalho, o app descansa na
proporção certa. Com 50%, trabalha 1 s e descansa 1 s. Vale na hora, sem reiniciar.
"""
import json
import os
import time
from pathlib import Path

ARQ = Path(__file__).resolve().parent.parent / "potencia.json"
_cache = {"t": 0.0, "p": 100}


def potencia():
    if time.time() - _cache["t"] > 2:
        try:
            _cache["p"] = int(json.loads(ARQ.read_text(encoding="utf-8"))["potencia"])
        except Exception:
            _cache["p"] = 100
        _cache["t"] = time.time()
    return max(10, min(100, _cache["p"]))


def definir(p):
    p = max(10, min(100, int(p)))
    ARQ.write_text(json.dumps({"potencia": p}), encoding="utf-8")
    _cache.update({"t": time.time(), "p": p})
    aplicar_threads()
    return p


def respirar(trabalho_s):
    """Chame depois de um pedaço de trabalho que levou `trabalho_s` segundos."""
    p = potencia()
    if p < 100 and trabalho_s > 0:
        time.sleep(min(60.0, trabalho_s * (100.0 / p - 1.0)))


def aplicar_threads():
    try:
        import torch
        n = os.cpu_count() or 8
        torch.set_num_threads(max(1, round(n * potencia() / 100)))
    except Exception:
        pass


class Cronometro:
    """with Cronometro(): ...  -> respira no fim, proporcional ao tempo gasto."""
    def __enter__(self):
        self.t0 = time.time()
        return self

    def __exit__(self, *a):
        respirar(time.time() - self.t0)
