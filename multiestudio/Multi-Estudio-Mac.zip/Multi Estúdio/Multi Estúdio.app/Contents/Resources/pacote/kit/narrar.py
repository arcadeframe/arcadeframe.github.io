"""
Narração: texto longo em português -> locução, com voz pronta ou clonada.
Motor: Chatterbox Multilingual V3 (MIT) via mlx-audio. Ele sempre fala a partir de
uma voz de referência; as vozes prontas são referências que acompanham o app.

O texto é dividido em trechos curtos (o motor rende melhor assim) e cada trecho
vira um arquivo, para poder refazer só o que ficou ruim.
"""
import json
import re
import threading
import time
from pathlib import Path

import numpy as np
import soundfile as sf

MODELO = "mlx-community/chatterbox-multilingual-v3"
MODELO_VOZES = "mlx-community/Kokoro-82M-bf16"
MODELO_VOX = "mlx-community/VoxCPM2-8bit"     # VoxCPM2 (Apache 2.0): fala mais natural e lida melhor com nomes estrangeiros
PASSOS_VOX = 10
SR_SAIDA = 24000
MAX_TRECHO = 260          # caracteres por trecho
FRASE_REF = ("Olá, esta é a minha voz. Eu gravo locuções para vídeos, eventos e apresentações, "
             "sempre com calma, clareza e boa dicção, do começo ao fim.")
VOZES_PADRAO = [{"id": "alex", "nome": "Thiago", "estilo": "Padrão do app, masculina", "kokoro": "pm_alex", "zonos": "Thiago_pt_M_1"},
                {"id": "dora", "nome": "Leonor", "estilo": "Padrão do app, feminina", "kokoro": "pf_dora", "zonos": "Leonor_pt_F_1"}]
# frase da amostra de cada voz (uns 10 s): "Olá, eu sou o fulano..."
FRASE_DEMO = {
    "alex": "Posso narrar o seu vídeo, a sua apresentação ou o seu evento, sempre com clareza.",
    "dora": "Posso narrar o seu vídeo, a sua apresentação ou o seu evento, sempre com clareza.",
    "bruno": "Minha voz traz calma e confiança para o seu vídeo institucional.",
    "rafael": "Bora fazer um vídeo cheio de energia para as suas redes sociais?",
    "carlos": "Cada história merece ser contada com tempo, peso e verdade.",
    "marcos": "Aproveite! É só nesta semana, com preços que você nunca viu!",
    "paulo": "Vou contar essa história com calma, do jeitinho que ela merece.",
    "lucas": "E aí, tudo certo? Bora bater um papo sobre o seu projeto?",
    "helena": "Somos uma empresa que acredita em pessoas, resultados e confiança.",
    "camila": "Oi, gente! Hoje tem novidade, então fica até o final!",
    "beatriz": "Era uma vez um amor que começou com um simples olhar.",
    "marta": "Boa noite. Estas são as principais notícias de hoje.",
    "julia": "Respire fundo, solte os ombros e deixe o dia ficar mais leve.",
    "fernanda": "Vamos apresentar os resultados do trimestre e os próximos passos.",
}
TRAVA = threading.Lock()
_M = {}


def _modelo(nome):
    from mlx_audio.tts.utils import load_model
    if nome not in _M:
        _M.clear()
        _M[nome] = load_model(nome)
    return _M[nome]


def liberar():
    _M.clear()
    try:
        import gc
        import mlx.core as mx
        gc.collect()
        mx.clear_cache()
    except Exception:
        pass


def _acelerar(audio, sr, taxa):
    """Muda a velocidade sem o efeito robótico (atempo do ffmpeg, feito para voz)."""
    try:
        from dublar import acelerar
        return acelerar(audio, sr, taxa)
    except Exception:
        import librosa
        return librosa.effects.time_stretch(audio, rate=taxa)


def _juntar(resultados, padrao=24000):
    pedacos, sr = [], None
    for r in resultados:
        pedacos.append(np.array(r.audio, dtype=np.float32).reshape(-1))
        sr = getattr(r, "sample_rate", None) or sr
    return np.concatenate(pedacos) if pedacos else np.zeros(1, dtype=np.float32), int(sr or padrao)


# ------------------------------------------------------------------ texto --

def numeros_por_extenso(texto):
    try:
        from num2words import num2words
    except Exception:
        return texto

    def troca(m):
        bruto = m.group(0)
        try:
            if "," in bruto:
                inteiro, dec = bruto.replace(".", "").split(",")
                return num2words(int(inteiro), lang="pt_BR") + " vírgula " + " ".join(num2words(int(d), lang="pt_BR") for d in dec)
            return num2words(int(bruto.replace(".", "")), lang="pt_BR")
        except Exception:
            return bruto
    texto = re.sub(r"R\$\s*(\d[\d.]*)(?:,(\d{2}))?", lambda m: m.group(1) + " reais" + (f" e {m.group(2)} centavos" if m.group(2) and m.group(2) != "00" else ""), texto)
    texto = re.sub(r"(\d+)\s*%", r"\1 por cento", texto)
    return re.sub(r"\d{1,3}(?:\.\d{3})+(?:,\d+)?|\d+(?:,\d+)?", troca, texto)


PADRAO = {"emocao": 0.5, "estabilidade": 0.5, "semelhanca": 0.5, "velocidade": 1.0, "tom": 0.0,
          "clareza": 0.3, "pausa_frase": 0.28, "pausa_paragrafo": 0.75, "volume": -16.0, "semente": 0}
LIMITES = {"emocao": (0, 1), "estabilidade": (0, 1), "semelhanca": (0, 1), "velocidade": (0.7, 1.4), "tom": (-4, 4),
           "clareza": (0, 1), "pausa_frase": (0, 2), "pausa_paragrafo": (0, 4), "volume": (-24, -12), "semente": (0, 999999)}
RE_PAUSA = re.compile(r"\[\s*pausa\s*([\d.,]+)?\s*s?\s*\]", re.I)


def ajustes(d):
    """Completa e limita os ajustes vindos da tela."""
    r = {}
    for k, v in PADRAO.items():
        try:
            x = float((d or {}).get(k, v))
        except Exception:
            x = v
        lo, hi = LIMITES[k]
        r[k] = max(lo, min(hi, x))
    r["semente"] = int(r["semente"])
    return r


def aplicar_pronuncia(texto, dicionario):
    """dicionario = [{"de": "SILP", "para": "silpe"}]: troca palavras inteiras, sem diferenciar maiúsculas."""
    for item in dicionario or []:
        de, para = str(item.get("de", "")).strip(), str(item.get("para", "")).strip()
        if de and para:
            texto = re.sub(r"(?<![\wÀ-ÿ])" + re.escape(de) + r"(?![\wÀ-ÿ])", para, texto, flags=re.I)
    return texto


def dividir(texto):
    """Como _dividir, mas entende [pausa 1s] no meio do texto (vira silêncio depois do trecho)."""
    trechos, par_base = [], 0
    partes = RE_PAUSA.split(texto)          # texto, segundos, texto, segundos, ...
    for k in range(0, len(partes), 2):
        bloco = _dividir(partes[k])
        for t in bloco:
            t["paragrafo"] += par_base
        if bloco and k + 1 < len(partes):
            seg = partes[k + 1]
            bloco[-1]["pausa_depois"] = max(0.1, min(10.0, float(seg.replace(",", ".")) if seg else 1.0))
        if bloco:
            par_base = bloco[-1]["paragrafo"] + (1 if partes[k].rstrip(" ").endswith("\n") else 0)
        trechos += bloco
    return trechos


def _dividir(texto):
    """Devolve [{"texto", "paragrafo"}]: frases agrupadas até MAX_TRECHO caracteres."""
    trechos = []
    for p, par in enumerate([x.strip() for x in re.split(r"\n\s*\n|\n", texto) if x.strip()]):
        frases = re.split(r"(?<=[.!?…:;])\s+", par)
        atual = ""
        for f in frases:
            while len(f) > MAX_TRECHO:               # frase enorme: corta na vírgula ou no espaço
                corte = max(f.rfind(",", 0, MAX_TRECHO), f.rfind(" ", 0, MAX_TRECHO))
                corte = corte if corte > 40 else MAX_TRECHO
                if atual:
                    trechos.append({"texto": atual, "paragrafo": p})
                    atual = ""
                trechos.append({"texto": f[:corte + 1].strip(), "paragrafo": p})
                f = f[corte + 1:].strip()
            if len(atual) + len(f) + 1 > MAX_TRECHO and atual:
                trechos.append({"texto": atual, "paragrafo": p})
                atual = f
            else:
                atual = (atual + " " + f).strip()
        if atual:
            trechos.append({"texto": atual, "paragrafo": p})
    return trechos


# ------------------------------------------------------------------ vozes --

def listar_vozes(pasta_vozes):
    vozes = []
    for arq in sorted(Path(pasta_vozes).glob("*/voz.json")):
        try:
            vozes.append(json.loads(arq.read_text(encoding="utf-8")))
        except Exception:
            pass
    return sorted(vozes, key=lambda v: (v.get("tipo") != "pronta", v.get("nome", "")))


# Banco de vozes desenhadas (VoxCPM2 a partir de uma descrição: não é a voz de ninguém, pode vender)
VOZES_DESENHADAS = [
    {"id": "bruno", "nome": "Bruno", "estilo": "Locutor grave", "kokoro": "pm_alex",
     "desc": "Adult Brazilian man in his forties, deep warm baritone voice, calm and confident professional announcer, clear diction"},
    {"id": "rafael", "nome": "Rafael", "estilo": "Jovem animado", "kokoro": "pm_alex",
     "desc": "Young Brazilian man in his twenties, energetic, friendly and upbeat voice, social media presenter, smiling tone"},
    {"id": "carlos", "nome": "Carlos", "estilo": "Documentário", "kokoro": "pm_alex",
     "desc": "Mature Brazilian man in his fifties, serious and authoritative documentary narrator, slow and deliberate pace, rich low voice"},
    {"id": "marcos", "nome": "Marcos", "estilo": "Comercial de varejo", "kokoro": "pm_alex",
     "desc": "Brazilian man, enthusiastic retail commercial announcer, bright, punchy and fast, high energy"},
    {"id": "paulo", "nome": "Paulo", "estilo": "Senhor tranquilo", "kokoro": "pm_alex",
     "desc": "Older Brazilian man in his sixties, gentle grandfatherly voice, soft, warm and slow"},
    {"id": "lucas", "nome": "Lucas", "estilo": "Conversa de podcast", "kokoro": "pm_alex",
     "desc": "Brazilian man in his thirties, casual relaxed conversational voice, like a friendly podcast host"},
    {"id": "helena", "nome": "Helena", "estilo": "Institucional", "kokoro": "pf_dora",
     "desc": "Adult Brazilian woman in her forties, warm, elegant and trustworthy voice, corporate institutional narrator"},
    {"id": "camila", "nome": "Camila", "estilo": "Jovem animada", "kokoro": "pf_dora",
     "desc": "Young Brazilian woman in her twenties, cheerful, bright and energetic voice, social media style, smiling tone"},
    {"id": "beatriz", "nome": "Beatriz", "estilo": "Emocionante", "kokoro": "pf_dora",
     "desc": "Brazilian woman, soft, emotional and gentle voice, intimate and touching, wedding film narrator"},
    {"id": "marta", "nome": "Marta", "estilo": "Jornalista", "kokoro": "pf_dora",
     "desc": "Mature Brazilian woman in her fifties, serious, credible and firm news anchor voice"},
    {"id": "julia", "nome": "Júlia", "estilo": "Calma", "kokoro": "pf_dora",
     "desc": "Brazilian woman, calm, soothing and slow voice, meditation and wellness narrator, breathy and peaceful"},
    {"id": "fernanda", "nome": "Fernanda", "estilo": "Apresentação", "kokoro": "pf_dora",
     "desc": "Brazilian businesswoman in her thirties, confident, clear and dynamic presentation voice"},
]


GENEROS = {"homem": "man", "mulher": "woman"}
IDADES = {"jovem": "young {g} in their twenties", "adulto": "adult {g} in their thirties or forties",
          "maduro": "mature {g} in their fifties", "idoso": "older {g} in their sixties"}
TIMBRES = {"grave": "deep low-pitched voice", "medio": "medium-pitched voice", "agudo": "higher-pitched bright voice"}
ESTILOS_VOZ = {"locutor": "professional announcer, calm, confident and clear diction",
           "animado": "energetic, cheerful and upbeat, smiling tone",
           "calmo": "calm, soothing, slow and peaceful",
           "documentario": "serious documentary narrator, deliberate pace, rich voice",
           "jornalista": "credible, firm news anchor",
           "comercial": "enthusiastic retail commercial announcer, punchy and fast",
           "emocionante": "soft, emotional, intimate and touching",
           "conversa": "casual relaxed conversational voice, like a friendly podcast host",
           "institucional": "warm, elegant and trustworthy corporate narrator"}


def descricao_voz(genero, idade, timbre, estilo):
    g = GENEROS.get(genero, "man")
    return (f"Brazilian Portuguese speaker, {IDADES.get(idade, IDADES['adulto']).format(g=g)}, "
            f"{TIMBRES.get(timbre, TIMBRES['medio'])}, {ESTILOS_VOZ.get(estilo, ESTILOS_VOZ['locutor'])}")


ROTULOS = {"homem": "Homem", "mulher": "Mulher", "jovem": "jovem", "adulto": "adulto", "maduro": "maduro", "idoso": "mais velho",
           "grave": "grave", "medio": "médio", "agudo": "agudo", "locutor": "locutor", "animado": "animado", "calmo": "calmo",
           "documentario": "documentário", "jornalista": "jornalista", "comercial": "comercial", "emocionante": "emocionante",
           "conversa": "conversa", "institucional": "institucional"}


IDADE_F = {"jovem": "jovem", "adulto": "adulta", "maduro": "madura", "idoso": "mais velha"}


def eh_feminina(voz):
    return voz.get("kokoro") == "pf_dora"


def texto_demo(voz):
    nome = re.split(r"\s*[·(]", voz.get("nome", ""))[0].strip() or "a voz"
    artigo = "a" if eh_feminina(voz) else "o"
    extra = FRASE_DEMO.get(voz["id"], "Posso narrar o seu vídeo, a sua apresentação ou o seu evento.")
    return f"Olá, eu sou {artigo} {nome}, e esta é a minha voz. {extra}"


def gerar_demo(pasta_vozes, voz_id, forcar=False):
    """Amostra curta (uns 10 s, mp3 pequeno) para ouvir a voz antes de escolher."""
    import subprocess
    import tempfile
    from dublar import ffmpeg
    pasta = Path(pasta_vozes) / voz_id
    alvo = pasta / "demo.mp3"
    if alvo.exists() and not forcar:
        return alvo
    voz = json.loads((pasta / "voz.json").read_text(encoding="utf-8"))
    audio, sr = falar(texto_demo(voz), pasta / "voz.wav", ajustes({}), None, motor="voxcpm2")
    with tempfile.TemporaryDirectory() as d:
        wav = Path(d) / "demo.wav"
        sf.write(str(wav), audio, sr)
        subprocess.run([ffmpeg(), "-y", "-loglevel", "error", "-i", str(wav), "-ac", "1", "-b:a", "64k", str(alvo)], check=True)
    return alvo


def criar_voz_desenhada(pasta_vozes, nome, genero, idade, timbre, estilo):
    """Voz nova criada pela descrição: não é a voz de ninguém (pode usar em trabalho vendido)."""
    vid = re.sub(r"[^a-z0-9]+", "-", nome.lower()).strip("-")[:30] or "voz"
    vid = f"{vid}-{int(time.time()) % 100000}"
    v = {"id": vid, "nome": nome, "kokoro": "pf_dora" if genero == "mulher" else "pm_alex",
         "desc": descricao_voz(genero, idade, timbre, estilo),
         "estilo": f"{ROTULOS.get(genero, '')} {IDADE_F.get(idade) if genero == 'mulher' else ROTULOS.get(idade, '')}, "
                   f"{ROTULOS.get(timbre, '')}, {ROTULOS.get(estilo, '')}"}
    desenhar_voz(pasta_vozes, v, tipo="criada")
    return json.loads((Path(pasta_vozes) / vid / "voz.json").read_text(encoding="utf-8"))


def desenhar_voz(pasta_vozes, v, frase=None, tipo="pronta"):
    """Cria a voz de referência a partir da descrição (VoxCPM2) e guarda como voz pronta."""
    import librosa
    dest = Path(pasta_vozes) / v["id"]
    dest.mkdir(parents=True, exist_ok=True)
    with TRAVA:
        audio, sr = _juntar(_modelo(MODELO_VOX).generate(text=frase or FRASE_REF, instruct=v["desc"],
                                                         inference_timesteps=PASSOS_VOX), padrao=48000)
    audio, _ = librosa.effects.trim(audio, top_db=40)
    if sr != SR_SAIDA:
        audio = librosa.resample(audio, orig_sr=sr, target_sr=SR_SAIDA)
    audio = audio / (np.abs(audio).max() + 1e-9) * 0.9
    sf.write(str(dest / "voz.wav"), audio.astype(np.float32), SR_SAIDA, subtype="PCM_16")
    (dest / "voz.json").write_text(json.dumps({"id": v["id"], "nome": v["nome"], "tipo": tipo, "origem": "desenhada",
                                               "kokoro": v.get("kokoro"), "descricao": v["desc"],
                                               "estilo": v.get("estilo", "")}, ensure_ascii=False),
                                   encoding="utf-8")
    return dest / "voz.wav"


def garantir_vozes_desenhadas(pasta_vozes, aviso=None):
    for k, v in enumerate(VOZES_DESENHADAS):
        if not (Path(pasta_vozes) / v["id"] / "voz.wav").exists():
            if aviso:
                aviso(k / len(VOZES_DESENHADAS), v["nome"])
            desenhar_voz(pasta_vozes, v)


def atualizar_vozes_padrao(pasta_vozes):
    """Vozes antigas: completa nome curto, estilo e voz rápida no voz.json (sem refazer o áudio)."""
    for v in VOZES_PADRAO + VOZES_DESENHADAS:
        arq = Path(pasta_vozes) / v["id"] / "voz.json"
        if not arq.exists():
            continue
        d = json.loads(arq.read_text(encoding="utf-8"))
        novo = {**d, "nome": v["nome"], "estilo": v.get("estilo", ""), "kokoro": v.get("kokoro")}
        if v.get("zonos") and d.get("zonos") != v["zonos"] and _virar_voz_de_fabrica(arq.parent, v["zonos"]):
            novo["zonos"] = v["zonos"]
        if novo != d:
            arq.write_text(json.dumps(novo, ensure_ascii=False), encoding="utf-8")


def _virar_voz_de_fabrica(dest, nome):
    """Alex e Dora (vozes sintéticas antigas) viram Thiago e Leonor, vozes de fábrica do ZONOS3:
    a mesma pessoa no modo rápido (ZONOS3) e no caprichado (VoxCPM2 usa o voz.wav como referência)."""
    try:
        import librosa
        import zonos
        wav, emb = zonos.wav_fabrica(nome), zonos.embedding_fabrica(nome)
        if not wav or not emb:
            return False
        y, _ = librosa.load(str(wav), sr=SR_SAIDA, mono=True, duration=30)
        y, _ = librosa.effects.trim(y, top_db=35)
        y = y / (np.abs(y).max() + 1e-9) * 0.9
        sf.write(str(dest / "voz.wav"), y.astype(np.float32), SR_SAIDA, subtype="PCM_16")
        import shutil
        shutil.copyfile(emb, dest / "zonos.npy")
        (dest / "demo.mp3").unlink(missing_ok=True)       # a amostra é refeita com a voz nova
        return True
    except Exception as e:
        print("não consegui trocar a voz de fábrica:", e, flush=True)
        return False


def kokoro_da_voz(pasta_vozes, voz_id):
    """Qual voz rápida (Kokoro) combina com esta voz: homem -> Alex, mulher -> Dora."""
    if voz_id in KOKORO_DA_PESSOA:
        return KOKORO_DA_PESSOA[voz_id]
    try:
        return json.loads((Path(pasta_vozes) / voz_id / "voz.json").read_text(encoding="utf-8")).get("kokoro")
    except Exception:
        return None


def garantir_vozes_padrao(pasta_vozes):
    """Cria as vozes prontas na primeira vez (referências sintéticas, sem voz de ninguém)."""
    pasta_vozes = Path(pasta_vozes)
    for v in VOZES_PADRAO:
        dest = pasta_vozes / v["id"]
        if (dest / "voz.wav").exists():
            continue
        dest.mkdir(parents=True, exist_ok=True)
        fabrica = v.get("zonos") and _virar_voz_de_fabrica(dest, v["zonos"])
        if not fabrica:
            with TRAVA:
                audio, sr = _juntar(_modelo(MODELO_VOZES).generate(text=FRASE_REF, voice=v["kokoro"], speed=1.0, lang_code="p"))
            sf.write(str(dest / "voz.wav"), audio, sr, subtype="PCM_16")
        (dest / "voz.json").write_text(json.dumps({"id": v["id"], "nome": v["nome"], "tipo": "pronta", "estilo": v["estilo"],
                                               "kokoro": v["kokoro"], **({"zonos": v["zonos"]} if fabrica else {})},
                                              ensure_ascii=False), encoding="utf-8")


def criar_voz_clonada(pasta_vozes, nome, arquivo_origem):
    """Guarda até 30 s da gravação como referência. Só com autorização do dono da voz."""
    import librosa
    y, _ = librosa.load(str(arquivo_origem), sr=SR_SAIDA, mono=True, duration=60)
    y, _ = librosa.effects.trim(y, top_db=35)
    if len(y) < SR_SAIDA * 5:
        raise ValueError("A gravação precisa ter pelo menos 5 segundos de fala. O ideal é de 15 a 30 segundos.")
    y = y[:SR_SAIDA * 30]
    y = y / (np.abs(y).max() + 1e-9) * 0.9
    vid = re.sub(r"[^a-z0-9]+", "-", nome.lower()).strip("-")[:30] or "voz"
    vid = f"{vid}-{int(time.time()) % 100000}"
    dest = Path(pasta_vozes) / vid
    dest.mkdir(parents=True, exist_ok=True)
    sf.write(str(dest / "voz.wav"), y, SR_SAIDA, subtype="PCM_16")
    voz = {"id": vid, "nome": nome.strip()[:40] or "Minha voz", "tipo": "clonada", "estilo": "Voz clonada",
           "segundos": round(len(y) / SR_SAIDA, 1)}
    (dest / "voz.json").write_text(json.dumps(voz, ensure_ascii=False), encoding="utf-8")
    return voz


# ------------------------------------------------------------------ gerar --

# Estilo da locução: a voz natural (VoxCPM2) recebe a instrução junto da voz escolhida;
# a voz rápida (ZONOS3) só tem ritmo da fala (letras por segundo) como controle.
ESTILOS = {
    "neutro": None,
    "institucional": "calm, confident corporate narrator, clear and professional, steady medium pace",
    "comercial": "energetic retail commercial announcer, upbeat and enthusiastic",
    "documentario": "deep, serious documentary narrator, slow and thoughtful, with gravitas",
    "emocionante": "emotional, warm and heartfelt storyteller, gentle and moving",
    "noticia": "television news anchor, neutral, precise and authoritative",
    "calma": "soft, calm and soothing voice, slow relaxed pace",
    "conversa": "casual, friendly conversational tone, natural like a podcast host",
    "casamento": "tender, romantic and emotional wedding narrator, warm and intimate",
    "reels": "lively, fast and catchy social media voice, high energy",
}
RITMO_ZONOS = {"calma": 11.0, "documentario": 11.5, "emocionante": 12.0, "casamento": 12.0, "institucional": 13.5,
               "conversa": 14.0, "noticia": 14.5, "comercial": 16.5, "reels": 17.5}


def instrucao(estilo=None, direcao="", emocao=0.5):
    """Texto de direção para a voz natural: estilo + intensidade + o que você escreveu (opcional)."""
    partes = []
    if ESTILOS.get(estilo or ""):
        partes.append(ESTILOS[estilo])
    if emocao >= 0.75:
        partes.append("very expressive")
    elif emocao <= 0.25:
        partes.append("restrained and understated")
    d = re.sub(r"[()]", " ", str(direcao or "")).strip()
    if d:
        partes.append(d[:200])
    return ", ".join(partes) or None


def falar(texto, ref_wav, aj, dicionario=None, motor="chatterbox", passos=None, estilo=None, direcao=""):
    """Um trecho -> (áudio mono float32, sr). `aj` vem de ajustes(). motor: "voxcpm2", "zonos3" ou "chatterbox"."""
    import librosa
    texto = numeros_por_extenso(aplicar_pronuncia(texto, dicionario))
    if motor == "zonos3":
        import zonos
        extra = {"condition_values": {"speaking_rate": RITMO_ZONOS[estilo]}} if estilo in RITMO_ZONOS else None
        audio, sr = zonos.falar(texto, Path(ref_wav).parent, semente=int(aj.get("semente") or 7), extra=extra)
        if abs(aj.get("velocidade", 1.0) - 1.0) > 0.02:
            audio = _acelerar(audio, sr, float(aj["velocidade"]))
        if abs(aj.get("tom", 0)) > 0.05:
            audio = librosa.effects.pitch_shift(audio, sr=sr, n_steps=float(aj["tom"]))
        audio, _ = librosa.effects.trim(audio, top_db=40)
        if sr != SR_SAIDA:
            audio = librosa.resample(audio, orig_sr=sr, target_sr=SR_SAIDA)
        return audio.astype(np.float32), SR_SAIDA
    if motor == "voxcpm2":
        with TRAVA:
            m = _modelo(MODELO_VOX)
            if aj.get("semente"):
                try:
                    import mlx.core as mx
                    mx.random.seed(int(aj["semente"]))
                except Exception:
                    pass
            audio, sr = _juntar(m.generate(text=texto, ref_audio=str(ref_wav), inference_timesteps=int(passos or PASSOS_VOX),
                                           cfg_value=float(1.6 + 0.8 * aj.get("semelhanca", 0.5)),
                                           instruct=instrucao(estilo, direcao, aj.get("emocao", 0.5))), padrao=48000)
        if abs(aj.get("velocidade", 1.0) - 1.0) > 0.02:
            audio = _acelerar(audio, sr, float(aj["velocidade"]))
        if abs(aj.get("tom", 0)) > 0.05:
            audio = librosa.effects.pitch_shift(audio, sr=sr, n_steps=float(aj["tom"]))
        audio, _ = librosa.effects.trim(audio, top_db=40)
        if sr != SR_SAIDA:
            audio = librosa.resample(audio, orig_sr=sr, target_sr=SR_SAIDA)
        return audio.astype(np.float32), SR_SAIDA
    # estabilidade alta = voz mais constante (temperatura baixa); semelhança = aderência à voz de referência
    temperatura = 1.15 - 0.75 * aj["estabilidade"]
    cfg = 0.2 + 0.6 * aj["semelhanca"]
    with TRAVA:
        m = _modelo(MODELO)
        if aj["semente"]:
            try:
                import mlx.core as mx
                mx.random.seed(int(aj["semente"]))
            except Exception:
                pass
        audio, sr = _juntar(m.generate(text=texto, ref_audio=str(ref_wav), lang_code="pt",
                                       exaggeration=float(aj["emocao"]), cfg_weight=float(cfg),
                                       temperature=float(temperatura), verbose=False))
    if abs(aj["velocidade"] - 1.0) > 0.02:
        audio = _acelerar(audio, sr, float(aj["velocidade"]))
    if abs(aj["tom"]) > 0.05:
        audio = librosa.effects.pitch_shift(audio, sr=sr, n_steps=float(aj["tom"]))
    audio, _ = librosa.effects.trim(audio, top_db=40)
    if sr != SR_SAIDA:
        audio = librosa.resample(audio, orig_sr=sr, target_sr=SR_SAIDA)
    return audio.astype(np.float32), SR_SAIDA


VOZES_RAPIDAS = {"rapida-alex": ("pm_alex", "Thiago rápido (masculina)"), "rapida-dora": ("pf_dora", "Leonor rápida (feminina)")}
KOKORO_DA_PESSOA = {"alex": "pm_alex", "dora": "pf_dora"}     # mesma pessoa na voz rápida


VOZ_DO_KOKORO = {"pm_alex": "alex", "pf_dora": "dora"}      # extensão e testes antigos: voz rápida -> voz do app


def motor_rapido():
    """Qual motor faz a voz rápida agora: "zonos3" (natural) ou "kokoro" (reserva)."""
    try:
        import zonos
        return "zonos3" if zonos.disponivel() else "kokoro"
    except Exception:
        return "kokoro"


def falar_rapida(texto, voz_kokoro, velocidade=1.0, dicionario=None, voz_dir=None, motor="auto"):
    """Voz rápida. ZONOS3 leve com a impressão digital da voz escolhida (natural, 1 a 2 s por frase);
    Kokoro como reserva (bem mais rápido, mas robótico) se o ZONOS3 não estiver instalado ou falhar."""
    import librosa
    texto = numeros_por_extenso(aplicar_pronuncia(texto, dicionario))
    if motor in ("auto", "zonos3"):
        if voz_dir is None and voz_kokoro in VOZ_DO_KOKORO:
            voz_dir = Path(__file__).resolve().parent.parent / "Vozes" / VOZ_DO_KOKORO[voz_kokoro]
        try:
            import zonos
            if voz_dir is not None and zonos.disponivel():
                audio, sr = zonos.falar(texto, voz_dir)
                if abs(float(velocidade) - 1.0) > 0.02:
                    audio = _acelerar(audio, sr, float(velocidade))
                audio, _ = librosa.effects.trim(audio, top_db=40)
                if sr != SR_SAIDA:
                    audio = librosa.resample(audio, orig_sr=sr, target_sr=SR_SAIDA)
                return audio.astype(np.float32), SR_SAIDA
        except Exception as e:
            print("voz rápida ZONOS3 falhou, usando Kokoro:", e, flush=True)
    with TRAVA:
        audio, sr = _juntar(_modelo(MODELO_VOZES).generate(text=texto, voice=voz_kokoro, speed=float(velocidade), lang_code="p"))
    audio, _ = librosa.effects.trim(audio, top_db=40)
    if sr != SR_SAIDA:
        audio = librosa.resample(audio, orig_sr=sr, target_sr=SR_SAIDA)
    return audio.astype(np.float32), SR_SAIDA


def clarear(audio, quanto):
    """Reforço do locutor: tira o grave que embola, dá presença e brilho, segura os picos."""
    if quanto <= 0.01:
        return audio
    from scipy.signal import butter, sosfilt
    y = sosfilt(butter(2, 75, "highpass", fs=SR_SAIDA, output="sos"), audio)
    presenca = sosfilt(butter(2, [2500, 5500], "bandpass", fs=SR_SAIDA, output="sos"), y)
    brilho = sosfilt(butter(2, 7000, "highpass", fs=SR_SAIDA, output="sos"), y)
    y = y + quanto * (0.55 * presenca + 0.35 * brilho)
    limiar = 0.5
    acima = np.abs(y) > limiar                      # compressão suave dos picos
    y[acima] = np.sign(y[acima]) * (limiar + (np.abs(y[acima]) - limiar) / (1 + 2 * quanto))
    return y.astype(np.float32)


def montar(pasta, trechos, aj):
    """Junta os trechos prontos em narracao.wav, com pausas, clareza e volume padronizado."""
    partes, anterior, pausa_extra = [], None, 0.0
    for t in trechos:
        arq = Path(pasta) / (t.get("arquivo") or "_")
        if not t.get("arquivo") or not arq.exists():
            continue
        y, _ = sf.read(str(arq), dtype="float32")
        if anterior is not None:
            pausa = aj["pausa_paragrafo"] if t["paragrafo"] != anterior else aj["pausa_frase"]
            partes.append(np.zeros(int(SR_SAIDA * max(pausa, pausa_extra)), dtype=np.float32))
        partes.append(y)
        anterior = t["paragrafo"]
        pausa_extra = float(t.get("pausa_depois") or 0.0)
    if not partes:
        return None
    audio = clarear(np.concatenate(partes), aj["clareza"])
    try:
        import pyloudnorm as pyln
        medidor = pyln.Meter(SR_SAIDA)
        audio = pyln.normalize.loudness(audio, medidor.integrated_loudness(audio), float(aj["volume"]))
    except Exception:
        pass
    pico = np.abs(audio).max()
    if pico > 0.97:
        audio = audio * (0.97 / pico)
    final = Path(pasta) / "narracao.wav"
    sf.write(str(final), audio, SR_SAIDA, subtype="PCM_24")
    return {"arquivo": final.name, "duracao": round(len(audio) / SR_SAIDA, 1)}


def gerar_trecho(pasta, trecho, indice, ref_wav, aj, dicionario=None, motor="chatterbox", estilo=None, direcao=""):
    """Gera (ou refaz) um trecho. A versão anterior fica guardada para o botão Voltar."""
    audio, sr = falar(trecho["texto"], ref_wav, aj, dicionario, motor=motor, estilo=estilo, direcao=direcao)
    nome = f"trecho_{indice:03d}_{int(time.time() * 10) % 1000000}.wav"
    sf.write(str(Path(pasta) / nome), audio, sr, subtype="PCM_16")
    velho = trecho.get("anterior")
    if velho and velho.get("arquivo"):
        (Path(pasta) / velho["arquivo"]).unlink(missing_ok=True)
    if trecho.get("arquivo"):
        trecho["anterior"] = {"arquivo": trecho["arquivo"], "duracao": trecho.get("duracao"), "texto": trecho.get("texto_gerado", trecho["texto"])}
    trecho["arquivo"] = nome
    trecho["texto_gerado"] = trecho["texto"]
    trecho["duracao"] = round(len(audio) / sr, 1)
    return trecho


def voltar_trecho(trecho):
    """Troca a versão atual pela anterior (e vice-versa)."""
    ant = trecho.get("anterior")
    if not ant:
        return trecho
    atual = {"arquivo": trecho["arquivo"], "duracao": trecho.get("duracao"), "texto": trecho["texto"]}
    trecho.update({"arquivo": ant["arquivo"], "duracao": ant.get("duracao"), "texto": ant.get("texto", trecho["texto"])})
    trecho["texto_gerado"] = trecho["texto"]
    trecho["anterior"] = atual
    return trecho
