"""
Porteiro dos servidores locais do app (8790 e 8791).

Os servidores só escutam em 127.0.0.1, mas qualquer site aberto no navegador consegue MANDAR pedidos para
127.0.0.1. Sem este porteiro, uma página mal-intencionada poderia colocar downloads na fila, apagar vozes ou
abrir links. Aqui só passa quem é de casa: a janela do próprio app, a extensão Multi Estúdio e programas do
próprio computador (que não mandam "Origin").
"""
ID_EXTENSAO = "eghenmidbnmlmghehpnbipbdoecgcpkp"      # fixo pela chave ("key") no manifest.json da extensão
CASAS = ("127.0.0.1", "localhost", "[::1]")


def permitido(cabecalhos):
    """True se o pedido vem do app, da extensão ou de um programa local. `cabecalhos` = self.headers."""
    host = (cabecalhos.get("Host") or "").strip().lower()
    nome = host.rsplit(":", 1)[0] if host.count(":") == 1 or host.startswith("[") else host
    if nome not in CASAS:                    # outro nome apontando para cá (truque de DNS): recusa
        return False
    origem = (cabecalhos.get("Origin") or "").strip().lower()
    if not origem:                           # a janela do app (GET) e programas locais não mandam Origin
        return True
    if origem == f"chrome-extension://{ID_EXTENSAO}":
        return True
    semporta = origem.split("://", 1)[-1].rsplit(":", 1)[0] if origem.startswith("http://") else ""
    return semporta in CASAS
