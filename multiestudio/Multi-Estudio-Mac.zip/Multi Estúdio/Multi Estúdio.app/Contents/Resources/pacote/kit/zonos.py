"""
Voz rápida: ZONOS3-Mini (Apache 2.0, Zyphra), na versão leve (sem as peças de clonar fiel).

Roda num servidor local escondido (127.0.0.1:1919) que liga sozinho no primeiro uso e desliga
depois de 10 minutos parado. Cada voz do app vira uma "impressão digital" (Vozes/<id>/zonos.npy),
calculada uma vez a partir do voz.wav. Thiago e Leonor são as vozes de fábrica em português.
Se o motor não estiver instalado ou falhar, quem chama volta para o Kokoro.
"""
import atexit
import base64
import io
import json
import os
import shutil
import signal
import subprocess
import threading
import time
import urllib.request
import uuid
from pathlib import Path

import numpy as np

BASE = Path(__file__).resolve().parent.parent
PASTAS = [BASE / "motores" / "zonos3", BASE / "testes" / "zonos3"]
URL = "http://127.0.0.1:1919"
OCIOSO = 600                       # desliga sozinho depois de 10 min sem uso (libera uns 3 GB de memória)
FABRICA = {"Thiago_pt_M_1": "Portuguese/Thiago_pt_M_1", "Leonor_pt_F_1": "Portuguese/Leonor_pt_F_1"}
SESSAO = uuid.uuid4().hex
_TRAVA = threading.Lock()
_E = {"proc": None, "falhou": 0.0, "vigia": False}


def pasta():
    for p in PASTAS:
        if (p / "servers" / "ggml" / "gguf" / "backbone-ptq.gguf").exists() and (p / ".venv").exists():
            return p
    return None


def instalado():
    return pasta() is not None


def disponivel():
    """Instalado e sem falha no último minuto."""
    return instalado() and time.time() - _E["falhou"] > 60


def _marcar_uso():
    p = pasta()
    if p:
        try:
            (p / ".ultimo_uso").write_text(str(time.time()))
        except Exception:
            pass


def _ultimo_uso():
    p = pasta()
    try:
        return float((p / ".ultimo_uso").read_text())
    except Exception:
        return 0.0


def _ambiente():
    amb = dict(os.environ, PATH=f"{Path.home()}/.local/bin:/opt/homebrew/bin:/usr/local/bin:" + os.environ.get("PATH", ""))
    try:
        import imageio_ffmpeg
        amb["ZONOS3_FFMPEG"] = imageio_ffmpeg.get_ffmpeg_exe()
        amb["PATH"] = str(Path(amb["ZONOS3_FFMPEG"]).parent) + ":" + amb["PATH"]
    except Exception:
        ff = shutil.which("ffmpeg", path=amb["PATH"])
        if ff:
            amb["ZONOS3_FFMPEG"] = ff
    amb.pop("VIRTUAL_ENV", None)             # o servidor usa o ambiente dele, não o do app
    amb.pop("PYTHONPATH", None)
    amb.pop("PYTHONHOME", None)
    return amb


def vivo(timeout=6):
    try:
        urllib.request.urlopen(URL + "/v2/health", timeout=timeout)
        return True
    except Exception:
        return False


def _porta_ocupada():
    import socket
    s = socket.socket()
    s.settimeout(1)
    try:
        s.connect(("127.0.0.1", 1919))
        return True
    except Exception:
        return False
    finally:
        s.close()


def ligar(espera=240):
    """Liga o servidor (se já estiver ligado, só usa). Devolve True quando está pronto."""
    with _TRAVA:
        _marcar_uso()
        if vivo():
            return True
        p = pasta()
        if not p:
            return False
        if _porta_ocupada():
            # já tem servidor (de outro processo do app), só ocupado ou ligando: espera por ele, não liga outro
            fim = time.time() + espera
            while time.time() < fim:
                if vivo(10):
                    return True
                time.sleep(2)
            _E["falhou"] = time.time()
            return False
        pr = _E["proc"]
        if pr is None or pr.poll() is not None:
            log = open(p / "servidor.log", "w")
            _E["proc"] = subprocess.Popen(["bash", "servers/mlx/scripts/serve.sh"], cwd=str(p), env=_ambiente(),
                                          stdout=log, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL,
                                          start_new_session=True)
        fim = time.time() + espera
        while time.time() < fim:
            time.sleep(1)
            if vivo():
                _vigiar()
                return True
            if _E["proc"].poll() is not None:
                break
        _E["falhou"] = time.time()
        _parar()
        return False


def _parar():
    pr = _E.get("proc")
    if pr and pr.poll() is None:
        try:
            os.killpg(pr.pid, signal.SIGTERM)
            pr.wait(timeout=15)
        except Exception:
            try:
                os.killpg(pr.pid, signal.SIGKILL)
            except Exception:
                pass
    _E["proc"] = None


def desligar():
    with _TRAVA:
        _parar()


def _vigiar():
    if _E["vigia"]:
        return
    _E["vigia"] = True

    def laco():
        while True:
            time.sleep(30)
            pr = _E.get("proc")
            if pr is None or pr.poll() is not None:
                break
            if time.time() - _ultimo_uso() > OCIOSO:
                desligar()
                break
        _E["vigia"] = False

    threading.Thread(target=laco, daemon=True).start()


atexit.register(_parar)


def _pedir(caminho, corpo=None, timeout=300):
    dados = json.dumps(corpo).encode() if corpo is not None else None
    req = urllib.request.Request(URL + caminho, data=dados, headers={"Content-Type": "application/json",
                                                                       "X-TTS-Session-ID": SESSAO})
    return urllib.request.urlopen(req, timeout=timeout).read()


def embedding_fabrica(nome):
    p = pasta()
    if not p or nome not in FABRICA:
        return None
    arq = p / "servers" / "ggml" / "gguf" / "voices" / f"{FABRICA[nome]}.embedding.npy"
    return arq if arq.exists() else None


def wav_fabrica(nome):
    p = pasta()
    if not p or nome not in FABRICA:
        return None
    arq = p / "servers" / "ggml" / "gguf" / "voices" / f"{FABRICA[nome]}.wav"
    return arq if arq.exists() else None


def impressao(voz_dir):
    """zonos.npy da voz: de fábrica (Thiago, Leonor) ou calculada uma vez a partir do voz.wav."""
    voz_dir = Path(voz_dir)
    arq = voz_dir / "zonos.npy"
    ref = voz_dir / "voz.wav"
    if arq.exists() and (not ref.exists() or arq.stat().st_mtime >= ref.stat().st_mtime - 1):
        return arq
    try:
        fab = json.loads((voz_dir / "voz.json").read_text(encoding="utf-8")).get("zonos")
    except Exception:
        fab = None
    if fab and embedding_fabrica(fab):
        shutil.copyfile(embedding_fabrica(fab), arq)
        return arq
    if not ref.exists() or not ligar():
        return None
    if _E.get("erro_impressao"):         # este servidor não guarda impressão: usa a gravação direto (funciona igual)
        return ref
    try:
        r = json.loads(_pedir("/v2/speakers", {"speaker_audio_base64": base64.b64encode(ref.read_bytes()).decode(),
                                              "speaker_audio_name": "voz.wav", "label": voz_dir.name}, 120))
        sid = r.get("id") or r.get("speaker_id")
        vec = json.loads(_pedir(f"/v2/speakers/{sid}/embedding", None, 60))["embedding"]
        np.save(str(arq), np.asarray(vec, dtype=np.float32))
        return arq
    except Exception as e:
        det = getattr(e, "read", lambda: b"")().decode("utf-8", "ignore")[:300]
        print("impressão digital guardada falhou, uso a gravação direto:", e, det, flush=True)
        _E["erro_impressao"] = f"{e} {det}"
        return ref                       # o servidor tira a impressão digital da gravação a cada fala


def falar(texto, voz_dir, semente=7, extra=None):
    """Um trecho -> (áudio mono float32, sr). Erro sobe para quem chamou decidir (voltar para o Kokoro)."""
    import soundfile as sf
    if not ligar():
        raise RuntimeError("O motor de voz rápida não ligou.")
    emb = impressao(voz_dir)
    if emb is None:
        raise RuntimeError("Sem impressão digital para esta voz.")
    corpo = {"text": texto, "language": "pt_br", "stream": False, "format": "wav", "speaker_mode": "embedding"}
    if Path(emb).suffix == ".npy":
        corpo.update({"speaker_embedding_base64": base64.b64encode(Path(emb).read_bytes()).decode(),
                      "speaker_embedding_name": "zonos.npy"})
    else:
        corpo["speaker_audio_base64"] = base64.b64encode(Path(emb).read_bytes()).decode()
    if semente is not None:
        corpo["seed"] = int(semente)
    if extra:
        corpo.update(extra)
    ultimo = None
    for tentativa in range(2):
        try:
            dados = _pedir("/v2/generate", corpo, 300)
            _marcar_uso()
            audio, sr = sf.read(io.BytesIO(dados), dtype="float32")
            if audio.ndim > 1:
                audio = audio.mean(1)
            return audio, sr
        except Exception as e:
            ultimo = e
            if tentativa == 0 and not vivo():          # servidor caiu: liga de novo e tenta mais uma vez
                ligar()
    raise RuntimeError(f"A voz rápida falhou: {ultimo}")
