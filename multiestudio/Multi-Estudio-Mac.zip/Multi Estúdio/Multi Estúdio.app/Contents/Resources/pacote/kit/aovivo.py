"""
Dublagem ao vivo para a extensão do Chrome (porta 8791, só no próprio Mac).

A extensão manda as palavras com tempo (legenda automática do próprio YouTube, pega pelo player
que já está aberto no Chrome; nada é baixado de novo). Aqui as falas são montadas, traduzidas
(IA rápida) e narradas (voz rápida Kokoro) na frente do ponto em que o vídeo está, e a
extensão toca cada fala na hora certa, abaixando o som original.

Roda num processo separado do app: não disputa a IA com a fila de dublagem e sai sozinho
depois de 15 min sem uso (libera a memória). O que já foi feito fica guardado: assistir o
mesmo vídeo de novo é instantâneo.
"""
import hashlib
import json
import re
import sys
import threading
import time
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

KIT = Path(__file__).resolve().parent
sys.path.insert(0, str(KIT))
BASE = KIT.parent
PASTA = BASE / "Projetos" / "aovivo"
PORTA = 8791
OCIOSO_S = 15 * 60
VOZES = {"pm_alex", "pf_dora", "pm_santa"}      # pm_alex = Thiago, pf_dora = Leonor (com o ZONOS3)
PARALELO = 3

import guarda  # noqa: E402
import soundfile as sf  # noqa: E402

_SESSOES = {}
_TRAVA = threading.Lock()
_ESTADO = {"ultimo_uso": time.time(), "trabalhando": None, "msg": ""}


def _id_seguro(t):
    return re.sub(r"[^A-Za-z0-9_-]", "", str(t))[:40] or "video"


class Sessao:
    def __init__(self, video, titulo, idioma, palavras, voz):
        self.video = _id_seguro(video)
        self.titulo = str(titulo or "")[:200]
        self.idioma = str(idioma or "")[:12]
        self.voz = voz if voz in VOZES else "pm_alex"
        self.foco = 0.0
        self.versao = 0
        self.erro = ""
        import narrar
        self.motor = narrar.motor_rapido()          # ZONOS3 (natural) ou Kokoro (reserva)
        assinatura = hashlib.md5(json.dumps([palavras[:50], len(palavras), self.voz, self.motor]).encode()).hexdigest()[:10]
        self.pasta = PASTA / f"{self.video}-{assinatura}"
        self.pasta.mkdir(parents=True, exist_ok=True)
        arq = self.pasta / "falas.json"
        if arq.exists():
            self.segs = json.loads(arq.read_text(encoding="utf-8"))
            for s in self.segs:                       # áudio já feito antes: vale de novo
                s["ok"] = bool(s.get("ok")) and (self.pasta / f"{s['i']:04d}.wav").exists()
                s["v"] = 1 if s["ok"] else 0
            self.versao = 1
        else:
            self.segs = montar_falas(palavras)
            self._salvar()

    def _salvar(self):
        (self.pasta / "falas.json").write_text(json.dumps(self.segs, ensure_ascii=False), encoding="utf-8")

    def proximas(self, n):
        """As próximas falas sem dublagem a partir de onde o vídeo está (um pouco antes também)."""
        alvo = [s for s in self.segs if not s.get("ok") and s["fim"] >= self.foco - 1.0]
        alvo.sort(key=lambda s: s["ini"])
        return alvo[:n]

    def pendente(self):
        return any(not s.get("ok") for s in self.segs)


def montar_falas(palavras):
    """Palavras com tempo -> falas de até 7 s cortadas nas pausas (mesmo jeito da dublagem do app)."""
    import dublar
    ws = [{"word": " " + str(p.get("w", "")).strip(), "start": float(p.get("s", 0)), "end": float(p.get("e", 0))}
          for p in palavras if str(p.get("w", "")).strip()]
    ws.sort(key=lambda w: w["start"])
    frases = dublar.frases_por_palavras(ws) if ws else []
    return [{"i": i, "ini": round(f["ini"], 2), "fim": round(f["fim"], 2), "texto": f["texto"], "pt": "", "ok": False, "v": 0}
            for i, f in enumerate(frases)]


# ------------------------------------------------------------------ trabalho --

def trabalhar():
    """Um único trabalhador: atende primeiro o vídeo que foi usado por último, perto de onde ele está."""
    import dublar
    import narrar
    import traduzir
    traduzir.MODELOS_TRADUCAO = list(traduzir.MODELOS_RAPIDOS)   # ao vivo: tradução ligeira
    dicionario = dublar.ler_dicionario(BASE / "Projetos" / "x")     # sua lista + a lista brasileira do app
    while True:
        try:
            with _TRAVA:
                vivas = sorted(_SESSOES.values(), key=lambda s: -getattr(s, "uso", 0))
            sessao = next((s for s in vivas if s.pendente()), None)
            if not sessao:
                _ESTADO["trabalhando"] = None
                time.sleep(0.3)
                continue
            _ESTADO["trabalhando"] = sessao.video
            lote = sessao.proximas(6 if sessao.versao else 3)     # o primeiro lote é menor: começa a falar antes
            if not lote:
                time.sleep(0.3)
                continue
            sem_pt = [s for s in lote if not s.get("pt")]
            if sem_pt:
                if traduzir._T.get("modelo") is None:
                    _ESTADO["msg"] = "Carregando a tradução"
                textos = traduzir_lote(traduzir, sessao, sem_pt)
                for s, t in zip(sem_pt, textos):
                    s["pt"] = t.strip() or s["texto"]
                _ESTADO["msg"] = ""
            faltam = [s for s in lote if not s.get("ok")]

            def fazer(s):
                return narrar.falar_rapida(s["pt"], sessao.voz, 1.0, dicionario, motor=sessao.motor)
            if sessao.motor == "zonos3" and len(faltam) > 1:
                # o servidor do ZONOS3 atende várias falas ao mesmo tempo: o lote fica pronto bem antes
                from concurrent.futures import ThreadPoolExecutor
                with ThreadPoolExecutor(PARALELO) as ex:
                    feitos = list(ex.map(fazer, faltam))
            else:
                feitos = [fazer(s) for s in faltam]
            for s, (audio, sr) in zip(faltam, feitos):
                audio, _taxa, _cortou = dublar.encaixar(audio, sr, _disponivel(sessao, s), s["fim"] - s["ini"])
                sf.write(str(sessao.pasta / f"{s['i']:04d}.wav"), audio, sr, subtype="PCM_16")
                sessao.versao += 1
                s["ok"], s["v"], s["dur"] = True, sessao.versao, round(len(audio) / sr, 2)
            sessao._salvar()
        except Exception as e:
            traceback.print_exc()
            _ESTADO["msg"] = f"Erro: {str(e)[:160]}"
            time.sleep(2)


def traduzir_lote(traduzir, sessao, itens):
    """Mesma instrução da dublagem do app, com as 3 falas anteriores como contexto."""
    primeiro = min(x["i"] for x in itens)
    antes = [x["texto"] for x in sessao.segs if x["i"] < primeiro][-3:]
    lista = [{"fala": x["texto"], "max": int(max(25, _disponivel(sessao, x) * 19))} for x in itens]
    pedido = (f"Vídeo: {sessao.titulo or 'sem título'}. Idioma original: {sessao.idioma or 'detecte'}.\n"
              + (f"Falas anteriores (só contexto, não traduza): {json.dumps(antes, ensure_ascii=False)}\n" if antes else "")
              + "Traduza estas falas:\n" + json.dumps(lista, ensure_ascii=False))
    try:
        return traduzir._lista(traduzir._perguntar(traduzir.INSTRUCAO, pedido, None), len(itens))
    except Exception:
        return traduzir.traduzir([x["texto"] for x in itens], sessao.idioma, None, None, lote=1, titulo=sessao.titulo)


def _disponivel(sessao, s):
    seguinte = next((x["ini"] for x in sessao.segs if x["i"] == s["i"] + 1), s["fim"] + 1.5)
    return max(s["fim"] - s["ini"], seguinte - s["ini"] - 0.08)


# ------------------------------------------------------------------ servidor --

class Tratador(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _json(self, d, codigo=200):
        corpo = json.dumps(d, ensure_ascii=False).encode()
        self.send_response(codigo)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(corpo)))
        self.end_headers()
        self.wfile.write(corpo)

    def _de_casa(self):
        # só a extensão (pelo fundo.js) e o próprio app falam com a dublagem ao vivo; site nenhum fala direto
        if guarda.permitido(self.headers):
            return True
        self._json({"erro": "Pedido recusado."}, 403)
        return False

    def do_GET(self):
        if not self._de_casa():
            return
        _ESTADO["ultimo_uso"] = time.time()
        u = urlparse(self.path)
        q = {k: v[0] for k, v in parse_qs(u.query).items()}
        if u.path == "/saude":
            return self._json({"ok": True, "trabalhando": _ESTADO["trabalhando"], "msg": _ESTADO["msg"]})
        if u.path == "/estado":
            s = _SESSOES.get(_id_seguro(q.get("video", "")))
            if not s:
                return self._json({"erro": "sem sessão"}, 404)
            s.uso = time.time()
            desde = int(q.get("desde", 0) or 0)
            mud = [{k: x.get(k) for k in ("i", "ini", "fim", "pt", "ok", "dur")} for x in s.segs
                   if desde == 0 or x.get("v", 0) > desde]
            feitas = sum(1 for x in s.segs if x.get("ok"))
            return self._json({"versao": s.versao, "segs": mud, "total": len(s.segs), "feitas": feitas,
                               "msg": _ESTADO["msg"] if _ESTADO["trabalhando"] == s.video else ""})
        m = re.match(r"^/audio/([A-Za-z0-9_-]+)/(\d+)\.wav$", u.path)
        if m:
            s = _SESSOES.get(m.group(1))
            arq = s.pasta / f"{int(m.group(2)):04d}.wav" if s else None
            if not arq or not arq.exists():
                return self._json({"erro": "ainda não"}, 404)
            dados = arq.read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", "audio/wav")
            self.send_header("Content-Length", str(len(dados)))
            self.end_headers()
            self.wfile.write(dados)
            return
        self._json({"erro": "não encontrado"}, 404)

    def do_POST(self):
        if not self._de_casa():
            return
        _ESTADO["ultimo_uso"] = time.time()
        n = int(self.headers.get("Content-Length", 0) or 0)
        try:
            d = json.loads(self.rfile.read(n) or b"{}")
        except Exception:
            d = {}
        if self.path == "/iniciar":
            palavras = d.get("palavras") or []
            if not palavras:
                return self._json({"erro": "Este vídeo não tem legenda automática para usar."}, 400)
            vid = _id_seguro(d.get("video", ""))
            with _TRAVA:
                s = _SESSOES.get(vid)
                if not s or s.voz != (d.get("voz") if d.get("voz") in VOZES else "pm_alex"):
                    s = Sessao(vid, d.get("titulo"), d.get("idioma"), palavras, d.get("voz"))
                    _SESSOES[vid] = s
                s.foco = float(d.get("t", 0) or 0)
                s.uso = time.time()
            return self._json({"video": vid, "total": len(s.segs), "versao": 0})
        if self.path == "/posicao":
            s = _SESSOES.get(_id_seguro(d.get("video", "")))
            if s:
                s.foco = float(d.get("t", 0) or 0)
                s.uso = time.time()
            return self._json({"ok": bool(s)})
        if self.path == "/parar":
            _SESSOES.pop(_id_seguro(d.get("video", "")), None)
            return self._json({"ok": True})
        self._json({"erro": "não encontrado"}, 404)


def vigia_ocioso():
    while True:
        time.sleep(30)
        if time.time() - _ESTADO["ultimo_uso"] > OCIOSO_S:
            import os
            os._exit(0)


def _aquecer_voz():
    """Liga a voz rápida assim que a extensão acorda o app (o primeiro vídeo já começa mais rápido)."""
    try:
        import zonos
        if zonos.disponivel():
            zonos.ligar()
    except Exception:
        traceback.print_exc()


def main():
    PASTA.mkdir(parents=True, exist_ok=True)
    srv = ThreadingHTTPServer(("127.0.0.1", PORTA), Tratador)
    threading.Thread(target=trabalhar, daemon=True).start()
    threading.Thread(target=_aquecer_voz, daemon=True).start()
    threading.Thread(target=vigia_ocioso, daemon=True).start()
    print(f"Dublagem ao vivo em http://127.0.0.1:{PORTA}", flush=True)
    srv.serve_forever()


if __name__ == "__main__":
    main()
