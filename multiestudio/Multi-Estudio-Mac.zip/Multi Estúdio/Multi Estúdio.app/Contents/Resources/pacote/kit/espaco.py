"""
Espaço no Mac: quanto cada parte do app ocupa, apagar o que sobrou de testes e limpar
os arquivos de trabalho das dublagens antigas (o vídeo dublado nunca é apagado).

Os modelos de IA ficam no cache do Hugging Face. Se um módulo for removido, ele baixa
sozinho de novo na próxima vez que for usado.
"""
import json
import os
import shutil
import time
from pathlib import Path

import catalogo

BASE = Path(__file__).resolve().parent.parent
PROJETOS = BASE / "Projetos"
CONFIG = BASE / "Dublados" / "limpeza.json"

# a lista de módulos vem do catálogo (o mesmo que o instalador usa)
MODULOS = [{"id": m["id"], "nome": m["nome"], "descricao": m["descricao"], "fixo": bool(m.get("fixo")),
            "modelos": m.get("modelos", []) + m.get("reserva", []), "torch": m.get("torch", []),
            **({"pasta": m["repos"][0]["pasta"]} if m.get("repos") else {})}
           for m in catalogo.MODULOS if m["id"] != "base"]
# modelos que o app não usa mais (testes antigos ou motores trocados)
SOBRAS = ["qwen3-8b-4bit", "chatterbox", "s3tokenizerv2", "qwen3-4b-4bit", "qwen2.5-3b", "gemma-4-26b", "qwen3-tts",
          "voxtral", "omnivoice", "fish-speech", "openaudio", "voxcpm-0.5b", "voxcpm1.5", "whisper-large-v3-mlx",
          "ace-step", "acestep", "larger_clap_music"]            # a parte de música saiu do app
# o que é apagado de uma dublagem pronta (fica: vídeo dublado, falas, legenda e resumo)
TRABALHO = ["original.mp4", "original_compacto.mp4", "audio.wav", "faixas", "vozes", "voz_dublada.flac",
            "voz_dublada.wav", "dublagem.wav", "baixado.json"]


def cache_hf():
    try:
        from huggingface_hub import constants
        return Path(constants.HF_HUB_CACHE)
    except Exception:
        return Path.home() / ".cache" / "huggingface" / "hub"


def cache_torch():
    return Path(os.environ.get("TORCH_HOME", Path.home() / ".cache" / "torch")) / "hub" / "checkpoints"


def pasta_modelo(repo):
    return cache_hf() / ("models--" + repo.replace("/", "--"))


def tamanho(p, vistos=None):
    """Bytes de um arquivo ou pasta. Atalhos (o cache novo do Hugging Face guarda tudo numa pasta
    blobs comum e cada modelo só aponta para lá) contam o arquivo de verdade, uma vez só."""
    p = Path(p)
    if not p.exists():
        return 0
    if p.is_file():
        return p.stat().st_size
    vistos = set() if vistos is None else vistos
    total = 0
    for raiz, _dirs, arqs in os.walk(p):
        for a in arqs:
            c = os.path.join(raiz, a)
            try:
                real = os.path.realpath(c)
                if real in vistos:
                    continue
                vistos.add(real)
                total += os.stat(real).st_size
            except OSError:
                pass
    return total


def pastas_do_modulo(m):
    pastas = [pasta_modelo(r) for r in m.get("modelos", [])]
    raiz = cache_hf()
    for pref in m.get("prefixos", []):
        pastas += [d for d in raiz.glob("models--*") if d.name.lower().startswith(pref)] if raiz.exists() else []
    return pastas


def apagar_modelo(d):
    """Apaga o modelo e os arquivos de verdade que só ele usava (na pasta blobs comum)."""
    d = Path(d)
    if not d.exists():
        return 0
    livre = tamanho(d)
    alvos = set()
    for raiz, _dirs, arqs in os.walk(d):
        for a in arqs:
            c = os.path.join(raiz, a)
            if os.path.islink(c):
                alvos.add(os.path.realpath(c))
    shutil.rmtree(d, ignore_errors=True)
    blobs = cache_hf() / "blobs"
    em_uso = set()                      # arquivo que outro modelo também usa fica
    for outro in cache_hf().glob("models--*"):
        for raiz, _dirs, arqs in os.walk(outro):
            for a in arqs:
                c = os.path.join(raiz, a)
                if os.path.islink(c):
                    em_uso.add(os.path.realpath(c))
    alvos -= em_uso
    for r in alvos:
        if Path(r).parent == blobs and Path(r).exists():
            Path(r).unlink(missing_ok=True)
    return livre


def gb(n):
    return round(n / 1e9, 1)


def dias_config():
    try:
        return json.loads(CONFIG.read_text(encoding="utf-8")).get("dias", 1)
    except Exception:
        return 1            # padrão: 24 horas depois de pronto


def salvar_dias(dias):
    CONFIG.parent.mkdir(exist_ok=True)
    CONFIG.write_text(json.dumps({"dias": dias}), encoding="utf-8")


def sobras():
    raiz = cache_hf()
    saida = [BASE / "motor"] if (BASE / "motor").exists() else []        # motor de música antigo, se ainda estiver lá
    if (BASE / "testes").exists() and any((BASE / "testes").iterdir()):     # o que sobrou dos testes de motores de voz
        saida.append(BASE / "testes")
    if not raiz.exists():
        return saida
    usados = {("models--" + r.replace("/", "--")).lower() for m in MODULOS for r in m.get("modelos", [])}
    for d in raiz.glob("models--*"):
        nome = d.name.lower()
        if nome not in usados and any(s in nome for s in SOBRAS):
            saida.append(d)
    return saida


def projetos_prontos(ocupados=()):
    for p in sorted(PROJETOS.glob("dublagem-*")):
        if (p / "dublagem.json").exists() and p.name.replace("dublagem-", "") not in ocupados:
            yield p


def trabalho_do_projeto(p):
    return sum(tamanho(p / n) for n in TRABALHO)


def resumo(ocupados=()):
    mods = []
    vistos = set()                               # modelo usado por dois módulos conta uma vez só
    for m in MODULOS:
        t = sum(tamanho(d, vistos) for d in pastas_do_modulo(m)) + sum(tamanho(cache_torch() / a) for a in m.get("torch", []))
        if m.get("pasta"):                       # sem contar as sobras (aparecem embaixo, separadas)
            t += tamanho(BASE / m["pasta"])
        mods.append({"id": m["id"], "nome": m["nome"], "descricao": m["descricao"], "gb": gb(t), "fixo": bool(m.get("fixo"))})
    lixo = sobras()
    projs = list(projetos_prontos(ocupados))
    trabalho = sum(trabalho_do_projeto(p) for p in projs)
    return {"modulos": mods,
            "sobras": {"gb": gb(sum(tamanho(d) for d in lixo)), "itens": [d.name.split("--")[-1] for d in lixo]},
            "trabalho": {"gb": gb(trabalho), "videos": sum(1 for p in projs if trabalho_do_projeto(p) > 0)},
            "app": gb(tamanho(BASE / "kit" / ".venv")),
            "dias": dias_config()}


def apagar_sobras():
    livre = 0
    for d in sobras():
        if d.name.startswith("models--"):
            livre += apagar_modelo(d)
        else:                                    # pasta solta (motor antigo, testes)
            livre += tamanho(d)
            shutil.rmtree(d, ignore_errors=True)
    return livre


def remover_modulo(mid):
    m = next((x for x in MODULOS if x["id"] == mid and not x.get("fixo")), None)
    if not m:
        return 0
    livre = sum(apagar_modelo(d) for d in pastas_do_modulo(m))
    if m.get("pasta") and (BASE / m["pasta"]).exists():
        livre += tamanho(BASE / m["pasta"])
        shutil.rmtree(BASE / m["pasta"], ignore_errors=True)
    for a in m.get("torch", []):
        livre += tamanho(cache_torch() / a)
        (cache_torch() / a).unlink(missing_ok=True)
    return livre


def limpar_projetos(dias=None, ocupados=(), agora=False):
    """Apaga os arquivos de trabalho das dublagens prontas há mais de `dias` dias (ou todas, com agora=True)."""
    dias = dias_config() if dias is None else dias
    if dias is None or (dias <= 0 and not agora):
        return 0
    livre = 0
    for p in projetos_prontos(ocupados):
        idade = (time.time() - (p / "dublagem.json").stat().st_mtime) / 86400
        if not agora and idade < dias:
            continue
        for n in TRABALHO:
            alvo = p / n
            livre += tamanho(alvo)
            if alvo.is_dir():
                shutil.rmtree(alvo, ignore_errors=True)
            elif alvo.exists():
                alvo.unlink()
    return livre


def foi_limpo(pasta):
    return (Path(pasta) / "dublagem.json").exists() and not (Path(pasta) / "faixas").exists()
