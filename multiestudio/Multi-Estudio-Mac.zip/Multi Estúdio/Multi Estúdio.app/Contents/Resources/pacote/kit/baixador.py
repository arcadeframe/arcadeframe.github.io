"""
Baixador: vídeo ou só o áudio de YouTube, Instagram, Vimeo, TikTok, Facebook, X e
mais de mil sites (yt-dlp, licença Unlicense). Sem login em conta nenhuma.

modo  "video" -> mp4 na resolução pedida (0 = a melhor)
      "audio" -> mp3 320k, m4a ou wav
legendas -> baixa as legendas que o próprio vídeo já tem (português e inglês), em .srt
"""
import json
import os
import re
import sys
from pathlib import Path

from dublar import ffmpeg, formato


def _path_venv():
    pasta_bin = str(Path(sys.executable).parent)
    if pasta_bin not in os.environ.get("PATH", ""):
        os.environ["PATH"] = pasta_bin + os.pathsep + os.environ.get("PATH", "")


def nome_limpo(t):
    t = re.sub(r'[\\/:*?"<>|\n\r\t]+', " ", t or "")
    return re.sub(r"\s{2,}", " ", t).strip(" .")[:110] or "video"


def baixar_midia(url, pasta_destino, modo="video", resolucao=1080, formato_audio="mp3", legendas=False, aviso=None, prefixo=""):
    import yt_dlp
    _path_venv()
    pasta_destino = Path(pasta_destino)
    pasta_destino.mkdir(parents=True, exist_ok=True)
    temp = pasta_destino / ".baixando"
    temp.mkdir(exist_ok=True)

    def gancho(d):
        if aviso and d.get("status") == "downloading":
            total = d.get("total_bytes") or d.get("total_bytes_estimate") or 0
            if total:
                vel = d.get("speed") or 0
                aviso(d.get("downloaded_bytes", 0) / total, f"{vel / 1e6:.1f} MB/s" if vel else "")

    opcoes = {"outtmpl": str(temp / "%(id)s.%(ext)s"), "noplaylist": True, "quiet": True, "no_warnings": True,
              "ffmpeg_location": ffmpeg(), "progress_hooks": [gancho], "restrictfilenames": False}
    if modo == "audio":
        opcoes["format"] = "bestaudio/best"
        if formato_audio == "wav":
            opcoes["postprocessors"] = [{"key": "FFmpegExtractAudio", "preferredcodec": "wav"}]
        elif formato_audio == "m4a":
            opcoes["postprocessors"] = [{"key": "FFmpegExtractAudio", "preferredcodec": "m4a"}]
        else:
            opcoes["postprocessors"] = [{"key": "FFmpegExtractAudio", "preferredcodec": "mp3", "preferredquality": "320"}]
    else:
        opcoes["format"] = formato(resolucao)
        opcoes["merge_output_format"] = "mp4"
    if legendas:
        opcoes.update({"writesubtitles": True, "subtitleslangs": ["pt.*", "pt-BR", "en.*"],
                       "subtitlesformat": "srt/best", "postprocessors": opcoes.get("postprocessors", []) +
                       [{"key": "FFmpegSubtitlesConvertor", "format": "srt"}]})
    import rede
    opcoes.update(rede.opcoes(url))

    def fazer(rota):
        with rede.vez_do_youtube(url), yt_dlp.YoutubeDL(rota(opcoes)) as y:
            return y.extract_info(url, download=True)
    remedio = getattr(rede, "com_remedio", None) or (lambda u, f, *a, **k: f(lambda o: o))   # app aberto desde antes da atualização
    info = remedio(url, fazer, (lambda t: aviso(0, t)) if aviso else None)     # YouTube recusou? tenta outros caminhos
    vid = info.get("id") or ""
    titulo = rede.titulo_de(url) or info.get("title") or "video"
    nome = prefixo + nome_limpo(titulo)       # prefixo = número da playlist ("01 - ")
    principal, extras = None, []
    achados = sorted(temp.glob(f"{glob_seguro(vid)}*")) if vid else []
    if not any(a.suffix not in (".part", ".ytdl", ".srt", ".vtt") for a in achados):
        achados = sorted(a for a in temp.iterdir() if a.is_file())      # página com vários vídeos: o nome não bate com o id
        vid = ""
    for arq in achados:
        if arq.suffix in (".part", ".ytdl") or arq.name.endswith(".temp"):
            continue
        resto = arq.name[len(vid):] if vid else "".join(arq.suffixes[-2:] if arq.suffix in (".srt", ".vtt") else arq.suffixes[-1:])
        destino = livre(pasta_destino, nome, resto)
        arq.replace(destino)
        if arq.suffix in (".srt", ".vtt"):
            extras.append(destino.name)
        else:
            principal = destino
    try:
        temp.rmdir()                               # só sai se ficou vazia
    except OSError:
        pass
    if not principal:
        raise RuntimeError("O arquivo não foi baixado.")
    return {"arquivo": str(principal), "nome": principal.name, "titulo": titulo, "legendas": extras,
            "duracao": info.get("duration") or 0, "site": info.get("extractor_key") or "",
            "tamanho_mb": round(principal.stat().st_size / 1e6, 1)}


def glob_seguro(t):
    return re.sub(r"([\[\]*?])", r"[\1]", t)


def livre(pasta, nome, resto):
    """Não sobrescreve: acrescenta (2), (3)... se já existir."""
    c = Path(pasta) / f"{nome}{resto}"
    n = 2
    while c.exists() and n < 999:
        c = Path(pasta) / f"{nome} ({n}){resto}"
        n += 1
    return c


if __name__ == "__main__":
    r = baixar_midia(sys.argv[1], sys.argv[2], sys.argv[3] if len(sys.argv) > 3 else "video",
                     aviso=lambda f, v: print(f"{int(f * 100)}% {v}", flush=True))
    print(json.dumps(r, ensure_ascii=False))
