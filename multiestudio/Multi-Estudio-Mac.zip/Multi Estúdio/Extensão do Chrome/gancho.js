// Roda dentro da página do YouTube. Só ESCUTA a legenda que o próprio player baixa
// (não faz pedido extra ao YouTube) e liga a legenda original quando a extensão pede.
(() => {
  if (window.__tiGancho) return;
  window.__tiGancho = true;
  const guardadas = {};                     // id do vídeo -> legenda (texto)

  function idDaUrl(u) {
    try { return new URL(u, location.href).searchParams.get('v') || ''; } catch (e) { return ''; }
  }
  function enviar(o) { window.postMessage(Object.assign({ fonte: 'ti-gancho' }, o), '*'); }
  function pegou(url, texto) {
    if (!texto || texto.length < 20) return;
    const vid = idDaUrl(url);
    let lang = '';
    try { const p = new URL(url, location.href).searchParams; if (p.get('tlang')) return; lang = p.get('lang') || ''; } catch (e) {}
    if (vid) guardadas[vid] = { texto, lang };
    enviar({ tipo: 'legenda', video: vid, lang, texto });
  }

  const fetchOriginal = window.fetch;
  window.fetch = async function (...a) {
    const r = await fetchOriginal.apply(this, a);
    try {
      const u = (a[0] && a[0].url) || String(a[0]);
      if (u.includes('/api/timedtext')) r.clone().text().then(t => pegou(u, t)).catch(() => {});
    } catch (e) {}
    return r;
  };
  const abrir = XMLHttpRequest.prototype.open, mandar = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (m, u, ...r) { this.__tiUrl = String(u); return abrir.call(this, m, u, ...r); };
  XMLHttpRequest.prototype.send = function (...a) {
    if (this.__tiUrl && this.__tiUrl.includes('/api/timedtext')) {
      this.addEventListener('load', () => {
        try { pegou(this.__tiUrl, typeof this.response === 'string' ? this.response : this.responseText); } catch (e) {}
      });
    }
    return mandar.apply(this, a);
  };

  window.addEventListener('message', ev => {
    const d = ev.data;
    if (ev.source !== window || !d || d.fonte !== 'ti-ext') return;
    if (d.tipo === 'pedir-legenda') pedir();
  });

  function pedir() {
    const p = document.getElementById('movie_player');
    if (!p || !p.getPlayerResponse) { enviar({ tipo: 'erro', erro: 'player' }); return; }
    const pr = p.getPlayerResponse() || {};
    const vid = (pr.videoDetails && pr.videoDetails.videoId) || '';
    const titulo = (pr.videoDetails && pr.videoDetails.title) || document.title;
    const faixas = (((pr.captions || {}).playerCaptionsTracklistRenderer || {}).captionTracks) || [];
    if (!faixas.length) { enviar({ tipo: 'erro', erro: 'sem-legenda', video: vid }); return; }
    // a automática (asr) diz a língua falada; se houver legenda feita por gente nessa língua, ela é melhor (tem pontuação)
    const asr = faixas.find(f => f.kind === 'asr');
    const escolhida = (asr && faixas.find(f => !f.kind && f.languageCode === asr.languageCode)) || asr
      || faixas.find(f => !/^pt/.test(f.languageCode)) || faixas[0];
    enviar({ tipo: 'faixa', video: vid, titulo, idioma: escolhida.languageCode, kind: escolhida.kind || '' });
    const ja = guardadas[vid];
    if (ja && ja.lang === escolhida.languageCode) { enviar({ tipo: 'legenda', video: vid, lang: ja.lang, texto: ja.texto }); return; }
    try {
      if (p.loadModule) p.loadModule('captions');
      const lista = (p.getOption && p.getOption('captions', 'tracklist')) || [];
      const alvo = lista.find(x => x.languageCode === escolhida.languageCode && (x.kind || '') === (escolhida.kind || ''))
        || lista.find(x => x.languageCode === escolhida.languageCode);
      p.setOption('captions', 'track', alvo || { languageCode: escolhida.languageCode });
    } catch (e) {
      enviar({ tipo: 'erro', erro: 'cc', detalhe: String(e && e.message || e) });
    }
  }
})();
