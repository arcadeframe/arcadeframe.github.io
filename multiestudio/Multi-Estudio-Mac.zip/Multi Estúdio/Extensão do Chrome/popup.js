const PADRAO = { ligado: false, voz: 'pm_alex', volumeOriginal: 0.2, esperar: true, legenda: false };
const $ = s => document.querySelector(s);

function pintar(c) {
  $('#ligado').checked = !!c.ligado;
  document.querySelectorAll('#voz button').forEach(b => b.classList.toggle('on', b.dataset.v === c.voz));
  $('#volume').value = c.volumeOriginal;
  $('#volTxt').textContent = Math.round(c.volumeOriginal * 100) + '%';
  $('#esperar').checked = !!c.esperar;
  $('#legenda').checked = !!c.legenda;
}
function salvar(m) { chrome.storage.local.set(m); }

chrome.storage.local.get(PADRAO, c => pintar({ ...PADRAO, ...c }));
$('#ligado').onchange = e => salvar({ ligado: e.target.checked });
document.querySelectorAll('#voz button').forEach(b => b.onclick = () => {
  salvar({ voz: b.dataset.v });
  document.querySelectorAll('#voz button').forEach(x => x.classList.toggle('on', x === b));
});
$('#volume').oninput = e => { $('#volTxt').textContent = Math.round(e.target.value * 100) + '%'; };
$('#volume').onchange = e => salvar({ volumeOriginal: +e.target.value });
$('#esperar').onchange = e => salvar({ esperar: e.target.checked });
$('#legenda').onchange = e => salvar({ legenda: e.target.checked });

function estado(tipo, texto) {
  $('#estado').className = 'estado ' + tipo;
  $('#estado span').textContent = texto;
}
chrome.runtime.sendMessage({ tipo: 'api', url: 'http://127.0.0.1:8790/api/status' }, r => {
  if (r && r.ok) estado('ok', 'App Multi Estúdio conectado');
  else estado('erro', 'Abra o app Multi Estúdio no computador');
  const mods = r && r.ok && r.dados && r.dados.modulos;
  if (Array.isArray(mods) && !mods.includes('dublagem')) {      // sem o módulo de dublagem (ex.: Windows): só baixar
    $('#aoVivo').hidden = true;
    document.querySelector('header .chave').hidden = true;
    document.querySelectorAll('button[data-a=dublar]').forEach(b => b.remove());
    document.querySelector('#envio .acoes3').style.gridTemplateColumns = '1fr 1fr';
    window.semDublagem = true;
  }
});

// mandar o vídeo desta aba para a fila do app (a página inteira ou um arquivo achado pelo detector)
function tamanho(b) { return !b ? '' : b > 1e9 ? (b / 1e9).toFixed(1).replace('.', ',') + ' GB' : Math.round(b / 1e6) + ' MB'; }
function mandar(pedido) {
  const msg = $('#envioMsg');
  msg.className = 'dica';
  msg.textContent = 'Mandando…';
  chrome.storage.local.get({ envio: {} }, d => {
    if (pedido.acao !== 'dublar' && (d.envio || {}).perguntarPasta !== false) msg.textContent = 'Escolha a pasta na janelinha…';
  });
  chrome.runtime.sendMessage({ tipo: 'enviar', ...pedido }, r => {
    const ok = r && r.ok;
    msg.className = 'dica ' + (ok ? 'ok' : 'erro');
    msg.textContent = ok ? 'Na fila do Multi Estúdio ✓' : (r && r.cancelado) ? 'Cancelado' : ((r && r.erro) || 'Abra o app Multi Estúdio no computador.');
  });
}
const abaPedida = +new URLSearchParams(location.search).get('aba');      // só para os testes automáticos
(abaPedida ? cb => chrome.tabs.get(abaPedida, a => cb([a])) : cb => chrome.tabs.query({ active: true, currentWindow: true }, cb))(abas => {
  const aba = abas && abas[0];
  if (!aba || !/^https?:\/\//.test(aba.url || '')) return;
  $('#envio').hidden = false;
  document.querySelectorAll('#envio .acoes3 button').forEach(b => b.onclick = () => mandar({ url: aba.url, acao: b.dataset.a }));
  chrome.storage.session.get({ ['midias_' + aba.id]: [] }, d => {
    const lista = (d['midias_' + aba.id] || []).slice().sort((a, b) => (b.tam || 0) - (a.tam || 0));
    if (!lista.length) return;
    $('#achados').hidden = false;
    $('#achadosTit').textContent = lista.length === 1 ? '1 vídeo encontrado' : lista.length + ' vídeos encontrados';
    const titulo = (aba.title || '').replace(/\s+/g, ' ').trim().slice(0, 120);
    lista.forEach(m => {
      const linha = document.createElement('div');
      linha.className = 'item';
      const inf = document.createElement('div');
      inf.className = 'inf';
      const nome = document.createElement('b');
      nome.textContent = m.nome || m.host;
      nome.title = m.url;
      const det = document.createElement('small');
      det.textContent = [m.tipo, m.tipo === 'Vídeo' ? tamanho(m.tam) : '', m.host].filter(Boolean).join(' · ');
      inf.append(nome, det);
      const bx = document.createElement('button');
      bx.textContent = 'Baixar';
      bx.onclick = () => mandar({ url: m.url, acao: 'video', direto: true, referer: aba.url, titulo });
      const db = document.createElement('button');
      if (window.semDublagem) db.hidden = true;
      db.textContent = 'Dublar';
      db.onclick = () => mandar({ url: m.url, acao: 'dublar', direto: true, referer: aba.url, titulo });
      linha.append(inf, bx, db);
      $('#achadosLista').append(linha);
    });
  });
});

// acompanhar a fila do app aqui mesmo (só olha: se o app estiver fechado, não abre ele por causa disso)
const APP = 'http://127.0.0.1:8790';
async function app(caminho, metodo) {
  const r = await fetch(APP + caminho, { method: metodo || 'GET' });
  const d = await r.json();
  if (!r.ok || d.erro) throw new Error(d.erro || 'falhou');
  return d;
}
const abertura = Date.now() / 1000;
function pintarFila(itens) {
  // o que está andando ou esperando, mais o que terminou há pouco (ou deu erro) para você ver o resultado
  const vivos = itens.filter(x => x.estado === 'rodando' || x.estado === 'esperando');
  const fim = itens.filter(x => (x.estado === 'pronto' || x.estado === 'erro') && (x.fim || 0) > abertura - 600).slice(-3);
  const lista = [...vivos, ...fim].slice(0, 8);
  $('#fila').hidden = !lista.length;
  $('#filaTit').textContent = vivos.length ? 'Em andamento (' + vivos.length + ')' : 'Terminou agora';
  const caixa = $('#filaLista');
  caixa.textContent = '';
  lista.forEach(x => {
    const d = document.createElement('div');
    d.className = 'trab ' + x.estado;
    const t = document.createElement('b');
    t.textContent = x.titulo || x.link || 'Vídeo';
    t.title = t.textContent;
    const et = document.createElement('div');
    et.className = 'et';
    const e1 = document.createElement('span');
    e1.textContent = x.etapa || '';
    e1.title = e1.textContent;
    et.append(e1);
    const salvo = x.resultado && x.resultado.salvo_em;
    if (x.estado === 'pronto' && salvo) {
      const a = document.createElement('a');
      a.textContent = 'Mostrar';
      a.onclick = () => fetch(APP + '/api/mostrar', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ caminho: salvo }) });
      et.append(a);
    } else if (x.estado === 'rodando' && !/%/.test(x.etapa || '')) {
      const pc = document.createElement('span');
      pc.textContent = Math.round((x.progresso || 0) * 100) + '%';
      et.append(pc);
    }
    const barra = document.createElement('div');
    barra.className = 'barra';
    const i = document.createElement('i');
    i.style.width = Math.round((x.estado === 'pronto' ? 1 : x.progresso || 0) * 100) + '%';
    barra.append(i);
    d.append(t, et, barra);
    caixa.append(d);
  });
}
async function olharFila() {
  try { pintarFila((await app('/api/fila')).fila || []); } catch (e) { $('#fila').hidden = true; }
}
olharFila();
setInterval(olharFila, 1500);

function pintarPasta(d) {
  $('#pasta').hidden = false;
  $('#pastaTxt').textContent = d.pasta.replace(/^\/Users\/[^/]+/, '~') + (d.padrao ? ' (padrão do app)' : '');
  $('#pastaPadrao').style.visibility = d.padrao ? 'hidden' : '';
}
app('/api/pasta').then(pintarPasta).catch(() => {});
chrome.storage.local.get({ envio: {} }, d => { $('#perguntarPasta').checked = (d.envio || {}).perguntarPasta !== false; });
$('#perguntarPasta').onchange = e => chrome.storage.local.get({ envio: {} }, d => chrome.storage.local.set({ envio: { ...(d.envio || {}), perguntarPasta: e.target.checked } }));
$('#pastaEscolher').onclick = () => { $('#pastaTxt').textContent = 'Escolha a pasta na janelinha…'; app('/api/pasta/escolher', 'POST').then(pintarPasta).catch(e => { $('#pastaTxt').textContent = e.message; }); };
$('#pastaPadrao').onclick = () => app('/api/pasta/padrao', 'POST').then(pintarPasta).catch(() => {});
$('#pastaAbrir').onclick = () => app('/api/pasta/abrir', 'POST').catch(() => {});
