// Ponte entre a página e o app no Mac (127.0.0.1). A página não fala direto com o Mac:
// tudo passa por aqui, então o Chrome não pede permissão de "rede local" a cada site.
const PERMITIDO = /^http:\/\/127\.0\.0\.1:(8790|8791)\//;

// ---------- mandar um vídeo do YouTube para a fila do app (botões na página, menu do botão direito e ícone) ----------
const APP = 'http://127.0.0.1:8790';
const ENVIO_PADRAO = { qualidade: 'equilibrado', voz: 'alex', resolucao: 1080, perguntarPasta: true };

function idDoVideo(url) {
  try {
    const u = new URL(url);
    if (u.hostname === 'youtu.be') return u.pathname.slice(1, 12);
    if (u.pathname.startsWith('/shorts/')) return u.pathname.split('/')[2];
    return u.searchParams.get('v');
  } catch (e) { return null; }
}
function linkLimpo(url, playlist) {
  try {
    const u = new URL(url);
    const lista = u.searchParams.get('list');
    if (playlist && lista) return 'https://www.youtube.com/playlist?list=' + lista;
    const id = idDoVideo(url);
    return id ? 'https://www.youtube.com/watch?v=' + id : null;
  } catch (e) { return null; }
}
// ---------- abrir o app sozinho (escondido) quando ele não está aberto ----------
let porta = null;       // enquanto esta ligação existe, o app escondido fica vivo; fechou o Chrome, ele sai sozinho
async function appVivo() {
  try {
    const c = new AbortController();
    const t = setTimeout(() => c.abort(), 1500);
    const r = await fetch(APP + '/api/status', { signal: c.signal });
    clearTimeout(t);
    return r.ok;
  } catch (e) { return false; }
}
function acordarApp() {
  return new Promise(res => {
    try {
      if (!porta) {
        porta = chrome.runtime.connectNative('br.com.multiestudio.host');
        porta.onDisconnect.addListener(() => { void chrome.runtime.lastError; porta = null; });
      }
      const p = porta;
      const fim = setTimeout(() => res(false), 45000);
      const ouvir = m => { clearTimeout(fim); p.onMessage.removeListener(ouvir); res(!!(m && m.ok)); };
      // sem a ponte (Windows, ou app nunca aberto neste Mac): desiste na hora em vez de esperar 45 s
      p.onDisconnect.addListener(() => { clearTimeout(fim); res(false); });
      porta.onMessage.addListener(ouvir);
      porta.postMessage({ abrir: true });
    } catch (e) { porta = null; res(false); }
  });
}
async function garantirApp() {
  if (await appVivo()) return true;
  return await acordarApp();
}

async function enviar(p) {
  const guardado = await chrome.storage.local.get({ envio: ENVIO_PADRAO });
  const e = { ...ENVIO_PADRAO, ...guardado.envio, ...(p.ajustes || {}) };
  const youtube = /(^|\.)youtube\.com$|(^|\.)youtu\.be$/.test((() => { try { return new URL(p.url).hostname; } catch (e) { return ''; } })());
  const link = (p.direto || !youtube) ? (/^https?:\/\//.test(p.url || '') ? p.url : null) : linkLimpo(p.url, p.playlist);
  if (!link) return { ok: false, erro: 'Não achei o vídeo nesta página.' };
  const corpo = { links: link, link, direto: !!p.direto, referer: p.direto ? (p.referer || '') : '', titulo: p.direto ? (p.titulo || '') : '',
                  modo: p.acao, voz: e.voz, resolucao: p.acao === 'audio' ? 0 : e.resolucao,
                  qualidade: p.acao === 'dublar' ? e.qualidade : null, opcoes: { formato_audio: 'mp3' },
                  perguntar_pasta: (p.acao === 'video' || p.acao === 'audio') && e.perguntarPasta !== false };
  if (!(await garantirApp())) return { ok: false, erro: 'Abra o app Multi Estúdio no computador.' };
  try {
    const r = await fetch(APP + '/api/dublar', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(corpo) });
    const d = await r.json().catch(() => ({}));
    if (d.cancelado) return { ok: false, cancelado: true, erro: 'Cancelado' };
    if (!r.ok || d.erro) return { ok: false, erro: d.erro || 'O app recusou o pedido.' };
    await chrome.storage.local.set({ envio: e });
    return { ok: true, playlist: link.includes('/playlist') };
  } catch (err) {
    return { ok: false, erro: 'Abra o app Multi Estúdio no computador.' };
  }
}
async function marcar(ok) {
  try {
    await chrome.action.setBadgeBackgroundColor({ color: ok ? '#2E9E57' : '#D64545' });
    await chrome.action.setBadgeText({ text: ok ? '✓' : '!' });
    setTimeout(() => chrome.action.setBadgeText({ text: '' }), 4000);
  } catch (e) {}
}

const PADROES = ['https://www.youtube.com/watch*', 'https://www.youtube.com/shorts/*', 'https://youtu.be/*',
                 'https://m.youtube.com/watch*'];
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({ id: 'ti', title: 'Multi Estúdio', contexts: ['link', 'page', 'video'],
                                 targetUrlPatterns: PADROES, documentUrlPatterns: ['https://www.youtube.com/*', 'https://m.youtube.com/*'] });
    chrome.contextMenus.create({ id: 'ti-dublar', parentId: 'ti', title: 'Dublar para português', contexts: ['link', 'page', 'video'] });
    chrome.contextMenus.create({ id: 'ti-video', parentId: 'ti', title: 'Baixar o vídeo', contexts: ['link', 'page', 'video'] });
    chrome.contextMenus.create({ id: 'ti-audio', parentId: 'ti', title: 'Baixar só o áudio (mp3)', contexts: ['link', 'page', 'video'] });
  });
});
chrome.contextMenus.onClicked.addListener(async (info, aba) => {
  const acao = { 'ti-dublar': 'dublar', 'ti-video': 'video', 'ti-audio': 'audio' }[info.menuItemId];
  if (!acao) return;
  const r = await enviar({ url: info.linkUrl || info.pageUrl || (aba && aba.url), acao });
  marcar(r.ok);
  if (aba && aba.id) chrome.tabs.sendMessage(aba.id, { tipo: 'enviado', ...r, acao }).catch(() => {});
});

chrome.runtime.onMessage.addListener((m, _remetente, responder) => {
  (async () => {
    try {
      if (m && m.tipo === 'enviar') { const r = await enviar(m); marcar(r.ok); responder(r); return; }
      if (!m || !PERMITIDO.test(m.url || '')) { responder({ ok: false, erro: 'endereço não permitido' }); return; }
      if (m.tipo === 'api') {
        const pedir = () => fetch(m.url, {
          method: m.metodo || 'GET',
          headers: m.corpo ? { 'Content-Type': 'application/json' } : {},
          body: m.corpo ? JSON.stringify(m.corpo) : undefined,
        });
        let r;
        try { r = await pedir(); }
        catch (e) {                      // app fechado: abre escondido e tenta de novo
          if (!(await acordarApp())) throw e;
          r = await pedir();
        }
        let dados = null;
        try { dados = await r.json(); } catch (e) {}
        responder({ ok: r.ok, status: r.status, dados });
      } else if (m.tipo === 'audio') {
        const r = await fetch(m.url);
        if (!r.ok) { responder({ ok: false, status: r.status }); return; }
        const b = new Uint8Array(await r.arrayBuffer());
        let s = '';
        for (let i = 0; i < b.length; i += 0x8000) s += String.fromCharCode.apply(null, b.subarray(i, i + 0x8000));
        responder({ ok: true, b64: btoa(s) });
      } else {
        responder({ ok: false, erro: 'pedido desconhecido' });
      }
    } catch (e) {
      responder({ ok: false, erro: String(e && e.message || e) });
    }
  })();
  return true;
});

// ---------- detector: acha os vídeos que a página carrega (qualquer site, menos o YouTube, que tem botões próprios) ----------
const TIPOS = [
  [/\.m3u8(\?|$)/i, /mpegurl/i, 'HLS'],
  [/\.mpd(\?|$)/i, /dash\+xml/i, 'DASH'],
  [/\.(mp4|m4v|mov|webm)(\?|$)/i, /^video\/(mp4|webm|quicktime|x-m4v)/i, 'Vídeo'],
];
const FORA = /(^|\.)(youtube\.com|googlevideo\.com|youtu\.be|ytimg\.com|doubleclick\.net|google-analytics\.com)$/;
const fila = {};        // gravações enfileiradas por aba (evita corrida ao gravar)
function gravar(tabId, f) {
  fila[tabId] = (fila[tabId] || Promise.resolve()).then(async () => {
    const k = 'midias_' + tabId;
    const d = await chrome.storage.session.get({ [k]: [] });
    const nova = f(d[k]);
    if (nova) {
      await chrome.storage.session.set({ [k]: nova });
      try {
        await chrome.action.setBadgeBackgroundColor({ tabId, color: '#F5A524' });
        await chrome.action.setBadgeText({ tabId, text: nova.length ? String(nova.length) : '' });
      } catch (e) {}
    }
  }).catch(() => {});
}
chrome.webRequest.onHeadersReceived.addListener(d => {
  if (d.tabId < 0 || d.statusCode >= 400) return;
  let u;
  try { u = new URL(d.url); } catch (e) { return; }
  if (!/^https?:$/.test(u.protocol) || FORA.test(u.hostname) || u.hostname === '127.0.0.1') return;
  const cab = n => { const h = (d.responseHeaders || []).find(x => x.name.toLowerCase() === n); return h ? (h.value || '') : ''; };
  const ct = cab('content-type');
  const tipo = TIPOS.find(([re, mime]) => re.test(u.pathname) || mime.test(ct));
  if (!tipo) return;
  if (/\.(ts|m4s|aac|vtt|key)(\?|$)/i.test(u.pathname) || /mp2t/i.test(ct)) return;       // pedaços de um vídeo, não o vídeo
  let tam = parseInt(cab('content-length') || '0', 10) || 0;
  const faixa = cab('content-range').match(/\/(\d+)$/);
  if (faixa) tam = parseInt(faixa[1], 10);
  if (tipo[2] === 'Vídeo' && tam && tam < 700 * 1024) return;                                  // ícones animados, prévias minúsculas
  if (tipo[2] === 'Vídeo' && /\/(seg|segment|chunk|frag)[-_]?\d/i.test(u.pathname)) return;
  const chave = u.origin + u.pathname;
  gravar(d.tabId, lista => {
    if (lista.some(x => x.chave === chave)) return null;
    return [...lista, { chave, url: d.url, tipo: tipo[2], tam, host: u.hostname, nome: decodeURIComponent(u.pathname.split('/').pop() || '').slice(0, 60), quando: Date.now() }].slice(-25);
  });
}, { urls: ['http://*/*', 'https://*/*'], types: ['media', 'xmlhttprequest', 'other', 'object'] }, ['responseHeaders']);
// página nova na aba: zera a lista
chrome.tabs.onUpdated.addListener((tabId, info) => {
  if (info.url) { chrome.storage.session.remove('midias_' + tabId); try { chrome.action.setBadgeText({ tabId, text: '' }); } catch (e) {} }
});
chrome.tabs.onRemoved.addListener(tabId => chrome.storage.session.remove('midias_' + tabId));
