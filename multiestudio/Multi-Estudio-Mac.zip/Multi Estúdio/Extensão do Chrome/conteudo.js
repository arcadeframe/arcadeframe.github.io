// Dublagem ao vivo no YouTube: pega a legenda automática do vídeo, o app no Mac traduz e
// narra na frente de onde você está, e aqui cada fala toca na hora certa com o som original mais baixo.
(() => {
  const APP = 'http://127.0.0.1:8790', VIVO = 'http://127.0.0.1:8791';
  const PADRAO = { ligado: false, voz: 'pm_alex', volumeOriginal: 0.2, esperar: true, legenda: false };
  let cfg = { ...PADRAO };
  let s = novoEstado();

  function novoEstado() {
    return { video: null, ativo: false, segs: [], porI: new Map(), versao: 0, buffers: new Map(), carregando: new Set(),
             fonte: null, tocandoI: -1, pausadoPorMim: false, ultimaPosicao: 0, legendaTimer: null, loop: null, poll: null,
             total: 0, feitas: 0, msg: '', semEsperaI: -1 };
  }

  // ---------- conversa com o app (sempre pelo fundo.js) ----------
  function pedir(url, metodo, corpo) {
    return new Promise(res => {
      try { chrome.runtime.sendMessage({ tipo: 'api', url, metodo, corpo }, r => res(r || { ok: false })); }
      catch (e) { res({ ok: false, erro: String(e) }); }
    });
  }
  function baixarAudio(url) {
    return new Promise(res => {
      try { chrome.runtime.sendMessage({ tipo: 'audio', url }, r => res(r || { ok: false })); }
      catch (e) { res({ ok: false }); }
    });
  }

  // ---------- tela: aviso pequeno no canto do vídeo e legenda em português ----------
  function player() { return document.getElementById('movie_player'); }
  function video() { return document.querySelector('#movie_player video.html5-main-video') || document.querySelector('#movie_player video'); }
  function selo() {
    let el = document.getElementById('ti-selo');
    const p = player();
    if (!p) return null;
    if (!el) {
      el = document.createElement('div');
      el.id = 'ti-selo';
      el.innerHTML = '<span class="ti-ponto"></span><span class="ti-txt"></span><button class="ti-x" title="Desligar a dublagem">✕</button>';
      el.querySelector('.ti-x').onclick = ev => { ev.stopPropagation(); chrome.storage.local.set({ ligado: false }); };
      p.appendChild(el);
    } else if (el.parentElement !== p) p.appendChild(el);
    return el;
  }
  function avisar(texto, tipo) {
    const el = selo();
    if (!el) return;
    el.dataset.tipo = tipo || 'info';
    el.querySelector('.ti-txt').textContent = texto;
    el.classList.add('ver');
    clearTimeout(el._t);
    if (tipo === 'ok') el._t = setTimeout(() => el.classList.remove('ver'), 3500);
  }
  function esconderSelo() { const el = document.getElementById('ti-selo'); if (el) el.classList.remove('ver'); }
  function legendaPt(texto) {
    const p = player();
    if (!p) return;
    let el = document.getElementById('ti-legenda');
    if (!el) { el = document.createElement('div'); el.id = 'ti-legenda'; p.appendChild(el); }
    el.textContent = texto || '';
    el.classList.toggle('ver', !!(texto && cfg.legenda));
  }

  // ---------- áudio: a voz dublada e o som original mais baixo ----------
  let ctx = null, ganhoVoz = null;
  const rotas = new WeakMap();               // o mesmo <video> é reaproveitado pelo YouTube entre vídeos
  function prepararAudio() {
    if (!ctx) { ctx = new AudioContext(); ganhoVoz = ctx.createGain(); ganhoVoz.gain.value = 1; ganhoVoz.connect(ctx.destination); }
    if (ctx.state !== 'running') ctx.resume().catch(() => {});
    const v = video();
    if (v && ctx.state === 'running' && !rotas.has(v)) {
      try {
        const src = ctx.createMediaElementSource(v);
        const g = ctx.createGain();
        src.connect(g).connect(ctx.destination);
        rotas.set(v, g);
      } catch (e) { rotas.set(v, null); }
    }
    return ctx.state === 'running';
  }
  function abaixarOriginal(sim) {
    const v = video();
    const g = v && rotas.get(v);
    if (!g || !ctx) return;
    const alvo = sim ? cfg.volumeOriginal : 1;
    g.gain.cancelScheduledValues(ctx.currentTime);
    g.gain.setTargetAtTime(alvo, ctx.currentTime, sim ? 0.06 : 0.25);
  }
  function pararVoz() {
    if (s.fonte) { try { s.fonte.onended = null; s.fonte.stop(); } catch (e) {} }
    s.fonte = null;
    s.tocandoI = -1;
    abaixarOriginal(false);
    legendaPt('');
  }
  async function carregarBuffer(seg) {
    if (s.buffers.has(seg.i) || s.carregando.has(seg.i) || !ctx) return;
    s.carregando.add(seg.i);
    const vid = s.video;
    const r = await baixarAudio(`${VIVO}/audio/${encodeURIComponent(vid)}/${seg.i}.wav`);
    s.carregando.delete(seg.i);
    if (!r.ok || vid !== s.video) return;
    const bin = atob(r.b64), arr = new Uint8Array(bin.length);
    for (let k = 0; k < bin.length; k++) arr[k] = bin.charCodeAt(k);
    try { s.buffers.set(seg.i, await ctx.decodeAudioData(arr.buffer)); } catch (e) {}
  }
  function tocar(seg, deslocamento) {
    const buf = s.buffers.get(seg.i);
    const v = video();
    if (!buf || !v || !ctx) return;
    pararVoz();
    const f = ctx.createBufferSource();
    f.buffer = buf;
    f.playbackRate.value = v.playbackRate || 1;
    f.connect(ganhoVoz);
    f.onended = () => { if (s.fonte === f) { s.fonte = null; abaixarOriginal(false); legendaPt(''); } };
    f.start(0, Math.max(0, Math.min(deslocamento, buf.duration - 0.05)));
    s.fonte = f;
    s.tocandoI = seg.i;
    if (!s.anunciou) { s.anunciou = true; avisar('Dublagem ao vivo', 'ok'); }
    abaixarOriginal(true);
    legendaPt(seg.pt);
  }

  // ---------- legenda do YouTube -> palavras com tempo ----------
  function palavrasDe(texto) {
    const ws = [];
    const lixo = w => !w || /^\[.*\]$/.test(w) || /^[♪♫]+$/.test(w);
    texto = (texto || '').trim();
    if (texto.startsWith('{')) {
      const j = JSON.parse(texto);
      for (const ev of j.events || []) {
        if (!ev.segs) continue;
        const ini = (ev.tStartMs || 0) / 1000, dur = (ev.dDurationMs || 0) / 1000;
        const segs = ev.segs.filter(x => x.utf8 && x.utf8.trim());
        if (!segs.length) continue;
        if (segs.length === 1 && segs[0].tOffsetMs === undefined && segs[0].utf8.trim().split(/\s+/).length > 1) {
          const pal = segs[0].utf8.trim().split(/\s+/);           // legenda feita por gente: espalha as palavras no tempo
          pal.forEach((w, k) => { if (!lixo(w)) ws.push({ w, s: ini + dur * k / pal.length, e: ini + dur * (k + 1) / pal.length }); });
        } else {
          for (const x of segs) {
            const st = ini + (x.tOffsetMs || 0) / 1000;
            for (const w of x.utf8.trim().split(/\s+/)) if (!lixo(w)) ws.push({ w, s: st, e: st + 0.5, lim: ini + dur });
          }
        }
      }
    } else if (texto.startsWith('<')) {
      const xml = new DOMParser().parseFromString(texto, 'text/xml');
      for (const p of xml.querySelectorAll('p')) {
        const ini = (+p.getAttribute('t') || 0) / 1000, dur = (+p.getAttribute('d') || 0) / 1000;
        const ss = p.querySelectorAll('s');
        if (ss.length) {
          for (const x of ss) { const w = x.textContent.trim(); if (!lixo(w)) { const st = ini + (+x.getAttribute('t') || 0) / 1000; ws.push({ w, s: st, e: st + 0.5, lim: ini + dur }); } }
        } else {
          const pal = p.textContent.trim().split(/\s+/).filter(w => !lixo(w));
          pal.forEach((w, k) => ws.push({ w, s: ini + dur * k / pal.length, e: ini + dur * (k + 1) / pal.length }));
        }
      }
    }
    ws.sort((a, b) => a.s - b.s);
    for (let k = 0; k < ws.length; k++) {
      const nx = ws[k + 1];
      let e = ws[k].e;
      if (ws[k].lim) e = Math.min(e, ws[k].lim);
      if (nx) e = Math.min(e, nx.s);
      ws[k].e = Math.max(ws[k].s + 0.05, e);
      delete ws[k].lim;
      ws[k].s = Math.round(ws[k].s * 100) / 100;
      ws[k].e = Math.round(ws[k].e * 100) / 100;
    }
    return ws;
  }

  // ---------- liga / desliga ----------
  let esperandoLegenda = null;
  async function comecar() {
    const vid = new URLSearchParams(location.search).get('v');
    if (!cfg.ligado || location.pathname !== '/watch' || !vid) { parar(); return; }
    if (s.video === vid && s.ativo) return;
    parar();
    s.video = vid;
    avisar('Dublagem: ligando o app…');
    let r = await pedir(`${VIVO}/saude`);
    if (!r.ok) {
      r = await pedir(`${APP}/api/aovivo/ligar`, 'POST', {});
      if (!r.ok || !(r.dados && r.dados.ok)) { avisar('Abra o app Multi Estúdio para dublar', 'erro'); s.video = null; return; }
    }
    if (s.video !== vid) return;
    avisar('Dublagem: lendo as falas do vídeo…');
    document.documentElement.classList.add('ti-sem-cc');
    esperandoLegenda = { vid, faixa: null, timer: setTimeout(() => {
      if (esperandoLegenda && esperandoLegenda.vid === vid) { esperandoLegenda = null; avisar('Este vídeo não tem legenda para dublar ao vivo', 'erro'); }
    }, 15000) };
    window.postMessage({ fonte: 'ti-ext', tipo: 'pedir-legenda' }, '*');
  }

  async function iniciarSessao(faixa, texto) {
    const vid = faixa.video;
    if (/^pt/.test(faixa.idioma || '')) { avisar('Este vídeo já está em português', 'ok'); return; }
    let palavras = [];
    try { palavras = palavrasDe(texto); } catch (e) {}
    if (!palavras.length) { avisar('Não consegui ler a legenda deste vídeo', 'erro'); return; }
    const v = video();
    const r = await pedir(`${VIVO}/iniciar`, 'POST', { video: vid, titulo: faixa.titulo, idioma: faixa.idioma, palavras,
                                                       voz: cfg.voz, t: v ? v.currentTime : 0 });
    if (!r.ok || s.video !== vid) { if (s.video === vid) avisar((r.dados && r.dados.erro) || 'O app não respondeu', 'erro'); return; }
    s.ativo = true;
    s.total = r.dados.total;
    avisar('Dublagem: traduzindo…');
    prepararAudio();
    s.loop = setInterval(sincronizar, 80);
    s.poll = setInterval(atualizar, 700);
    atualizar();
  }

  function parar() {
    clearInterval(s.loop); clearInterval(s.poll);
    if (esperandoLegenda) { clearTimeout(esperandoLegenda.timer); esperandoLegenda = null; }
    pararVoz();
    const v = video();
    if (s.pausadoPorMim && v) v.play().catch(() => {});
    document.documentElement.classList.remove('ti-sem-cc');
    esconderSelo();
    s = novoEstado();
  }

  window.addEventListener('message', ev => {
    const d = ev.data;
    if (ev.source !== window || !d || d.fonte !== 'ti-gancho' || !esperandoLegenda) return;
    if (d.tipo === 'faixa' && d.video === esperandoLegenda.vid) esperandoLegenda.faixa = d;
    else if (d.tipo === 'erro' && (!d.video || d.video === esperandoLegenda.vid)) {
      clearTimeout(esperandoLegenda.timer); esperandoLegenda = null;
      avisar(d.erro === 'sem-legenda' ? 'Este vídeo não tem legenda para dublar ao vivo' : 'Não consegui ler a legenda deste vídeo', 'erro');
    } else if (d.tipo === 'legenda' && d.video === esperandoLegenda.vid && esperandoLegenda.faixa &&
               (!d.lang || d.lang === esperandoLegenda.faixa.idioma)) {
      const faixa = esperandoLegenda.faixa;
      clearTimeout(esperandoLegenda.timer); esperandoLegenda = null;
      iniciarSessao(faixa, d.texto);
    }
  });

  // ---------- acompanha o que o app já fez ----------
  async function atualizar() {
    if (!s.ativo) return;
    const vid = s.video;
    const r = await pedir(`${VIVO}/estado?video=${encodeURIComponent(vid)}&desde=${s.versao}`);
    if (vid !== s.video) return;
    if (!r.ok) { if (r.status === 404) { s.ativo = false; parar(); comecar(); } return; }
    const d = r.dados;
    for (const x of d.segs) {
      const velho = s.porI.get(x.i);
      if (velho) Object.assign(velho, x); else { s.porI.set(x.i, x); s.segs.push(x); }
    }
    if (d.segs.length) s.segs.sort((a, b) => a.ini - b.ini);
    s.versao = d.versao; s.total = d.total; s.feitas = d.feitas; s.msg = d.msg || '';
    const v = video();
    if (v && Math.abs(v.currentTime - s.ultimaPosicao) > 3) {
      s.ultimaPosicao = v.currentTime;
      pedir(`${VIVO}/posicao`, 'POST', { video: vid, t: v.currentTime });
    }
  }

  function atual(t) {
    // a fala que cobre o instante t (do início dela até o começo da próxima)
    let lo = 0, hi = s.segs.length - 1, achou = -1;
    while (lo <= hi) { const m = (lo + hi) >> 1; if (s.segs[m].ini <= t) { achou = m; lo = m + 1; } else hi = m - 1; }
    if (achou < 0) return { seg: null, prox: s.segs[0] || null };
    const seg = s.segs[achou], prox = s.segs[achou + 1] || null;
    const fimJanela = prox ? prox.ini : seg.fim + 1.5;
    return { seg: t < fimJanela ? seg : null, prox };
  }

  function sincronizar() {
    const v = video();
    if (!v || !s.ativo) return;
    if (!prepararAudio()) { if (!v.paused) avisar('Clique no vídeo para liberar o som da dublagem', 'erro'); return; }
    const t = v.currentTime;
    if (v.paused && !s.pausadoPorMim) { if (s.fonte) pararVoz(); return; }
    if (s.fonte && v.playbackRate !== s.fonte.playbackRate.value) s.fonte.playbackRate.value = v.playbackRate;
    const { seg, prox } = atual(t);

    // pré-carrega o áudio das próximas falas prontas
    let n = 0;
    for (const x of s.segs) { if (x.ini >= t - 1 && x.ok) { carregarBuffer(x); if (++n >= 4) break; } }

    if (s.pausadoPorMim) {
      const alvo = seg || prox;
      const pronto = !alvo || (alvo.ok && s.buffers.has(alvo.i));
      if (pronto) { s.pausadoPorMim = false; s.retomando = true; v.play().catch(() => {}).finally(() => { s.retomando = false; }); avisar('Dublagem ao vivo', 'ok'); }
      return;
    }
    if (!seg) { if (s.fonte && s.tocandoI >= 0) { /* deixa a fala terminar */ } return; }
    if (s.tocandoI === seg.i) return;
    const atraso = t - seg.ini;
    if (seg.ok && s.buffers.has(seg.i)) {
      if (atraso < Math.max(0.6, (seg.dur || 1) * 0.6)) tocar(seg, atraso);
      return;
    }
    if (cfg.esperar && atraso < 0.4 && s.semEsperaI !== seg.i) {
      v.pause();
      s.pausadoPorMim = true;
      avisar(s.msg || `Esperando a dublagem… (${s.feitas} de ${s.total} falas prontas)`);
      pedir(`${VIVO}/posicao`, 'POST', { video: s.video, t });
    }
  }

  // ---------- eventos do vídeo e da página ----------
  document.addEventListener('seeked', ev => {
    if (ev.target !== video() || !s.ativo) return;
    pararVoz();
    s.ultimaPosicao = ev.target.currentTime;
    pedir(`${VIVO}/posicao`, 'POST', { video: s.video, t: ev.target.currentTime });
  }, true);
  document.addEventListener('pause', ev => { if (ev.target === video() && !s.pausadoPorMim) pararVoz(); }, true);
  document.addEventListener('play', ev => {
    if (ev.target !== video()) return;
    if (s.pausadoPorMim && !s.retomando) {                    // você apertou play enquanto esperava: segue sem esperar esta fala
      s.pausadoPorMim = false;
      const { seg } = atual(ev.target.currentTime);
      if (seg) s.semEsperaI = seg.i;
    }
    prepararAudio();
  }, true);
  document.addEventListener('click', () => { if (ctx && ctx.state !== 'running') ctx.resume().catch(() => {}); }, true);
  window.addEventListener('yt-navigate-finish', () => setTimeout(comecar, 600));

  chrome.storage.local.get(PADRAO, v => {
    cfg = { ...PADRAO, ...v };
    comecar();
  });
  chrome.storage.onChanged.addListener(m => {
    const antes = { ...cfg };
    for (const k in m) cfg[k] = m[k].newValue;
    if (!cfg.ligado) { parar(); return; }
    if (!antes.ligado || antes.voz !== cfg.voz) { parar(); comecar(); return; }
    if (antes.legenda !== cfg.legenda) legendaPt('');
  });
})();
