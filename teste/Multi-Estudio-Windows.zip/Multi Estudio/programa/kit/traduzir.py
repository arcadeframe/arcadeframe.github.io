"""
Tradução de falas para português do Brasil, pensada para dublagem: frases naturais
e mais ou menos do mesmo tamanho da original, para caber no tempo.
IA 100% local (mlx-lm): nada sai do computador e não gasta crédito de ninguém.
"""
import json
import re

# o segundo é a reserva (e o modelo do modo Rápido): não baixa nada a mais.
MODELOS_TRADUCAO = ["mlx-community/Qwen3.5-9B-MLX-4bit", "mlx-community/Qwen3-4B-Instruct-2507-4bit"]
# modo Rápido: tradução ligeira (Gemma 4 E4B, Apache 2.0): ~2,5x mais rápida, erra um pouco mais o sentido
MODELOS_RAPIDOS = ["mlx-community/Qwen3-4B-Instruct-2507-4bit", "mlx-community/gemma-4-e4b-it-4bit"]   # Qwen3 4B: 16% mais rápido e errou menos no teste de 20/11
_T = {"modelo": None, "tok": None, "nome": None}

INSTRUCAO = """Você é tradutor de dublagem. Traduza cada fala para português do Brasil falado, natural e direto.
Regras:
- Traduza TUDO o que foi dito, com todos os detalhes: não resuma, não pule informação, não junte ideias. A dublagem tem que cobrir a fala inteira.
- Cada fala tem um teto de caracteres ("max"), porque será falada no mesmo tempo da original. Só encurte se a tradução completa passar do teto, e aí corte palavras sobrando, nunca informação.
- Use o contexto das falas vizinhas para escolher as palavras certas (termos técnicos, gírias, nomes).
- Não traduza nomes próprios nem marcas.
- Responda SOMENTE com um JSON: uma lista de textos, na mesma ordem e com a mesma quantidade de itens da entrada. Nada fora do JSON.
- Nunca use travessão."""


def _perguntar(sistema, usuario, config, lista=True):
    from mlx_lm import generate, load
    if _T["modelo"] is None:
        for nome in MODELOS_TRADUCAO:
            try:
                _T["modelo"], _T["tok"] = load(nome)
                _T["nome"] = nome
                break
            except Exception:
                continue
        if _T["modelo"] is None:
            raise RuntimeError("A IA local não está disponível para traduzir.")
    tok = _T["tok"]
    msgs = [{"role": "system", "content": sistema}, {"role": "user", "content": usuario}]
    try:
        prompt = tok.apply_chat_template(msgs, add_generation_prompt=True, tokenize=False, enable_thinking=False)
    except TypeError:
        prompt = tok.apply_chat_template(msgs, add_generation_prompt=True, tokenize=False)
    if not lista:
        return generate(_T["modelo"], tok, prompt=prompt, max_tokens=700, verbose=False)
    # para assim que a lista JSON fecha (sem isso o modelo segue escrevendo até o limite e fica lento)
    from mlx_lm import stream_generate
    texto, prof, abriu = "", 0, False
    limite = min(2400, 220 + len(usuario) // 2)
    for r in stream_generate(_T["modelo"], tok, prompt=prompt, max_tokens=limite):
        pedaco = r.text
        texto += pedaco
        visivel = re.sub(r"<think>.*?(</think>|$)", "", texto, flags=re.S)
        if "[" in visivel and not abriu:
            abriu = True
        if abriu and "]" in pedaco:
            prof = _profundidade(visivel)
            if prof == 0:
                break
    return texto


def _profundidade(t):
    """Quantos colchetes da lista JSON ainda estão abertos (ignora o que está dentro de aspas)."""
    i = t.find("[")
    if i < 0:
        return 1
    prof, aspas, esc = 0, False, False
    for c in t[i:]:
        if esc:
            esc = False
        elif c == "\\":
            esc = True
        elif c == '"':
            aspas = not aspas
        elif not aspas and c == "[":
            prof += 1
        elif not aspas and c == "]":
            prof -= 1
            if prof == 0:
                return 0
    return max(prof, 1)


def liberar():
    _T.update({"modelo": None, "tok": None})
    try:
        import gc
        import mlx.core as mx
        gc.collect()
        mx.clear_cache()
    except Exception:
        pass


def _texto_item(x):
    """A IA às vezes devolve {"fala": "..."} ou {"traducao": "..."} em vez do texto puro."""
    if isinstance(x, dict):
        for k in ("traducao", "tradução", "texto", "pt", "fala", "translation", "text"):
            if isinstance(x.get(k), str):
                return x[k]
        vals = [v for v in x.values() if isinstance(v, str)]
        return vals[-1] if vals else ""
    return str(x)


def _lista(texto, n):
    texto = re.sub(r"<think>.*?</think>", "", texto, flags=re.S)
    i, j = texto.find("["), texto.rfind("]")
    lista = json.loads(texto[i:j + 1])
    lista = [_texto_item(x).strip() for x in lista]
    if len(lista) != n:
        raise ValueError("quantidade diferente")
    return [x.replace("—", ",").replace("–", ",") for x in lista]


INSTRUCAO_REVISAO = """Você é revisor de dublagem em português do Brasil. Recebe falas originais e a tradução atual.
Para cada item, devolva a tradução corrigida: sentido certo, português natural falado, sem trechos em outra língua,
e cabendo no limite de caracteres ("max"). Se a tradução já está boa, devolva igual.
Se houver um pedido do usuário, siga o pedido.
Responda SOMENTE com um JSON: uma lista de textos, na mesma ordem e quantidade da entrada. Nunca use travessão."""


def falhas(falas, idioma=""):
    """Índices das falas com problema evidente: sem tradução, igual à original, longa demais ou cortada."""
    ruins = []
    for i, f in enumerate(falas):
        pt = (f.get("pt") or "").strip()
        orig = (f.get("texto") or "").strip()
        tempo = max(0.5, f.get("fim", 0) - f.get("ini", 0))
        if not pt:
            ruins.append(i)
        elif not idioma.startswith("pt") and pt.lower() == orig.lower() and len(orig) > 12:
            ruins.append(i)
        elif f.get("cortou") or len(pt) > tempo * 24:
            ruins.append(i)
    return ruins


def revisar(falas, indices, idioma="", config=None, aviso=None, titulo="", pedido_usuario="", lote=8):
    """Revisa só as falas dos `indices`. Devolve {indice: texto_novo} apenas das que mudaram."""
    import time
    import ritmo
    mudou = {}
    for k in range(0, len(indices), lote):
        t0 = time.time()
        if aviso:
            aviso(k / max(1, len(indices)))
        grupo = indices[k:k + lote]
        itens = []
        for i in grupo:
            f = falas[i]
            prox = falas[i + 1]["ini"] if i + 1 < len(falas) else f["fim"] + 1
            seg = max(f["fim"], prox) - f["ini"]
            itens.append({"original": f["texto"], "traducao": f.get("pt", ""), "max": int(max(25, seg * 19))})
        ctx = [falas[j].get("pt", "") for j in range(max(0, grupo[0] - 2), grupo[0])]
        pedido = (f"Vídeo: {titulo or 'sem título'}. Idioma original: {idioma or 'detecte'}.\n"
                  + (f"Pedido do usuário: {pedido_usuario}\n" if pedido_usuario else "")
                  + (f"Falas anteriores (contexto): {json.dumps(ctx, ensure_ascii=False)}\n" if ctx else "")
                  + "Revise:\n" + json.dumps(itens, ensure_ascii=False))
        try:
            novos = _lista(_perguntar(INSTRUCAO_REVISAO, pedido, config), len(grupo))
        except Exception:
            novos = []
            for it in itens:
                try:
                    novos += _lista(_perguntar(INSTRUCAO_REVISAO, "Revise:\n" + json.dumps([it], ensure_ascii=False), config), 1)
                except Exception:
                    novos.append(it["traducao"])
        for i, txt in zip(grupo, novos):
            if txt and txt.strip() != (falas[i].get("pt") or "").strip():
                mudou[i] = txt.strip()
        ritmo.respirar(time.time() - t0)
    return mudou


INSTRUCAO_ENCURTAR = """Você é adaptador de dublagem. Cada fala em português ficou longa demais para o tempo da cena.
Reescreva cada uma com no máximo "max" caracteres, mantendo o sentido principal, natural e falada.
Corte palavras sobrando, troque por sinônimos curtos, resuma. Nunca passe do limite.
Responda SOMENTE com um JSON: uma lista de textos, na mesma ordem e quantidade da entrada. Nunca use travessão."""


INSTRUCAO_ALONGAR = """Você é adaptador de dublagem. Em cada item, a tradução em português ("pt") deixou de fora parte do que
foi dito no "original". Refaça a tradução completa do "original", com tudo o que ele diz, em português natural.
Regras:
- Traduza só o que está no original. É proibido acrescentar palavras, opiniões, explicações ou frases que não estão lá.
- Se a tradução já diz tudo o que está no original, devolva a tradução igual.
- Não passe de "alvo" caracteres.
Responda SOMENTE com um JSON: uma lista de textos, na mesma ordem e quantidade da entrada. Nunca use travessão."""


def alongar(itens, config=None, lote=10):
    """itens = [{"original", "pt", "alvo"}] -> textos mais completos (mesma ordem). Só aceita se ficou mais longo."""
    saida = []
    for k in range(0, len(itens), lote):
        bloco = itens[k:k + lote]
        try:
            novos = _lista(_perguntar(INSTRUCAO_ALONGAR, "Complete:\n" + json.dumps(bloco, ensure_ascii=False), config), len(bloco))
        except Exception:
            novos = [b["pt"] for b in bloco]
        saida += [n if n and len(b["pt"]) < len(n) <= min(b["alvo"] * 1.3, len(b["original"]) * 1.3) else b["pt"]
                  for n, b in zip(novos, bloco)]
    return saida


INSTRUCAO_TITULOS = """Traduza títulos de vídeos para português do Brasil, natural, como um título de vídeo brasileiro.
Regras:
- Nada em caixa alta: só a primeira letra e os nomes próprios em maiúscula.
- Não traduza nomes próprios, marcas e modelos (Bugatti Veyron, iPhone, Ferrari).
- Valores e números como no original ($700,000 vira US$ 700 mil).
- Título que já está em português: só arrume a caixa alta.
Responda SOMENTE com um JSON: uma lista de textos, na mesma ordem e quantidade da entrada. Nunca use travessão."""


def titulos_pt(titulos, config=None, lote=12):
    """Títulos na língua original -> títulos em português (mesma ordem). Se falhar, devolve o original."""
    saida = []
    for k in range(0, len(titulos), lote):
        bloco = titulos[k:k + lote]
        try:
            novos = _lista(_perguntar(INSTRUCAO_TITULOS, json.dumps(bloco, ensure_ascii=False), config), len(bloco))
        except Exception:
            novos = bloco
        saida += [(n or o).strip().replace("—", ",").replace("–", ",")[:140] for n, o in zip(novos, bloco)]
    return saida


def resumir(textos, titulo="", config=None):
    """Resumo do vídeo em português: 1 frase + até 5 tópicos curtos."""
    corpo = " ".join(textos)
    if len(corpo) > 14000:                       # vídeos longos: pega começo, meio e fim
        corpo = corpo[:5000] + " [...] " + corpo[len(corpo) // 2 - 2000:len(corpo) // 2 + 2000] + " [...] " + corpo[-5000:]
    sistema = ("Resuma o vídeo em português do Brasil: uma frase de abertura e depois até 5 tópicos curtos começando com \"- \". "
               "Direto, sem enrolação. Nunca use travessão.")
    try:
        r = _perguntar(sistema, f"Título: {titulo}\nTranscrição:\n{corpo}", config, lista=False)
        r = re.sub(r"<think>.*?</think>", "", r, flags=re.S).strip()
        return r.replace("—", ",").replace("–", ",")[:1500]
    except Exception:
        return ""


INSTRUCAO_PRONUNCIA = """Você prepara textos para um locutor virtual brasileiro, que lê tudo com fonética do português.
Recebe uma lista de palavras que aparecem numa dublagem (nomes, marcas, termos em inglês ou outra língua).
Para cada palavra que esse locutor leria ERRADO, escreva como ela deve ser escrita para soar do jeito que um brasileiro fala no dia a dia.
Exemplos: Bugatti -> Bugáti, airbag -> érbégue, Audi -> Áudi, Chiron -> Xirón, YouTube -> Iutúbi, Ferrari -> Ferrári, Instagram -> Instagrãm, workshop -> uôrcxóp, ok -> okêi.
Palavras que já soam certo (português comum) ficam de fora.
Responda SOMENTE com um JSON objeto {"palavra": "como ler"}. Nunca use travessão."""


def pronuncias(pares, config=None):
    """pares = [(fala original, fala em português)]. Descobre palavras estrangeiras e nomes que ficaram no
    português (ex.: airbag, Bugatti) e devolve [{"de", "para"}] para o locutor ler direito.
    Só afeta a voz: a legenda continua com a grafia original."""
    from collections import Counter
    cont = Counter()
    for orig, t in pares:
        orig_l = set(w.lower() for w in re.findall(r"[A-Za-z][A-Za-z0-9'\-]+", orig or ""))
        for w in re.findall(r"[A-Za-zÀ-ÿ][A-Za-zÀ-ÿ0-9'\-]{1,}", t):
            wl = w.lower()
            singular = wl[:-1] if wl.endswith("s") else wl
            ficou_igual = len(wl) >= 3 and (wl in orig_l or singular in orig_l or singular + "s" in orig_l)
            estrangeira = (w[0].isupper() and not t.startswith(w)) or re.search(r"[kwy]|tt|ff|gg|sh|th|ck|oo|ee|ght", wl)
            if ficou_igual or estrangeira:
                cont[w] += 1
    candidatas = [w for w, _ in cont.most_common(80)]
    if not candidatas:
        return []
    try:
        r = _perguntar(INSTRUCAO_PRONUNCIA, "Palavras:\n" + json.dumps(candidatas, ensure_ascii=False), config, lista=False)
        r = re.sub(r"<think>.*?</think>", "", r, flags=re.S)
        i, j = r.find("{"), r.rfind("}")
        mapa = json.loads(r[i:j + 1])
    except Exception:
        return []
    saida = []
    for de, para in mapa.items():
        de, para = str(de).strip(), str(para).strip().replace("—", " ")
        if de and para and de.lower() != para.lower() and de in candidatas and len(para) < 40:
            saida.append({"de": de, "para": para})
    return saida


def encurtar(itens, config=None, lote=10):
    """itens = [{"original", "pt", "max"}] -> lista de textos encurtados (mesma ordem)."""
    saida = []
    for k in range(0, len(itens), lote):
        bloco = itens[k:k + lote]
        try:
            novos = _lista(_perguntar(INSTRUCAO_ENCURTAR, "Encurte:\n" + json.dumps(bloco, ensure_ascii=False), config), len(bloco))
        except Exception:
            novos = [b["pt"] for b in bloco]
        saida += [n if n and len(n) < len(b["pt"]) else b["pt"] for n, b in zip(novos, bloco)]
    return saida


def traduzir(falas, idioma="", config=None, aviso=None, lote=10, segundos=None, titulo=""):
    """falas = lista de textos na língua original -> lista em português, mesma ordem.
    segundos = tempo disponível para cada fala (vira limite de caracteres)."""
    import time
    import ritmo
    segundos = segundos or [None] * len(falas)
    saida = []
    for ini in range(0, len(falas), lote):
        t0 = time.time()
        bloco = falas[ini:ini + lote]
        if aviso:
            aviso(ini / max(1, len(falas)))
        itens = [{"fala": f, "max": int(max(25, s * 19)) if s else None} for f, s in zip(bloco, segundos[ini:ini + lote])]
        antes = falas[max(0, ini - 3):ini]
        pedido = (f"Vídeo: {titulo or 'sem título'}. Idioma original: {idioma or 'detecte'}.\n"
                  + (f"Falas anteriores (só contexto, não traduza): {json.dumps(antes, ensure_ascii=False)}\n" if antes else "")
                  + "Traduza estas falas:\n" + json.dumps(itens, ensure_ascii=False))
        try:
            saida += _lista(_perguntar(INSTRUCAO, pedido, config), len(bloco))
        except Exception:
            for it in itens:                         # plano B: uma por vez
                try:
                    saida += _lista(_perguntar(INSTRUCAO, "Traduza estas falas:\n" + json.dumps([it], ensure_ascii=False), config), 1)
                except Exception:
                    saida.append(it["fala"])
        ritmo.respirar(time.time() - t0)
    return saida
