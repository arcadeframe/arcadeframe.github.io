"""
Dublar vídeo: link do YouTube (ou arquivo) -> vídeo dublado em português.

  1. baixa o vídeo (yt-dlp, sem login em conta nenhuma)
  2. separa a voz do fundo (Demucs)
  3. transcreve as falas com o tempo de cada uma (Whisper, via mlx-whisper)
  4. traduz para português (IA da conversa)
  5. narra cada fala (Chatterbox) e encaixa no tempo da original
  6. mistura com o fundo original e renderiza o vídeo (ffmpeg)

Uso pessoal: para assistir. Não republicar vídeos de terceiros.
"""
import json
import re
import subprocess
import threading
import time
from pathlib import Path

import numpy as np
import soundfile as sf

MODELO_WHISPER = "mlx-community/whisper-large-v3-turbo"
SR = 44100
ACELERA_MAX = 1.35
PARALELO_RAPIDO = 3


def ffmpeg():
    import imageio_ffmpeg
    return imageio_ffmpeg.get_ffmpeg_exe()


def _rodar(args):
    r = subprocess.run(args, capture_output=True, text=True)
    if r.returncode != 0:
        raise RuntimeError("ffmpeg falhou: " + r.stderr[-400:])
    return r


def formato(resolucao):
    """Escolhe o vídeo até a resolução pedida (0 = a melhor). Prefere mp4/H.264, que abre em qualquer lugar."""
    if not resolucao:
        return "bv*+ba/b"
    h = int(resolucao)
    return (f"bv*[height<={h}][vcodec^=avc1]+ba[ext=m4a]/bv*[height<={h}][ext=mp4]+ba[ext=m4a]/"
            f"bv*[height<={h}]+ba/b[height<={h}]/b")


def baixar(url, pasta, aviso=None, resolucao=1080):
    import os
    import sys
    import yt_dlp
    # o YouTube exige um interpretador de JavaScript (deno), instalado junto no ambiente do app
    pasta_bin = str(Path(sys.executable).parent)
    if pasta_bin not in os.environ.get("PATH", ""):
        os.environ["PATH"] = pasta_bin + os.pathsep + os.environ.get("PATH", "")

    def gancho(d):
        if aviso and d.get("status") == "downloading":
            total = d.get("total_bytes") or d.get("total_bytes_estimate") or 0
            if total:
                aviso(d.get("downloaded_bytes", 0) / total)
    opcoes = {"outtmpl": str(Path(pasta) / "original.%(ext)s"), "noplaylist": True, "quiet": True, "no_warnings": True,
              "format": formato(resolucao),
              "merge_output_format": "mp4", "ffmpeg_location": ffmpeg(), "progress_hooks": [gancho]}
    import rede
    opcoes.update(rede.opcoes(url))

    def fazer(rota):
        with rede.vez_do_youtube(url), yt_dlp.YoutubeDL(rota(opcoes)) as y:
            return y.extract_info(url, download=True)
    remedio = getattr(rede, "com_remedio", None) or (lambda u, f, *a, **k: f(lambda o: o))   # app aberto desde antes da atualização
    info = remedio(url, fazer)                    # YouTube recusou? tenta os outros caminhos sozinho
    arq = next(iter(sorted(Path(pasta).glob("original.*"), key=lambda p: p.suffix != ".mp4")), None)
    if not arq:
        raise RuntimeError("O vídeo não foi baixado.")
    dados = {"titulo": rede.titulo_de(url) or info.get("title") or "video", "duracao": info.get("duration") or 0,
             "canal": info.get("uploader") or "", "arquivo": arq.name}
    (Path(pasta) / "baixado.json").write_text(json.dumps(dados, ensure_ascii=False), encoding="utf-8")
    return arq, dados


def ja_baixado(pasta):
    """Se o vídeo já foi baixado antes (pré-download da fila), devolve (arquivo, info)."""
    marca = Path(pasta) / "baixado.json"
    if marca.exists():
        info = json.loads(marca.read_text(encoding="utf-8"))
        arq = Path(pasta) / info.get("arquivo", "original.mp4")
        if arq.exists():
            return arq, info
    return None


MODELO_PARAKEET = "mlx-community/parakeet-tdt-0.6b-v3"     # NVIDIA, CC-BY-4.0: 25 línguas europeias
IDIOMAS_PARAKEET = {"en", "es", "fr", "de", "it", "pt", "nl", "pl", "ru", "uk", "cs", "sk", "sl", "hr", "bg", "ro", "hu",
                    "el", "sv", "da", "fi", "et", "lv", "lt", "mt"}


def idioma_do_audio(audio):
    """O Whisper só ouve 30 s para descobrir a língua (rápido)."""
    import mlx_whisper
    try:
        r = mlx_whisper.transcribe(audio[: 16000 * 30].astype(np.float32), path_or_hf_repo=MODELO_WHISPER, verbose=None,
                                   condition_on_previous_text=False)
        return r.get("language", "")
    except Exception:
        return ""


def transcrever_parakeet(audio):
    """Parakeet TDT v3: 4x mais rápido que o Whisper e pula menos fala. Devolve as palavras com tempo."""
    import tempfile
    from mlx_audio.stt import load
    m = load(MODELO_PARAKEET)
    with tempfile.TemporaryDirectory() as d:
        arq = Path(d) / "voz16k.wav"
        sf.write(str(arq), audio, 16000)
        r = m.generate(str(arq), chunk_duration=30.0, overlap_duration=2.0)
    palavras = _palavras_parakeet(r)
    try:
        palavras += repescar_parakeet(m, audio, palavras)
        palavras.sort(key=lambda w: w["start"])
    except Exception:
        import traceback
        traceback.print_exc()
    del m
    try:
        import gc
        import mlx.core as mx
        gc.collect()
        mx.clear_cache()
    except Exception:
        pass
    return palavras


ENCHIMENTO = {"uh", "um", "mm", "hmm", "mm-hmm", "mhm", "ha", "haha", "oh", "ah", "okay", "ok", "yeah", "yes", "no", "wow",
              "huh", "hey", "oi", "eh", "aw", "whoa", "yep", "nope", "gotcha", "right", "so", "and"}


HESITACAO = re.compile(r"(?i)(?<![\w'-])(uh+|um+|uhm|erm?|hm+|mm+|ah+)(?![\w'-])[,.…]*\s*")


def tirar_hesitacao(falas, idioma):
    """Tira "uh", "um", "hmm" antes de traduzir: viravam falas soltas como "Um" e "Isso, ah" na dublagem."""
    if not str(idioma or "").startswith("en"):
        return falas
    saida = []
    for f in falas:
        t = re.sub(r"\s+([,.!?])", r"\1", HESITACAO.sub("", f["texto"])).strip(" ,;-")
        if re.search(r"[A-Za-z0-9]", t):
            f["texto"] = t[0].upper() + t[1:]
            saida.append(f)
    return saida


def juntar_pedacos(falas, max_s=7.0, folga=1.0):
    """Pedaço solto ("Just the", "If", "That's") vira parte da fala seguinte: traduz melhor e soa natural."""
    saida = []
    for f in falas:
        ant = saida[-1] if saida else None
        if ant and len(ant["texto"].split()) <= 3 and not re.search(r"[.!?…]$", ant["texto"].strip()) \
                and f["ini"] - ant["fim"] <= folga and f["fim"] - ant["ini"] <= max_s:
            resto = f["texto"]
            ult = ant["texto"].rstrip(" ,").split()[-1].lower()
            if resto.split() and resto.split()[0].lower().strip(",") == ult:          # "If" + "If you work..." (repetiu)
                ant["texto"] = " ".join(ant["texto"].rstrip(" ,").split()[:-1])
            resto = resto[0].lower() + resto[1:] if resto[:2] != "I " and ant["texto"] else resto
            ant["texto"] = (ant["texto"].rstrip(" ,") + " " + resto).strip()
            ant["fim"] = f["fim"]
            continue
        saida.append(dict(f))
    return saida


def repescar_parakeet(m, audio, palavras, sr=16000):
    """Segunda passada só nos buracos: trecho com som de voz e sem nenhuma palavra transcrita.
    Isolado, o Parakeet pega frases que tinha pulado no meio de barulho. Risada, "uh", "okay" e
    letra de música repetida ficam de fora."""
    import tempfile
    hop = int(sr * 0.05)
    n = len(audio) // hop
    if n == 0:
        return []
    db = 20 * np.log10(np.sqrt(np.mean(audio[:n * hop].reshape(n, hop) ** 2, axis=1)) + 1e-9)
    marcas = [(0.0, 0.0)] + [(float(w["start"]), float(w["end"])) for w in palavras] + [(len(audio) / sr, len(audio) / sr)]
    novas = []
    with tempfile.TemporaryDirectory() as d:
        clip = Path(d) / "trecho.wav"
        for (_, fim_a), (ini_b, _) in zip(marcas[:-1], marcas[1:]):
            if ini_b - fim_a < 1.5:
                continue
            trecho = db[int(fim_a / 0.05):int(ini_b / 0.05)]
            if len(trecho) == 0 or np.sum(trecho > -38) * 0.05 < 1.0:
                continue
            a, b = max(0, int((fim_a - 0.2) * sr)), min(len(audio), int((ini_b + 0.2) * sr))
            sf.write(str(clip), audio[a:b], sr)
            try:
                r = m.generate(str(clip), chunk_duration=30.0, overlap_duration=2.0) if (b - a) > 30 * sr else m.generate(str(clip))
            except Exception:
                continue
            ws = [dict(w, start=w["start"] + a / sr, end=w["end"] + a / sr) for w in _palavras_parakeet(r)]
            ws = [w for w in ws if w["start"] >= fim_a - 0.1 and w["end"] <= ini_b + 0.1]
            limpas = [re.sub(r"[^\w'-]", "", w["word"].lower()) for w in ws]
            uteis = [x for x in limpas if x and x not in ENCHIMENTO]
            if len(uteis) < 3 or (len(limpas) >= 4 and len(set(limpas)) / len(limpas) < 0.5):
                continue
            novas += ws
    return novas


def _palavras_parakeet(r):
    palavras = []
    for frase in r.sentences:
        toks = getattr(frase, "tokens", None) or []
        if not toks:
            palavras.append({"word": " " + frase.text.strip(), "start": float(frase.start), "end": float(frase.end)})
            continue
        for t in toks:
            txt = str(getattr(t, "text", "")).replace("▁", " ")
            ini = float(getattr(t, "start", 0.0))
            fim = float(getattr(t, "end", ini + float(getattr(t, "duration", 0.0))))
            if not txt.strip():
                continue
            if not palavras or txt.startswith(" ") or palavras[-1].get("_fecha"):
                palavras.append({"word": " " + txt.strip(), "start": ini, "end": fim})
            else:
                palavras[-1]["word"] += txt.strip()
                palavras[-1]["end"] = fim
        if palavras:
            palavras[-1]["_fecha"] = True           # a próxima frase começa palavra nova
    for p in palavras:
        p.pop("_fecha", None)
    return palavras


def transcrever(voz_wav):
    import librosa
    import mlx_whisper
    # entrega o áudio já carregado (16 kHz mono): assim o Whisper não precisa do ffmpeg do sistema
    audio, _ = librosa.load(str(voz_wav), sr=16000, mono=True)
    idioma = idioma_do_audio(audio)
    if idioma in IDIOMAS_PARAKEET:
        try:
            palavras = transcrever_parakeet(audio)
            if palavras:
                return frases_por_palavras(palavras), idioma
        except Exception:
            import traceback
            traceback.print_exc()
    r = mlx_whisper.transcribe(audio.astype(np.float32), path_or_hf_repo=MODELO_WHISPER, verbose=None,
                               condition_on_previous_text=False, word_timestamps=True)
    palavras = [w for s in r.get("segments", []) for w in (s.get("words") or [])]
    idioma = r.get("language", "")
    if palavras:
        palavras.sort(key=lambda w: float(w["start"]))
        segs = frases_por_palavras(palavras)
    else:
        segs = [{"ini": float(s["start"]), "fim": float(s["end"]), "texto": s["text"].strip()}
                for s in r.get("segments", []) if s.get("text", "").strip()]
    return segs, idioma


def repescar_buracos(audio, palavras, idioma, sr=16000):
    """Segunda passada: o Whisper às vezes pula fala no meio de barulho (motor, música).
    Onde ficou um buraco sem transcrição mas a faixa de voz tem som de fala, transcreve só aquele trecho."""
    import mlx_whisper
    hop = int(sr * 0.05)
    n = len(audio) // hop
    if n == 0:
        return []
    rms = np.sqrt(np.mean(audio[:n * hop].reshape(n, hop) ** 2, axis=1))
    db = 20 * np.log10(rms + 1e-9)
    marcas = [(0.0, 0.0)] + [(float(w["start"]), float(w["end"])) for w in palavras] + [(len(audio) / sr, len(audio) / sr)]
    novas = []
    for (_, fim_a), (ini_b, _) in zip(marcas[:-1], marcas[1:]):
        if ini_b - fim_a < 1.5:
            continue
        q0, q1 = int(fim_a / 0.05), int(ini_b / 0.05)
        trecho = db[q0:q1]
        if len(trecho) == 0 or np.sum(trecho > -38) * 0.05 < 1.0:     # menos de 1 s com som de voz: não vale repescar
            continue
        a, b = max(0, int((fim_a - 0.2) * sr)), min(len(audio), int((ini_b + 0.2) * sr))
        try:
            r = mlx_whisper.transcribe(audio[a:b].astype(np.float32), path_or_hf_repo=MODELO_WHISPER, verbose=None,
                                       language=idioma or None, condition_on_previous_text=False, word_timestamps=True)
        except Exception:
            continue
        for s in r.get("segments", []):
            if s.get("no_speech_prob", 0) > 0.6:
                continue
            for w in s.get("words") or []:
                ws, we = float(w["start"]) + a / sr, float(w["end"]) + a / sr
                if ws >= fim_a - 0.05 and we <= ini_b + 0.05 and str(w.get("word", "")).strip():
                    novas.append({"word": w["word"], "start": ws, "end": we})
    return novas


ABREVIACOES = {"mr.", "mrs.", "ms.", "dr.", "st.", "vs.", "jr.", "sr.", "prof.", "inc.", "ltd.", "co.", "etc.", "no.", "approx.", "e.g.", "i.e."}


def frases_por_palavras(palavras, max_s=7.0, pausa=0.45):
    """Remonta as falas em frases inteiras usando o tempo de cada palavra
    (o Whisper às vezes corta no meio da frase)."""
    falas, atual = [], []

    def fechar():
        if atual:
            txt = "".join(w["word"] for w in atual).strip()
            if txt:
                falas.append({"ini": float(atual[0]["start"]), "fim": float(atual[-1]["end"]), "texto": txt})
        atual.clear()

    for w in palavras:
        if atual and float(w["start"]) - float(atual[-1]["end"]) > pausa:
            fechar()
        if atual and float(w["end"]) - float(atual[0]["start"]) > max_s:
            # passaria do limite: corta na última vírgula, se houver; senão antes desta palavra
            corte = max((i for i, x in enumerate(atual[:-1]) if re.search(r"[,;:]$", x["word"].strip())), default=None)
            if corte is not None and corte >= 2:
                resto = atual[corte + 1:]
                del atual[corte + 1:]
                fechar()
                atual.extend(resto)
            else:
                fechar()
        atual.append(w)
        dur = float(w["end"]) - float(atual[0]["start"])
        if re.search(r"[.!?…][\"')\]]*$", w["word"].strip()) and dur >= 0.6 \
                and w["word"].strip().lower() not in ABREVIACOES:
            fechar()
    fechar()
    return falas


def agrupar(segs, max_s=7.0, max_car=140, folga=0.25):
    """Junta pedaços do Whisper em falas completas (até o ponto final ou uma pausa)."""
    falas, atual = [], None
    for s in segs:
        if atual and (s["ini"] - atual["fim"] <= folga and s["fim"] - atual["ini"] <= max_s
                      and len(atual["texto"]) + len(s["texto"]) < max_car
                      and not re.search(r"[.!?…]$", atual["texto"])):
            atual["fim"] = s["fim"]
            atual["texto"] += " " + s["texto"]
        else:
            if atual:
                falas.append(atual)
            atual = dict(s)
    if atual:
        falas.append(atual)
    return falas


def liberar_whisper():
    try:
        from mlx_whisper.transcribe import ModelHolder
        ModelHolder.model = None
        ModelHolder.model_path = None
        import gc
        import mlx.core as mx
        gc.collect()
        mx.clear_cache()
    except Exception:
        pass


def acelerar(audio, sr, taxa):
    """Acelera a fala sem mudar o tom, com o atempo do ffmpeg (WSOLA, feito para voz).
    O time_stretch do librosa (vocoder de fase) deixava a voz robótica e com eco."""
    import tempfile
    if abs(taxa - 1.0) < 0.01:
        return audio
    with tempfile.TemporaryDirectory() as d:
        ent, sai = Path(d) / "e.wav", Path(d) / "s.wav"
        sf.write(str(ent), audio, sr, subtype="FLOAT")
        try:
            _rodar([ffmpeg(), "-y", "-loglevel", "error", "-i", str(ent), "-filter:a", f"atempo={taxa:.4f}",
                    "-ar", str(sr), "-ac", "1", "-c:a", "pcm_f32le", str(sai)])
            out, _ = sf.read(str(sai), dtype="float32")
            return out.reshape(-1)
        except Exception:
            import librosa
            return librosa.effects.time_stretch(audio, rate=taxa)


DESACELERA_MIN = 0.86      # a voz pode ficar até 14% mais lenta para acompanhar quem fala devagar


def encaixar(audio, sr, disponivel_s, fala_s=None):
    """Acelera (até ACELERA_MAX) para caber no espaço; se ainda passar, corta com fade.
    Se a dublagem ficou bem mais curta que a fala original (fala_s), desacelera um pouco para cobrir melhor."""
    dur = len(audio) / sr
    taxa = 1.0
    if dur > disponivel_s * 1.02 and disponivel_s > 0.3:      # até 2% a mais cabe sem acelerar
        taxa = min(ACELERA_MAX, dur / disponivel_s)
        audio = acelerar(audio, sr, taxa)
    elif fala_s and dur < fala_s * 0.8 and dur > 0.6:
        taxa = max(DESACELERA_MIN, dur / (fala_s * 0.9))
        if taxa < 0.98:
            audio = acelerar(audio, sr, taxa)
    limite = int(max(0.3, disponivel_s) * sr)
    cortou = len(audio) > limite + int(0.15 * sr)       # menos de 0,15 s some no fade: não conta como apertada
    if cortou:
        audio = audio[:limite].copy()
        f = min(len(audio), int(0.12 * sr))
        audio[-f:] *= np.linspace(1, 0, f)
    return audio.astype(np.float32), round(taxa, 2), cortou


def _tempo_srt(t):
    ms = int(round(max(0.0, t) * 1000))             # em milésimos inteiros: 0,9996 s não vira "00,1000"
    h, m, s, ms = ms // 3600000, ms // 60000 % 60, ms // 1000 % 60, ms % 1000
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def escrever_srt(falas, caminho, campo="pt"):
    linhas = []
    for i, f in enumerate(falas, 1):
        linhas += [str(i), f"{_tempo_srt(f['ini'])} --> {_tempo_srt(f['fim'])}", f.get(campo) or f["texto"], ""]
    Path(caminho).write_text("\n".join(linhas), encoding="utf-8")


def dublar(origem, pasta, ref_voz, aj, config_ia=None, aviso=None, fundo_original=1.0, ao_saber_titulo=None, resolucao=1080, voz_rapida=None,
           voz_original=0.0, legenda="embutida", traducao_rapida=False, ao_saber_duracao=None, compactar=None,
           motor="voxcpm2"):
    """origem = link ou caminho de vídeo. Devolve dict com o vídeo dublado e os detalhes."""
    import narrar
    import ritmo
    from separar import separar
    from traduzir import traduzir

    pasta = Path(pasta)
    pasta.mkdir(parents=True, exist_ok=True)
    aviso = aviso or (lambda etapa, fracao, texto: None)
    t0 = time.time()
    MOTOR["natural"] = motor if motor in ("voxcpm2", "chatterbox") else "voxcpm2"
    if voz_rapida and narrar.motor_rapido() == "zonos3":      # a voz rápida vai aquecendo enquanto o resto trabalha
        import zonos
        threading.Thread(target=zonos.ligar, daemon=True).start()

    # 1) vídeo
    pronto = ja_baixado(pasta) if re.match(r"https?://", str(origem)) else None
    if pronto:
        video, info = pronto
        aviso(1, 1, "Vídeo já baixado")
        if ao_saber_titulo:
            ao_saber_titulo(info["titulo"])
    elif re.match(r"https?://", str(origem)):
        aviso(1, 0, "Baixando o vídeo")
        video, info = baixar(origem, pasta, lambda f: aviso(1, f, f"Baixando o vídeo · {int(f * 100)}%"), resolucao)
        if ao_saber_titulo:
            ao_saber_titulo(info["titulo"])
    else:
        video, info = Path(origem), {"titulo": Path(origem).stem, "duracao": 0, "canal": ""}
    compacto = {}
    if compactar in ("leve", "media", "forte"):
        # o chip de vídeo trabalha em paralelo com a dublagem (não disputa com a IA)
        import compactar as _cp

        def _compactar():
            try:
                compacto["r"] = _cp.compactar_video(video, pasta / "original_compacto.mp4", compactar)
            except Exception as e:
                compacto["erro"] = str(e)
        compacto["th"] = threading.Thread(target=_compactar, daemon=True)
        compacto["th"].start()
    # 2) voz x fundo (se o app foi fechado no meio, retoma do que já estava pronto)
    faixas = pasta / "faixas"
    if (faixas / "separacao.json").exists() and faixa(faixas, "instrumental").exists() and faixa(faixas, "voz").exists():
        aviso(2, 1, "Voz já separada, retomando")
        duracao = sf.info(str(faixa(faixas, "instrumental"))).duration
        info["duracao"] = round(duracao, 1)
        if ao_saber_duracao:
            ao_saber_duracao(info["duracao"])
    else:
        audio_wav = pasta / "audio.wav"
        _rodar([ffmpeg(), "-y", "-i", str(video), "-vn", "-ac", "2", "-ar", str(SR), str(audio_wav)])
        duracao = sf.info(str(audio_wav)).duration
        info["duracao"] = round(duracao, 1)
        if ao_saber_duracao:
            ao_saber_duracao(info["duracao"])
        aviso(2, 0, "Separando a voz do fundo")
        separar(audio_wav, faixas, "voz", lambda f, t: aviso(2, f, f"Separando a voz do fundo · {int(f * 100)}%"))
        audio_wav.unlink(missing_ok=True)          # já separado: não precisa mais (economiza espaço)

    # 3) e 4) transcrição e tradução (retoma se já tinham terminado antes)
    anterior = None
    try:
        anterior = json.loads((pasta / "falas.json").read_text(encoding="utf-8"))
        if not (anterior.get("traduzido") or (pasta / "pronuncia_auto.json").exists()) or \
                not all(f.get("pt") for f in anterior.get("falas", [])):
            anterior = None
    except Exception:
        anterior = None
    if anterior:
        aviso(4, 1, "Tradução já pronta, retomando")
        falas, idioma = anterior["falas"], anterior.get("idioma", "")
        dicionario = ler_dicionario(pasta)
        try:
            resumo = (pasta / "resumo.txt").read_text(encoding="utf-8")
        except Exception:
            resumo = ""
        salvar_falas(pasta, idioma, falas)
    else:
        # 3) transcrição
        aviso(3, 0, "Transcrevendo as falas")
        with ritmo.Cronometro():
            segs, idioma = transcrever(faixa(pasta / "faixas", "voz"))
        liberar_whisper()
        falas = juntar_pedacos(tirar_hesitacao(agrupar(segs), idioma))
        if not falas:
            raise RuntimeError("Não encontrei fala neste vídeo.")

        # 4) tradução
        if traducao_rapida:
            import traduzir as _tr0
            _tr0.MODELOS_TRADUCAO = list(_tr0.MODELOS_RAPIDOS)
        aviso(4, 0, "Traduzindo para português")
        if idioma.startswith("pt"):
            for f in falas:
                f["pt"] = f["texto"]
        else:
            espacos = [max(f["fim"], (falas[i + 1]["ini"] if i + 1 < len(falas) else duracao)) - f["ini"]
                       for i, f in enumerate(falas)]
            pts = traduzir([f["texto"] for f in falas], idioma, config_ia,
                           lambda fr: aviso(4, fr, f"Traduzindo para português · {int(fr * 100)}%"),
                           segundos=espacos, titulo=info.get("titulo", ""))
            for f, pt in zip(falas, pts):
                f["pt"] = pt
        # 4b) se a tradução saiu com muita falha evidente, corrige só essas falas
        if not idioma.startswith("pt"):
            try:
                import traduzir as _tr
                ruins = _tr.falhas(falas, idioma)
                sem_traducao = [i for i in ruins if falas[i].get("pt", "").strip().lower() == falas[i]["texto"].strip().lower()]
                if traducao_rapida or not (len(ruins) >= 3 and len(ruins) > 0.15 * len(falas)):
                    ruins = sem_traducao          # modo rápido: não para para revisar          # pouca falha: só refaz as que ficaram sem traduzir
                if ruins:
                    aviso(4, 0.95, f"Corrigindo {len(ruins)} falas com problema")
                    for i, txt in _tr.revisar(falas, ruins, idioma, config_ia, titulo=info.get("titulo", "")).items():
                        falas[i]["pt"] = txt
            except Exception:
                pass
        dicionario = ler_dicionario(pasta)
        if not idioma.startswith("pt"):
            try:
                import traduzir as _tr
                aviso(4, 0.97, "Ajustando a pronúncia de nomes e palavras estrangeiras")
                auto = _tr.pronuncias([(f["texto"], f["pt"]) for f in falas], config_ia)
                (pasta / "pronuncia_auto.json").write_text(json.dumps(auto, ensure_ascii=False, indent=1), encoding="utf-8")
                dicionario = ler_dicionario(pasta)
            except Exception:
                import traceback
                traceback.print_exc()
        resumo = ""
        try:
            import traduzir as _tr
            aviso(4, 0.98, "Fazendo o resumo do vídeo")
            resumo = _tr.resumir([f["texto"] for f in falas], info.get("titulo", ""), config_ia)
            (pasta / "resumo.txt").write_text(resumo, encoding="utf-8")
            titulo_portugues(pasta, info.get("titulo", ""), config_ia)
        except Exception:
            pass
        try:
            import traduzir as _tr
            _tr.liberar()
        except Exception:
            pass
        escrever_srt(falas, pasta / "legenda_pt.srt", "pt")
        salvar_falas(pasta, idioma, falas)

    # 5) narração de cada fala (cada uma fica guardada, para revisar depois só o que mudar).
    # Retomando: as falas já narradas ficam, e a voz continua a mesma do começo do vídeo.
    est = pasta / "narracao_estado.json"
    if est.exists():
        st = json.loads(est.read_text(encoding="utf-8"))
        MOTOR["natural"] = st.get("motor") or MOTOR["natural"]
        voz_rapida = st.get("voz_rapida", voz_rapida)
        MOTOR["rapido"] = st.get("rapido") or "kokoro"     # retomando: a voz rápida continua a mesma do começo
    elif (pasta / "vozes").exists() and any((pasta / "vozes").glob("*.wav")):
        MOTOR["natural"] = "chatterbox"          # vozes feitas antes desta versão eram do Chatterbox
        MOTOR["rapido"] = "kokoro"
    else:
        import narrar as _n
        MOTOR["rapido"] = _n.motor_rapido()
    est.write_text(json.dumps({"motor": MOTOR["natural"], "voz_rapida": voz_rapida, "rapido": MOTOR["rapido"]}), encoding="utf-8")
    if voz_rapida and MOTOR["rapido"] == "zonos3":
        aviso(5, 0.0, "Ligando a voz rápida")
        import zonos
        if not zonos.ligar():
            MOTOR["rapido"] = "kokoro"
            est.write_text(json.dumps({"motor": MOTOR["natural"], "voz_rapida": voz_rapida, "rapido": "kokoro"}), encoding="utf-8")
    feitas = sum(1 for i in range(len(falas)) if (pasta / "vozes" / f"{i:04d}.wav").exists())
    pendentes = [i for i in range(len(falas)) if not (pasta / "vozes" / f"{i:04d}.wav").exists()]
    if voz_rapida and MOTOR["rapido"] == "zonos3" and len(pendentes) > 1:
        # o servidor do ZONOS3 atende várias falas de uma vez: 3 por vez, na ordem do vídeo
        from concurrent.futures import ThreadPoolExecutor, as_completed
        ex = ThreadPoolExecutor(PARALELO_RAPIDO)
        try:
            futs = [ex.submit(narrar_fala, pasta, i, falas[i]["pt"], ref_voz, aj, voz_rapida, dicionario=dicionario) for i in pendentes]
            t_fala = time.time()
            for k, fu in enumerate(as_completed(futs)):
                fu.result()
                n = feitas + k + 1
                aviso(5, n / len(falas), f"Dublando fala {n} de {len(falas)}")
                ritmo.respirar(time.time() - t_fala)
                t_fala = time.time()
        except BaseException:
            ex.shutdown(wait=False, cancel_futures=True)
            raise
        ex.shutdown(wait=True)
    for i in pendentes:
        if (pasta / "vozes" / f"{i:04d}.wav").exists():
            continue
        f = falas[i]
        aviso(5, i / len(falas), f"Dublando fala {i + 1} de {len(falas)}" + (f" (retomado, {feitas} já prontas)" if feitas else ""))
        t_fala = time.time()
        narrar_fala(pasta, i, f["pt"], ref_voz, aj, voz_rapida, dicionario=dicionario)
        ritmo.respirar(time.time() - t_fala)
    narrar.liberar()

    # 5b) falas que não cabem nem acelerando: a IA encurta o texto (até 2 rodadas) e só essas são refeitas
    if not idioma.startswith("pt"):
        try:
            import traduzir as _tr
            for rodada in range(1 if traducao_rapida else 2):
                longas = falas_longas(pasta, falas, duracao, folga=0.92 if rodada == 0 else 0.8)
                if not longas:
                    break
                aviso(5, 0.96, f"Encurtando {len(longas)} falas que não cabiam no tempo")
                itens = [{"original": falas[i]["texto"], "pt": falas[i]["pt"], "max": m} for i, m in longas]
                novos = _tr.encurtar(itens, config_ia)
                _tr.liberar()
                for n, ((i, _m), txt) in enumerate(zip(longas, novos)):
                    if txt != falas[i]["pt"]:
                        aviso(5, 0.97, f"Refazendo fala {n + 1} de {len(longas)} mais curta")
                        falas[i].setdefault("pt_longa", falas[i]["pt"])
                        falas[i]["pt"] = txt
                        narrar_fala(pasta, i, txt, ref_voz, aj, voz_rapida, dicionario=dicionario)
            # falas que acabam muito antes da pessoa parar de falar: a IA traduz mais completo (1 rodada)
            curtas = [] if traducao_rapida else falas_curtas(pasta, falas)     # modo rápido: não alonga
            if curtas:
                aviso(5, 0.975, f"Completando {len(curtas)} falas que acabavam antes da hora")
                itens = [{"original": falas[i]["texto"], "pt": falas[i]["pt"], "alvo": a} for i, a in curtas]
                novos = _tr.alongar(itens, config_ia)
                _tr.liberar()
                for n, ((i, _a), txt) in enumerate(zip(curtas, novos)):
                    if txt != falas[i]["pt"]:
                        aviso(5, 0.98, f"Refazendo fala {n + 1} de {len(curtas)} mais completa")
                        falas[i].setdefault("pt_curta", falas[i]["pt"])
                        falas[i]["pt"] = txt
                        narrar_fala(pasta, i, txt, ref_voz, aj, voz_rapida, dicionario=dicionario)
                salvar_falas(pasta, idioma, falas)
            # o que ainda sobrar: a voz rápida fala um pouco mais depressa (soa melhor que acelerar o áudio)
            if voz_rapida and MOTOR["rapido"] != "zonos3":     # no ZONOS3 isso seria só acelerar o áudio: o encaixe já faz
                for i, _m in falas_longas(pasta, falas, duracao):
                    f = falas[i]
                    dur = sf.info(str(pasta / "vozes" / f"{i:04d}.wav")).duration
                    prox = falas[i + 1]["ini"] if i + 1 < len(falas) else duracao
                    disp = max(f["fim"] - f["ini"], prox - f["ini"] - 0.08)
                    vel = min(1.35, dur / (disp * ACELERA_MAX) * 1.05)
                    if vel > 1.02:
                        narrar_fala(pasta, i, f["pt"], ref_voz, aj, voz_rapida, velocidade=vel, dicionario=dicionario)
            narrar.liberar()
            escrever_srt(falas, pasta / "legenda_pt.srt", "pt")
        except Exception:
            import traceback
            traceback.print_exc()

    # 6) mistura e vídeo
    if compacto.get("th"):
        aviso(6, 0, "Terminando de compactar o vídeo")
        compacto["th"].join()
        if compacto.get("r"):
            grande = video
            video = pasta / "original.mp4"
            if grande != video:
                grande.unlink(missing_ok=True)
            (pasta / "original_compacto.mp4").replace(video)
        else:
            (pasta / "original_compacto.mp4").unlink(missing_ok=True)
    aviso(6, 0.1, "Misturando e renderizando o vídeo")
    opcoes = {"fundo_original": fundo_original, "voz_original": voz_original, "legenda": legenda}
    resultado = montar(pasta, video, falas, duracao, aj, opcoes)
    salvar_falas(pasta, idioma, falas)
    resultado.update({"titulo": info["titulo"], "canal": info["canal"], "duracao": info["duracao"], "idioma": idioma,
                      "segundos": round(time.time() - t0, 1), "original": video.name, "opcoes": opcoes, "resumo": resumo,
                      "voz_rapida": voz_rapida, "compactado": compacto.get("r"), "motor": None if voz_rapida else MOTOR["natural"],
                      "rapido": MOTOR["rapido"] if voz_rapida else None})
    (pasta / "dublagem.json").write_text(json.dumps(resultado, ensure_ascii=False, indent=1), encoding="utf-8")
    arrumar_faixas(pasta)
    aviso(6, 1, "Pronto")
    return resultado


def faixa(pasta, nome):
    """Arquivo da faixa (instrumental, voz, voz_dublada), seja .wav ou .flac."""
    for ext in (".flac", ".wav"):
        c = Path(pasta) / f"{nome}{ext}"
        if c.exists():
            return c
    return Path(pasta) / f"{nome}.wav"


def arrumar_faixas(pasta):
    """Guarda as faixas de trabalho em FLAC (sem perda, menos da metade do tamanho) e apaga o que já não serve."""
    pasta = Path(pasta)
    for p in (pasta / "faixas" / "instrumental.wav", pasta / "faixas" / "voz.wav", pasta / "voz_dublada.wav"):
        if p.exists():
            try:
                dados, sr = sf.read(str(p), dtype="int16", always_2d=True)
                sf.write(str(p.with_suffix(".flac")), dados, sr, format="FLAC", subtype="PCM_16")
                p.unlink()
            except Exception:
                pass
    for p in (pasta / "audio.wav", pasta / "dublagem.wav"):
        p.unlink(missing_ok=True)


def falas_longas(pasta, falas, duracao, folga=0.92):
    """[(índice, máximo de caracteres)] das falas que passariam do tempo mesmo acelerando."""
    saida = []
    for i, f in enumerate(falas):
        arq = Path(pasta) / "vozes" / f"{i:04d}.wav"
        if not arq.exists():
            continue
        dur = sf.info(str(arq)).duration
        prox = falas[i + 1]["ini"] if i + 1 < len(falas) else duracao
        disponivel = max(f["fim"] - f["ini"], prox - f["ini"] - 0.08)
        if dur > disponivel * ACELERA_MAX * 1.02:
            alvo = int(len(f["pt"]) * disponivel * ACELERA_MAX / dur * folga)
            saida.append((i, max(12, alvo)))
    return saida


def falas_curtas(pasta, falas, minimo=0.65):
    """[(índice, caracteres alvo)] das falas em que a dublagem acaba bem antes da pessoa parar de falar."""
    saida = []
    for i, f in enumerate(falas):
        arq = Path(pasta) / "vozes" / f"{i:04d}.wav"
        tempo = f["fim"] - f["ini"]
        if not arq.exists() or tempo < 2.0 or len(f.get("texto", "").split()) < 4:
            continue
        if len(f.get("pt", "")) >= len(f.get("texto", "")) * 0.85:   # a tradução já diz tudo: não inventa texto para encher
            continue
        dur = sf.info(str(arq)).duration / DESACELERA_MIN          # o quanto ela ocupa já desacelerando no máximo
        if dur < tempo * minimo:
            saida.append((i, int(len(f["pt"]) * tempo * 0.9 / max(0.3, sf.info(str(arq)).duration))))
    return saida


def titulo_portugues(pasta, titulo, config=None):
    """Título traduzido (guardado em titulo_pt.txt para não traduzir de novo)."""
    arq = Path(pasta) / "titulo_pt.txt"
    if arq.exists():
        return arq.read_text(encoding="utf-8").strip()
    try:
        import traduzir as _tr
        t = _tr.titulos_pt([titulo], config)[0]
    except Exception:
        return ""
    if t:
        arq.write_text(t, encoding="utf-8")
    return t


def salvar_falas(pasta, idioma, falas):
    (Path(pasta) / "falas.json").write_text(json.dumps({"idioma": idioma, "falas": falas, "traduzido": True},
                                                       ensure_ascii=False, indent=1), encoding="utf-8")


def ler_dicionario(pasta):
    """Pronúncia: sua lista (aba Narração) tem prioridade, depois a lista brasileira do app, depois a automática do vídeo."""
    lista = []
    for arq in (Path(pasta).parent.parent / "pronuncia.json",            # a sua lista (aba Narração)
                Path(__file__).resolve().parent / "pronuncia_br.json",    # palavras abrasileiradas que vêm com o app
                Path(pasta) / "pronuncia_auto.json"):                     # o que a IA achou neste vídeo
        try:
            itens = json.loads(arq.read_text(encoding="utf-8"))
        except Exception:
            continue
        for it in itens:
            lista.append(it)
            de, para = str(it.get("de", "")), str(it.get("para", ""))
            if de and para and not de.endswith("s") and " " not in de:          # plural: airbags -> érbéguis
                lista.append({"de": de + "s", "para": para + "s"})
    # palavras com espaço primeiro (land rover antes de rover)
    lista.sort(key=lambda x: -len(str(x.get("de", "")).split()))
    return lista


MOTOR = {"natural": "voxcpm2", "rapido": "auto"}     # natural: VoxCPM2 (ou Chatterbox antigo); rápido: ZONOS3 ou Kokoro


def narrar_fala(pasta, i, texto, ref_voz, aj, voz_rapida=None, velocidade=1.0, dicionario=None):
    import narrar
    if voz_rapida:
        voz, sr = narrar.falar_rapida(texto, voz_rapida, velocidade, dicionario, voz_dir=Path(ref_voz).parent,
                                      motor=MOTOR.get("rapido", "auto"))
    else:
        voz, sr = narrar.falar(texto, ref_voz, aj, dicionario, motor=MOTOR["natural"])
    voz = np.asarray(voz, dtype=np.float32).reshape(-1)
    try:                                   # tira o silêncio que a voz às vezes deixa no começo e no fim
        import librosa
        _, (a, b) = librosa.effects.trim(voz, top_db=38)
        pad = int(0.04 * sr)
        voz = voz[max(0, a - pad):min(len(voz), b + pad)]
    except Exception:
        pass
    d = Path(pasta) / "vozes"
    d.mkdir(exist_ok=True)
    sf.write(str(d / f"{i:04d}.wav"), voz, sr)


def montar(pasta, video, falas, duracao, aj, opcoes):
    """Encaixa as falas guardadas no tempo, mistura com o fundo e grava o vídeo (com legenda que liga e desliga)."""
    import librosa
    pasta = Path(pasta)
    trilha = np.zeros(int(duracao * SR) + SR, dtype=np.float32)
    apertadas = 0
    for i, f in enumerate(falas):
        arq = pasta / "vozes" / f"{i:04d}.wav"
        if not arq.exists():
            continue
        voz, sr = sf.read(str(arq), dtype="float32")
        if voz.ndim > 1:
            voz = voz.mean(1)
        prox = falas[i + 1]["ini"] if i + 1 < len(falas) else duracao
        disponivel = max(f["fim"] - f["ini"], prox - f["ini"] - 0.08)
        voz, taxa, cortou = encaixar(voz, sr, disponivel, f["fim"] - f["ini"])
        f["taxa"], f["cortou"] = taxa, cortou
        apertadas += int(cortou)
        voz = librosa.resample(voz, orig_sr=sr, target_sr=SR)
        voz = nivelar_fala(voz)                       # cada fala no mesmo volume
        a = int(f["ini"] * SR)
        if a >= len(trilha):                          # fala marcada depois do fim do vídeo: não entra
            continue
        b = min(len(trilha), a + len(voz))
        trilha[a:b] += voz[:b - a]
    fundo, _ = sf.read(str(faixa(pasta / "faixas", "instrumental")), dtype="float32", always_2d=True)
    n = min(len(fundo), len(trilha))
    voz_st = narrar_clareza(trilha[:n], aj)
    voz_st = comprimir_voz(voz_st)                    # volume constante ao longo do vídeo
    sf.write(str(pasta / "voz_dublada.flac"), voz_st, SR, format="FLAC", subtype="PCM_16")     # para o pacote do Premiere
    fundo = fundo[:n] * nivel_do_fundo(fundo[:n]) * float(opcoes.get("fundo_original", 1.0))
    fundo = fundo * ganho_ducking(voz_st)[:, None]    # o fundo abaixa enquanto alguém fala
    mix = fundo + voz_st[:, None]
    vo = float(opcoes.get("voz_original") or 0)
    if vo > 0 and faixa(pasta / "faixas", "voz").exists():
        orig, _ = sf.read(str(faixa(pasta / "faixas", "voz")), dtype="float32", always_2d=True)
        m = min(n, len(orig))
        mix[:m] += orig[:m] * vo * 0.5
    mix = finalizar_mix(mix)
    sf.write(str(pasta / "dublagem.wav"), mix, SR, subtype="PCM_16")
    escrever_srt(falas, pasta / "legenda_pt.srt", "pt")
    saida = pasta / "dublado.mp4"
    legenda = opcoes.get("legenda", "embutida")
    base = [ffmpeg(), "-y", "-i", str(video), "-i", str(pasta / "dublagem.wav")]
    feito = False
    if legenda == "queimada":
        srt = str(pasta / "legenda_pt.srt").replace("\\", "/").replace(":", "\\:").replace("'", "\\'")
        estilo = "FontName=Helvetica,FontSize=20,Outline=2,Shadow=0,MarginV=28"
        try:
            import compactar as _cp
            kb = _cp.sondar(video)["kbps"] or 8000
        except Exception:
            kb = 8000
        kb = int(min(8000, max(500, kb * 1.1)))          # não engorda um vídeo que já foi compactado
        for cod in (["-c:v", "hevc_videotoolbox", "-tag:v", "hvc1", "-b:v", f"{kb}k"], ["-c:v", "h264_videotoolbox", "-b:v", f"{kb}k"],
                    ["-c:v", "libx264", "-preset", "veryfast", "-crf", "20"]):
            try:
                _rodar(base + ["-map", "0:v:0", "-map", "1:a:0", "-vf", f"subtitles='{srt}':force_style='{estilo}'"] + cod
                       + ["-c:a", "aac", "-b:a", "192k", "-t", f"{n / SR:.3f}", "-movflags", "+faststart", str(saida)])
                feito = True
                break
            except Exception:
                continue
    if not feito and legenda in ("embutida", "queimada"):
        try:
            _rodar(base + ["-i", str(pasta / "legenda_pt.srt"), "-map", "0:v:0", "-map", "1:a:0", "-map", "2:s:0",
                           "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-c:s", "mov_text",
                           "-metadata:s:s:0", "language=por", "-t", f"{n / SR:.3f}", "-movflags", "+faststart", str(saida)])
            feito = True
        except Exception:
            pass
    if not feito:
        _rodar(base + ["-map", "0:v:0", "-map", "1:a:0", "-c:v", "copy", "-c:a", "aac", "-b:a", "192k",
                       "-t", f"{n / SR:.3f}", "-movflags", "+faststart", str(saida)])
    (pasta / "dublagem.wav").unlink(missing_ok=True)
    return {"video": saida.name, "legenda": "legenda_pt.srt", "falas": len(falas), "apertadas": apertadas}


def pacote_premiere(pasta, destino):
    """Faixas separadas para mixar no Premiere: vídeo original, voz dublada, fundo sem voz, voz original e legenda.
    Tudo em 48 kHz (padrão de vídeo), alinhado no zero da timeline."""
    pasta, destino = Path(pasta), Path(destino)
    destino.mkdir(parents=True, exist_ok=True)
    info = json.loads((pasta / "dublagem.json").read_text(encoding="utf-8"))
    video = pasta / info.get("original", "original.mp4")
    import shutil
    shutil.copy2(video, destino / ("0 video original" + video.suffix))
    for origem, nome in ((faixa(pasta, "voz_dublada"), "1 voz dublada.wav"),
                         (faixa(pasta / "faixas", "instrumental"), "2 fundo sem voz.wav"),
                         (faixa(pasta / "faixas", "voz"), "3 voz original.wav")):
        if origem.exists():
            _rodar([ffmpeg(), "-y", "-i", str(origem), "-ar", "48000", "-c:a", "pcm_s24le", str(destino / nome)])
    if (pasta / "legenda_pt.srt").exists():
        shutil.copy2(pasta / "legenda_pt.srt", destino / "4 legenda em portugues.srt")
    (destino / "LEIA.txt").write_text(
        "Arraste tudo para uma sequência nova, começando no zero da timeline.\n"
        "1 voz dublada: a narração em português.\n2 fundo sem voz: música e efeitos do vídeo original.\n"
        "3 voz original: a fala original, se quiser deixar baixinha por baixo.\n"
        "4 legenda: importe em Arquivo > Importar, vira legenda editável no Premiere.\n", encoding="utf-8")
    return destino


def revisar_dublagem(pasta, ref_voz, aj, config_ia=None, aviso=None, voz_rapida=None, pedido_usuario="", indices=None,
                     mudancas=None, remix=False):
    """Revisão sob pedido: a IA relê a tradução, corrige o que estiver errado e só refaz as falas que mudaram."""
    import narrar
    import traduzir as _tr
    pasta = Path(pasta)
    aviso = aviso or (lambda etapa, fracao, texto: None)
    dados = json.loads((pasta / "falas.json").read_text(encoding="utf-8"))
    idioma, falas = dados.get("idioma", ""), dados["falas"]
    info = json.loads((pasta / "dublagem.json").read_text(encoding="utf-8")) if (pasta / "dublagem.json").exists() else {}
    if voz_rapida is None:
        voz_rapida = info.get("voz_rapida")
    MOTOR["natural"] = info.get("motor") or "chatterbox"
    MOTOR["rapido"] = info.get("rapido") or "kokoro"      # a fala refeita sai na mesma voz rápida do resto
    if remix:                       # só refaz a mixagem (voz e fundo), sem mexer nas falas
        mudou = {}
    elif mudancas:                  # você editou as falas na tela: só refaz essas, sem IA
        mudou = {int(i): str(t).strip().replace("—", ",") for i, t in mudancas.items()
                 if 0 <= int(i) < len(falas) and str(t).strip() and str(t).strip() != falas[int(i)].get("pt", "")}
    else:
        indices = list(range(len(falas))) if indices is None else indices
        aviso(4, 0, "Revisando a tradução")
        mudou = _tr.revisar(falas, indices, idioma, config_ia, lambda fr: aviso(4, fr, f"Revisando a tradução · {int(fr * 100)}%"),
                            titulo=info.get("titulo", ""), pedido_usuario=pedido_usuario)
        _tr.liberar()
    for k, (i, txt) in enumerate(sorted(mudou.items())):
        aviso(5, k / max(1, len(mudou)), f"Refazendo fala {k + 1} de {len(mudou)}")
        falas[i]["pt_antes"] = falas[i].get("pt", "")
        falas[i]["pt"] = txt
        narrar_fala(pasta, i, txt, ref_voz, aj, voz_rapida, dicionario=ler_dicionario(pasta))
    narrar.liberar()
    aviso(6, 0, "Misturando e renderizando o vídeo")
    video = pasta / info.get("original", "original.mp4")
    if not video.exists():
        video = next(iter(sorted(pasta.glob("original.*"))))
    duracao = float(info.get("duracao") or 0) or sf.info(str(faixa(pasta / "faixas", "instrumental"))).duration
    r = montar(pasta, video, falas, duracao, aj, info.get("opcoes") or {})
    salvar_falas(pasta, idioma, falas)
    info.update(r)
    info["revisadas"] = len(mudou)
    (pasta / "dublagem.json").write_text(json.dumps(info, ensure_ascii=False, indent=1), encoding="utf-8")
    arrumar_faixas(pasta)
    aviso(6, 1, "Pronto")
    return info


# ------------------------------------------------------------------ mixagem --
# Voz: cada fala nivelada em -20 dBFS (RMS da parte falada) e depois um compressor suave (alvo -20, até ±6 dB).
# Fundo: levado a -26 dBFS e abaixado 10 dB enquanto há fala (ataque 60 ms, volta em 450 ms, sem bombear).
# Final: -16 LUFS (padrão de internet) e pico máximo de -1 dBFS.
ALVO_VOZ_DB = -20.0
ALVO_FUNDO_DB = -26.0
DUCK_DB = -10.0
QUADRO = 0.01          # 10 ms


def _db(x):
    return 20 * np.log10(np.maximum(x, 1e-9))


def _rms_quadros(x, hop):
    n = len(x) // hop
    if n == 0:
        return np.zeros(1, dtype=np.float32)
    q = x[:n * hop].reshape(n, hop)
    return np.sqrt(np.mean(q.astype(np.float64) ** 2, axis=1)).astype(np.float32)


def _suavizar(alvo, ataque_q, soltura_q):
    """Suaviza uma curva por quadros: desce rápido (ataque) e sobe devagar (soltura)."""
    a, r = np.exp(-1.0 / max(1, ataque_q)), np.exp(-1.0 / max(1, soltura_q))
    out = np.empty_like(alvo)
    g = alvo[0] if len(alvo) else 1.0
    for i, v in enumerate(alvo):
        c = a if v < g else r
        g = c * g + (1 - c) * v
        out[i] = g
    return out


def _por_amostra(g_quadros, n, hop):
    pos = (np.arange(len(g_quadros)) + 0.5) * hop
    return np.interp(np.arange(n), pos, g_quadros).astype(np.float32)


def nivelar_fala(voz):
    """Leva a parte falada de uma fala a ALVO_VOZ_DB."""
    hop = int(SR * QUADRO)
    r = _rms_quadros(voz, hop)
    ativo = r[r > 10 ** (-45 / 20)]
    if len(ativo) == 0:
        return voz
    atual = 20 * np.log10(np.sqrt(np.mean(ativo.astype(np.float64) ** 2)))
    ganho = np.clip(ALVO_VOZ_DB - atual, -12, 18)
    return (voz * 10 ** (ganho / 20)).astype(np.float32)


def comprimir_voz(voz):
    """Compressor suave por quadros: sobe partes baixas e segura as altas (±6 dB), sem mexer no silêncio."""
    hop = int(SR * QUADRO)
    r = _db(_rms_quadros(voz, hop))
    falando = r > -45
    ganho = np.where(falando, np.clip(ALVO_VOZ_DB - r, -6, 6) * 0.6, 0.0).astype(np.float32)
    ganho = _suavizar(ganho, 3, 25)
    g = 10 ** (_por_amostra(ganho, len(voz), hop) / 20)
    return (voz * g).astype(np.float32)


def nivel_do_fundo(fundo):
    """Ganho fixo que leva o fundo (música e ambiente) a ALVO_FUNDO_DB. Quase nunca aumenta (no máximo +2 dB):
    aumentar o fundo trazia junto o resíduo da voz original que a separação deixa, e soava como eco."""
    mono = fundo.mean(1) if fundo.ndim > 1 else fundo
    r = _rms_quadros(mono, int(SR * 0.4))
    ativo = r[r > 10 ** (-60 / 20)]
    if len(ativo) == 0:
        return 1.0
    atual = 20 * np.log10(np.sqrt(np.mean(ativo.astype(np.float64) ** 2)))
    return float(10 ** (np.clip(ALVO_FUNDO_DB - atual, -24, 2) / 20))


def ganho_ducking(voz):
    """Curva de ganho do fundo: DUCK_DB enquanto há fala, 0 dB nas pausas."""
    hop = int(SR * QUADRO)
    r = _db(_rms_quadros(voz, hop))
    alvo = np.where(r > -42, DUCK_DB, 0.0).astype(np.float32)
    g = _suavizar(alvo, 6, 45)
    return 10 ** (_por_amostra(g, len(voz), hop) / 20)


def finalizar_mix(mix):
    """Volume final em -16 LUFS e pico até -1 dBFS (limitador simples por quadros)."""
    try:
        import pyloudnorm as pyln
        m = pyln.Meter(SR)
        alvo = np.asarray(mix[:: 1] if len(mix) < SR * 600 else mix[: SR * 600], dtype=np.float64)
        lufs = m.integrated_loudness(alvo)
        if np.isfinite(lufs):
            mix = mix * float(10 ** (np.clip(-16.0 - lufs, -20, 20) / 20))
    except Exception:
        pass
    teto = 10 ** (-1 / 20)
    hop = int(SR * 0.005)
    pico = np.abs(mix).max(axis=1) if mix.ndim > 1 else np.abs(mix)
    n = len(pico) // hop
    if n:
        pq = np.maximum.reduceat(pico[: n * hop], np.arange(0, n * hop, hop))
        g = np.minimum(1.0, teto / np.maximum(pq, 1e-9)).astype(np.float32)
        g = _suavizar(g, 1, 40)
        gs = _por_amostra(g, len(mix), hop)
        mix = mix * (gs[:, None] if mix.ndim > 1 else gs)
    return np.clip(mix, -teto, teto).astype(np.float32)


def narrar_clareza(voz, aj):
    """Aplica a clareza do locutor (o filtro do narrar trabalha em 24 kHz; aqui a trilha está em 44,1 kHz)."""
    from scipy.signal import butter, sosfilt
    q = float(aj.get("clareza", 0.3))
    y = sosfilt(butter(2, 75, "highpass", fs=SR, output="sos"), voz)
    if q > 0.01:
        y = y + q * 0.5 * sosfilt(butter(2, [2500, 5500], "bandpass", fs=SR, output="sos"), y)
    return y.astype(np.float32)
