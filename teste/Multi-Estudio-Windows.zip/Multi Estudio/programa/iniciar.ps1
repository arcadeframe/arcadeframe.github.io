﻿# Multi Estúdio no Windows: copia o programa para a pasta "Multi Estúdio" na sua pasta de usuário,
# prepara o Python do app (uma vez só) e abre. Depois da primeira vez, use o atalho da Área de Trabalho.
# MULTI_AUTOMATICO=1: sem janelas de pergunta e sem abrir o app (usado nos testes automáticos).
$ErrorActionPreference = "Continue"       # erros dos programas são conferidos um a um (o "Stop" quebra no Windows PowerShell 5)
try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch {}
$pacote = $PSScriptRoot
$casa = if ($env:MULTI_CASA) { $env:MULTI_CASA } else { Join-Path $env:USERPROFILE "Multi Estúdio" }
$auto = ($env:MULTI_AUTOMATICO -eq "1")
$log = Join-Path $casa "instalacao.log"
Add-Type -AssemblyName System.Windows.Forms

function Avisar($texto, $icone = "Information") {
    if ($auto) { Write-Host $texto; return }
    [System.Windows.Forms.MessageBox]::Show($texto, "Multi Estúdio", "OK", $icone) | Out-Null
}
function Registrar($texto) { Add-Content -Path $log -Value ((Get-Date -Format "dd/MM HH:mm:ss") + " " + $texto) -Encoding UTF8 }
function Rodar($exe, [string[]]$argumentos) {
    # roda um programa, guarda o que ele escreveu no instalacao.log e devolve o código de saída
    Registrar ("$ " + $exe + " " + ($argumentos -join " "))
    $saida = & $exe @argumentos 2>&1 | ForEach-Object { "$_" }
    $codigo = $LASTEXITCODE
    if ($saida) { Add-Content -Path $log -Value $saida -Encoding UTF8 }
    return $codigo
}
function PythonPronto($py) {
    if (-not (Test-Path $py)) { return $false }
    & $py -c "import yt_dlp, requests, soundfile, numpy" 2>&1 | Out-Null
    return ($LASTEXITCODE -eq 0)
}

try {
    New-Item -ItemType Directory -Force -Path (Join-Path $casa "kit") | Out-Null

    # 1) programa: copia na primeira vez e troca quando a versão muda (os seus vídeos e módulos ficam)
    $nova = (Get-Content (Join-Path $pacote "versao.txt") -ErrorAction SilentlyContinue | Select-Object -First 1)
    $atual = (Get-Content (Join-Path $casa "versao.txt") -ErrorAction SilentlyContinue | Select-Object -First 1)
    if ((Test-Path (Join-Path $pacote "app")) -and ($nova -ne $atual)) {
        Registrar "copiando o programa, versão $nova (antes: $atual)"
        foreach ($p in "app", "extensao-chrome") {
            $alvo = Join-Path $casa $p
            if (Test-Path $alvo) { Remove-Item -Recurse -Force $alvo }
            Copy-Item -Recurse -Force (Join-Path $pacote $p) $alvo
        }
        Get-ChildItem (Join-Path $casa "kit") -File -ErrorAction SilentlyContinue | Where-Object { $_.Extension -in ".py", ".txt" } | Remove-Item -Force
        Copy-Item -Recurse -Force (Join-Path $pacote "kit\*") (Join-Path $casa "kit")
        foreach ($a in "LEIA-ME.html", "icone.ico", "versao.txt") { Copy-Item -Force (Join-Path $pacote $a) $casa }
        if (-not (Test-Path (Join-Path $casa "app\janela.py"))) { throw "não consegui copiar o programa para $casa" }
    }

    # 2) Python do app (uma vez só, uns 300 MB)
    $py = Join-Path $casa "kit\.venv\Scripts\python.exe"
    $pyw = Join-Path $casa "kit\.venv\Scripts\pythonw.exe"
    if (-not (PythonPronto $py)) {
        if (-not $auto) {
            $r = [System.Windows.Forms.MessageBox]::Show("Bem-vindo ao Multi Estúdio!`n`nNa primeira vez ele precisa baixar o básico (uns 300 MB). Leva de 2 a 5 minutos e precisa de internet.`n`nDepois disso o app abre sozinho. Pode continuar?", "Multi Estúdio", "OKCancel", "Information")
            if ($r -ne "OK") { exit 0 }
        }
        Write-Host "Preparando o Multi Estúdio. Esta janela fecha sozinha quando terminar..."
        $env:Path = "$env:USERPROFILE\.local\bin;$env:Path"
        $uv = (Get-Command uv -ErrorAction SilentlyContinue).Source
        if (-not $uv) {
            Registrar "instalando o uv"
            [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
            Invoke-RestMethod https://astral.sh/uv/install.ps1 | Invoke-Expression
            $env:Path = "$env:USERPROFILE\.local\bin;$env:Path"
            $uv = (Get-Command uv -ErrorAction SilentlyContinue).Source
            if (-not $uv) { throw "não consegui instalar o uv (o gerenciador do Python)" }
        }
        $venv = Join-Path $casa "kit\.venv"
        if (-not (Test-Path $py)) {
            if ((Rodar $uv @("venv", "--python", "3.12", $venv)) -ne 0) { throw "não consegui criar o Python do app" }
        }
        Write-Host "Baixando as bibliotecas..."
        $req = Join-Path $casa "kit\requisitos-base.txt"
        if ((Rodar $uv @("pip", "install", "--python", $py, "-r", $req)) -ne 0) { throw "não consegui baixar as bibliotecas" }
        if (-not (PythonPronto $py)) { throw "a preparação não terminou" }
        Registrar "Python pronto"
    }

    # 3) atalho na Área de Trabalho (abre direto, sem janela preta)
    $janela = Join-Path $casa "app\janela.py"
    try {
        $atalho = Join-Path ([Environment]::GetFolderPath("Desktop")) "Multi Estúdio.lnk"
        $s = (New-Object -ComObject WScript.Shell).CreateShortcut($atalho)
        $s.TargetPath = $pyw
        $s.Arguments = '"' + $janela + '"'
        $s.WorkingDirectory = $casa
        $s.IconLocation = (Join-Path $casa "icone.ico")
        $s.Save()
    } catch { Registrar ("atalho: " + $_.Exception.Message) }

    # 4) abre o app
    if (-not $auto) { Start-Process -FilePath $pyw -ArgumentList ('"' + $janela + '"') -WorkingDirectory $casa }
    exit 0
}
catch {
    Registrar ("ERRO: " + $_.Exception.Message)
    Avisar ("Não consegui preparar o Multi Estúdio: " + $_.Exception.Message + "`n`nConfira a internet e tente de novo. Se repetir, mande para quem te passou o app o arquivo:`n" + $log) "Warning"
    exit 1
}
