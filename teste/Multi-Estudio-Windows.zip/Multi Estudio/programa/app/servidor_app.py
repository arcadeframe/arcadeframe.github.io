"""
Multi Estúdio - servidor local do app.

Roda só no computador do usuário (127.0.0.1) e só atende a janela do app e a extensão do Chrome (kit/guarda.py).
Serve a interface (app/ui) e cuida de três coisas:

  Vídeos    fila de downloads e de dublagens      /api/dublar, /api/fila/..., /api/dublagem/..., /api/pasta/...
  Narração  texto -> locução com as vozes do app  /api/narrar/..., /api/vozes/..., /api/pronuncia
  Casa      espaço em disco, uso do computador    /api/espaco/..., /api/potencia, /api/status

Arquivos: /dublados/, /baixado/<id>/, /baixados/, /arquivos/ (Projetos) e /vozes/.

Uso: python servidor_app.py [porta]
"""

import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import traceback
import uuid
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import quote, unquote

BASE = Path(__file__).resolve().parent.parent          # pasta TrilhaInspirada
KIT = BASE / "kit"
UI = Path(__file__).resolve().parent / "ui"
PROJETOS = BASE / "Projetos"
sys.path.insert(0, str(KIT))

import requests  # noqa: E402

import guarda  # noqa: E402
import licenca  # noqa: E402
import modulos  # noqa: E402
import narrar  # noqa: E402
import espaco  # noqa: E402

try:
    VERSAO = (BASE / "versao.txt").read_text(encoding="utf-8").strip() or "0.5.0"
except Exception:
    VERSAO = "0.5.0"
TRABALHOS = {}


# --------------------------------------------------------------- narração -----

VOZES = BASE / "Vozes"


def semear_vozes():
    """Instalação nova: as 14 vozes prontas do app (sintéticas, de ninguém) já vêm no pacote."""
    origem = KIT / "vozes_prontas"
    if not origem.exists():
        return
    for pasta in sorted(origem.iterdir()):
        if pasta.is_dir() and not (VOZES / pasta.name / "voz.wav").exists():
            try:
                shutil.copytree(pasta, VOZES / pasta.name, dirs_exist_ok=True)
            except Exception:
                traceback.print_exc()


def fazer_demo(voz_id):
    """Amostra "Olá, eu sou o fulano..." de uma voz nova. Se falhar, a voz continua valendo (toca a gravação de referência)."""
    try:
        narrar.gerar_demo(VOZES, voz_id)
    except Exception:
        traceback.print_exc()


_DEMOS = set()


def refazer_demos_padrao():
    """Thiago e Leonor (vozes de fábrica): a amostra "Olá, eu sou o Thiago..." é refeita uma vez, em segundo plano."""
    for vid in ("alex", "dora"):
        if (VOZES / vid / "voz.json").exists() and not (VOZES / vid / "demo.mp3").exists() and vid not in _DEMOS:
            _DEMOS.add(vid)
            threading.Thread(target=fazer_demo, args=(vid,), daemon=True).start()


def vozes_publicas():
    return [{**v, "amostra": f"/vozes/{v['id']}/" + ("demo.mp3" if (VOZES / v["id"] / "demo.mp3").exists() else "voz.wav")}
            for v in narrar.listar_vozes(VOZES)]


PRONUNCIA_ARQ = BASE / "pronuncia.json"


def ler_pronuncia():
    """Sua lista primeiro (tem prioridade), depois as palavras abrasileiradas que vêm com o app."""
    lista = []
    try:
        lista = json.loads(PRONUNCIA_ARQ.read_text(encoding="utf-8"))
    except Exception:
        pass
    return lista


def pronuncia_completa():
    lista = ler_pronuncia()
    try:
        lista = lista + json.loads((BASE / "kit" / "pronuncia_br.json").read_text(encoding="utf-8"))
    except Exception:
        pass
    return lista


def ler_narracao(nid):
    return json.loads((PROJETOS / f"narracao-{nid}" / "narracao.json").read_text(encoding="utf-8"))


def salvar_narracao(n):
    pasta = PROJETOS / f"narracao-{n['id']}"
    pasta.mkdir(parents=True, exist_ok=True)
    (pasta / "narracao.json").write_text(json.dumps(n, ensure_ascii=False, indent=1), encoding="utf-8")


def narracao_publica(n):
    base = f"/arquivos/narracao-{n['id']}/"
    return {**n, "trechos": [{**t, "url": base + t["arquivo"] if t.get("arquivo") else "", "tem_anterior": bool(t.get("anterior"))}
                             for t in n["trechos"]],
            "url": base + n["final"]["arquivo"] + f"?v={int(time.time())}" if n.get("final") else ""}


def trabalho_narrar(tid, nid, indices):
    """Gera os trechos pedidos (todos, ou só os que o usuário mandou refazer) e remonta o arquivo final."""
    t = TRABALHOS[tid]
    try:
        n = ler_narracao(nid)
        pasta = PROJETOS / f"narracao-{nid}"
        ref = VOZES / n["voz"] / "voz.wav"
        if not ref.exists():
            raise RuntimeError("Essa voz não existe mais. Escolha outra.")
        aj = narrar.ajustes(n.get("ajustes"))
        total = len(indices)
        t0 = time.time()
        for k, i in enumerate(indices, 1):
            resto = ""
            if k > 1:
                falta = (time.time() - t0) / (k - 1) * (total - k + 1)
                resto = f" · falta cerca de {int(falta // 60)} min {int(falta % 60):02d} s"
            t["etapa"] = f"Narrando trecho {k} de {total}{resto}"
            t["progresso"] = round((k - 1) / total, 3)
            import ritmo
            with ritmo.Cronometro():
                narrar.gerar_trecho(pasta, n["trechos"][i], i, ref, aj, pronuncia_completa(), motor=n.get("motor", "chatterbox"),
                                    estilo=n.get("estilo"), direcao=n.get("direcao", ""))
            salvar_narracao(n)
            t["narracao"] = narracao_publica(n)
        t["etapa"] = "Juntando tudo"
        n["final"] = narrar.montar(pasta, n["trechos"], aj)
        salvar_narracao(n)
        t["narracao"] = narracao_publica(n)
        t["progresso"] = 1
        t["estado"] = "pronto"
        t["etapa"] = "Pronto"
    except Exception as e:
        traceback.print_exc()
        t["estado"] = "erro"
        t["etapa"] = str(e)


# ---------------------------------------------------------------- dublagem -----

DUBLADOS = BASE / "Dublados"
FILA_ARQ = DUBLADOS / "fila.json"
ETAPAS_DUB = ["Baixar", "Separar voz", "Transcrever", "Traduzir", "Dublar", "Renderizar"]
FILA = []
TRAVA_FILA = threading.Lock()
_TRABALHADOR = {"rodando": False}
_BAIXADOR = {"rodando": False}
BAIXADOS = BASE / "Baixados"
PASTA_ARQ = BASE / "Dublados" / "pasta_downloads.json"


def pasta_baixados():
    """Onde os downloads são salvos: a pasta que você escolheu, ou Baixados dentro do app."""
    try:
        p = Path(json.loads(PASTA_ARQ.read_text(encoding="utf-8"))["pasta"])
        if p.is_dir():
            return p
    except Exception:
        pass
    return BAIXADOS


def perguntar_pasta(pergunta="Onde o Multi Estúdio deve salvar os downloads?"):
    """Abre a janelinha do sistema para escolher uma pasta (funciona com o app escondido também). None = cancelou."""
    if sys.platform == "darwin":
        inicio = str(pasta_baixados()).replace('"', "")
        r = subprocess.run(["osascript", "-e", "activate", "-e",
                            f'POSIX path of (choose folder with prompt "{pergunta}" default location (POSIX file "{inicio}"))'],
                           capture_output=True, text=True, timeout=600)
    elif sys.platform.startswith("win"):
        aspas = lambda t: str(t).replace("'", "''")       # noqa: E731
        ps = ("Add-Type -AssemblyName System.Windows.Forms; [Console]::OutputEncoding = [Text.Encoding]::UTF8; "
              "$f = New-Object System.Windows.Forms.FolderBrowserDialog; "
              f"$f.Description = '{aspas(pergunta)}'; $f.SelectedPath = '{aspas(pasta_baixados())}'; "
              "$j = New-Object System.Windows.Forms.Form -Property @{TopMost = $true}; "
              "if ($f.ShowDialog($j) -eq 'OK') { Write-Output $f.SelectedPath }")
        r = subprocess.run(["powershell", "-NoProfile", "-STA", "-Command", ps], capture_output=True, text=True,
                           encoding="utf-8", timeout=600, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    else:
        return None
    caminho = r.stdout.strip()
    if r.returncode != 0 or not caminho:
        return None
    p = Path(caminho)
    (p / ".teste_multi").write_text("ok")            # confere se dá para gravar lá
    (p / ".teste_multi").unlink()
    return p


def escolher_pasta():
    """Troca a pasta padrão dos downloads."""
    p = perguntar_pasta()
    if not p:
        return None
    PASTA_ARQ.parent.mkdir(exist_ok=True)
    PASTA_ARQ.write_text(json.dumps({"pasta": str(p)}, ensure_ascii=False), encoding="utf-8")
    return p
ESTADO_FILA_ARQ = DUBLADOS / "fila_estado.json"
ESTADO_FILA = {"pausada": False}
MODOS = ("dublar", "video", "audio")


def ler_estado_fila():
    try:
        ESTADO_FILA.update(json.loads(ESTADO_FILA_ARQ.read_text(encoding="utf-8")))
    except Exception:
        pass


def salvar_estado_fila():
    DUBLADOS.mkdir(exist_ok=True)
    ESTADO_FILA_ARQ.write_text(json.dumps(ESTADO_FILA), encoding="utf-8")


def modo_de(it):
    return it.get("modo") or "dublar"


_FILA_MTIME = {"t": 0.0}


def salvar_fila():
    DUBLADOS.mkdir(exist_ok=True)
    with TRAVA_FILA:
        dados = json.dumps(FILA, ensure_ascii=False, indent=1)
    FILA_ARQ.write_text(dados, encoding="utf-8")
    _FILA_MTIME["t"] = FILA_ARQ.stat().st_mtime


PARA_DUBLAR = BASE / "Para dublar"
VIDEOS_EXT = {".mp4", ".mov", ".m4v", ".mkv", ".webm", ".avi", ".mxf"}


def abrir_no_sistema(caminho, mostrar=False):
    """Abre uma pasta (ou mostra um arquivo dentro da pasta dele) no Finder / Explorador de Arquivos."""
    caminho = str(caminho)
    try:
        if sys.platform == "darwin":
            subprocess.Popen(["open", "-R", caminho] if mostrar else ["open", caminho])
        elif sys.platform.startswith("win"):
            subprocess.Popen(["explorer", "/select," + caminho] if mostrar else ["explorer", caminho])
        else:
            subprocess.Popen(["xdg-open", str(Path(caminho).parent) if mostrar else caminho])
    except Exception:
        traceback.print_exc()


def notificar(titulo, texto):
    """Aviso do macOS (canto da tela) quando algo da fila termina."""
    if sys.platform != "darwin":
        return
    t = lambda x: str(x).replace("\\", " ").replace('"', "'")[:180]
    try:
        subprocess.Popen(["osascript", "-e", f'display notification "{t(texto)}" with title "{t(titulo)}" sound name "Glass"'])
    except Exception:
        pass


def vigiar_pasta():
    """Vídeo colocado na pasta 'Para dublar' entra sozinho na fila (voz rápida, opções padrão)."""
    try:
        PARA_DUBLAR.mkdir(exist_ok=True)
        with TRAVA_FILA:
            conhecidos = {x["link"] for x in FILA}
        # cada arquivo entra na fila UMA vez só: se você cancelar, remover ou limpar, ele não volta sozinho
        marca = PARA_DUBLAR / ".ja_entraram.json"
        try:
            vistos = json.loads(marca.read_text(encoding="utf-8"))
        except Exception:
            vistos = {}
        mudou = False
        for c in conhecidos:                           # o que já está na fila conta como visto
            a = Path(c)
            if a.parent == PARA_DUBLAR and a.exists() and a.name not in vistos:
                vistos[a.name] = a.stat().st_size
                mudou = True
        novos = []
        for arq in sorted(PARA_DUBLAR.iterdir()):
            if arq.suffix.lower() not in VIDEOS_EXT or arq.name.startswith("."):
                continue
            if str(arq) in conhecidos:
                continue
            t1 = arq.stat().st_size
            if vistos.get(arq.name) == t1:
                continue
            time.sleep(1)
            if arq.stat().st_size != t1:          # ainda copiando
                continue
            novos.append(novo_item(str(arq), "alex", {}, arq.stem, qualidade="equilibrado"))
            vistos[arq.name] = t1
            mudou = True
        if mudou:
            marca.write_text(json.dumps({k: v for k, v in vistos.items() if (PARA_DUBLAR / k).exists()}), encoding="utf-8")
        if novos:
            with TRAVA_FILA:
                FILA.extend(novos)
            salvar_fila()
            iniciar_trabalhador()
    except Exception:
        traceback.print_exc()


_AOVIVO = {"proc": None}


def ligar_aovivo():
    """Liga (se ainda não estiver ligado) o processo da dublagem ao vivo usado pela extensão do Chrome."""
    try:
        if requests.get("http://127.0.0.1:8791/saude", timeout=1).ok:
            return {"ok": True, "porta": 8791}
    except Exception:
        pass
    p = _AOVIVO.get("proc")
    if p is None or p.poll() is not None:
        log = open(BASE / "aovivo.log", "a")
        _AOVIVO["proc"] = subprocess.Popen([sys.executable, str(BASE / "kit" / "aovivo.py")], stdout=log, stderr=subprocess.STDOUT,
                                           cwd=str(BASE), start_new_session=True)
    for _ in range(40):
        time.sleep(0.5)
        try:
            if requests.get("http://127.0.0.1:8791/saude", timeout=1).ok:
                return {"ok": True, "porta": 8791}
        except Exception:
            pass
    return {"ok": False, "erro": "Não consegui ligar a dublagem ao vivo."}


def ocupados():
    return {x["id"] for x in FILA if x.get("estado") != "pronto"}


_LIMPEZA = {"t": 0.0}


def limpeza_automatica():
    """Uma vez por hora: apaga os arquivos de trabalho das dublagens prontas há mais tempo que o combinado."""
    if time.time() - _LIMPEZA["t"] < 3600:
        return
    _LIMPEZA["t"] = time.time()
    try:
        espaco.limpar_projetos(ocupados=ocupados())
    except Exception:
        traceback.print_exc()


_TITULOS = {"t": 0.0, "rodando": False}


def titulos_pendentes():
    """Traduz os títulos que ainda estão na língua original (quando a fila de dublagem está livre)
    e dá o nome em português ao vídeo dublado (com o número da playlist, se tiver)."""
    if _TITULOS["rodando"] or time.time() - _TITULOS["t"] < 60:
        return
    _TITULOS["t"] = time.time()
    with TRAVA_FILA:
        faltam = [x for x in FILA if x.get("titulo") and not x.get("titulo_pt") and not x.get("titulo_tentado")
                  and not eh_playlist(x["link"])]
    if not faltam or not TRAVA_DUBLAR.acquire(blocking=False):
        return
    _TITULOS["rodando"] = True

    def rodar():
        try:
            import traduzir
            precisa = []
            for x in faltam:
                arq = PROJETOS / f"dublagem-{x['id']}" / "titulo_pt.txt"
                if arq.exists():
                    x["titulo_pt"] = arq.read_text(encoding="utf-8").strip()
                else:
                    precisa.append(x)
            if precisa:
                novos = traduzir.titulos_pt([x["titulo"] for x in precisa], {"provedor": "local"})
                traduzir.liberar()
                for x, t in zip(precisa, novos):
                    x["titulo_tentado"] = True
                    if t and t != x["titulo"]:
                        x["titulo_pt"] = t
                        pj = PROJETOS / f"dublagem-{x['id']}"
                        if pj.exists():
                            (pj / "titulo_pt.txt").write_text(t, encoding="utf-8")
            for x in faltam:
                renomear_dublado(x)
            salvar_fila()
        except Exception:
            traceback.print_exc()
        finally:
            _TITULOS["rodando"] = False
            TRAVA_DUBLAR.release()
    threading.Thread(target=rodar, daemon=True).start()


def renomear_dublado(x):
    """Vídeo dublado já pronto: passa para o nome em português (o .srt junto)."""
    r = x.get("resultado") or {}
    atual = Path(r.get("salvo_em") or "/nao-existe")
    if modo_de(x) != "dublar" or not x.get("titulo_pt") or not atual.exists() or DUBLADOS not in atual.parents:
        return
    novo = livre_em(pasta_do_item(x, DUBLADOS), nome_de_arquivo(x, x["titulo_pt"]) + " (dublado)", ".mp4", atual)
    if novo.resolve() == atual.resolve():
        return
    atual.rename(novo)
    if atual.with_suffix(".srt").exists():
        atual.with_suffix(".srt").rename(novo.with_suffix(".srt"))
    r.update({"salvo_em": str(novo), "url": url_de("/dublados/", DUBLADOS, novo)})


_PARADO = {}


def vigiar_travada():
    """Se um vídeo fica na mesma etapa por 25 min, avisa no Mac (uma vez)."""
    agora = time.time()
    for x in FILA:
        if x.get("estado") != "rodando":
            _PARADO.pop(x["id"], None)
            continue
        marca = (x.get("etapa"), x.get("progresso"))
        p = _PARADO.get(x["id"])
        if not p or p["marca"] != marca:
            _PARADO[x["id"]] = {"marca": marca, "desde": agora, "avisou": False}
        elif not p["avisou"] and agora - p["desde"] > 25 * 60:
            p["avisou"] = True
            notificar("A fila parece parada", f"{x.get('titulo_pt') or x.get('titulo') or 'Vídeo'}: {x.get('etapa')} há 25 min")


def vigiar_fila():
    """Se fila.json for trocado por fora (outro programa), recarrega e retoma o trabalho."""
    while True:
        time.sleep(5)
        limpeza_automatica()
        try:
            vigiar_travada()
            titulos_pendentes()
        except Exception:
            traceback.print_exc()
        vigiar_pasta()
        tarefa_pendente()
        ler_estado_fila()
        if not ESTADO_FILA.get("pausada") and any(x["estado"] == "esperando" for x in FILA):
            iniciar_trabalhador()          # retoma sozinho (ex.: depois da pausa pedida pelo YouTube)
            iniciar_pre_baixar()
        try:
            m = FILA_ARQ.stat().st_mtime if FILA_ARQ.exists() else 0
            if m and m > _FILA_MTIME["t"] + 0.5:
                novos = json.loads(FILA_ARQ.read_text(encoding="utf-8"))
                with TRAVA_FILA:
                    ids = {x["id"] for x in FILA}
                    for it in novos:
                        if it.get("id") not in ids:
                            FILA.append(it)
                _FILA_MTIME["t"] = m
                salvar_fila()
                iniciar_trabalhador()
        except Exception:
            traceback.print_exc()


_VIGIA = {"ok": False}


TAREFAS_PERMITIDAS = {"comparar_motores": ("teste_motores.py", {"asr", "traducao", "voz", "grande", "lote", "lote2", "pronuncia", "yt4"}),
                      "testar_baixador": ("teste_baixador.py", set())}


def tarefa_pendente():
    """Testes de manutenção (só os da lista acima), pedidos por um arquivo .tarefa na pasta do app.
    Rodam escondidos, sem Terminal, e gravam o resultado em Projetos."""
    arq = BASE / ".tarefa"
    if not arq.exists():
        return
    try:
        d = json.loads(arq.read_text(encoding="utf-8"))
        arq.unlink()
        script, ok = TAREFAS_PERMITIDAS[d["tarefa"]]
        args = [a for a in d.get("args", []) if a in ok]
        if d.get("args") and not args:
            return
        log = open(PROJETOS / f"tarefa_{d['tarefa']}.log", "a")
        subprocess.Popen([sys.executable, str(BASE / "kit" / script)] + args, stdout=log, stderr=subprocess.STDOUT,
                         cwd=str(BASE), start_new_session=True)
    except Exception:
        traceback.print_exc()


def atualizar_baixador():
    """O YouTube muda direto e quebra os baixadores: uma vez por semana o app atualiza o yt-dlp sozinho, em segundo plano."""
    marca = BASE / "kit" / ".ytdlp_atualizado"
    try:
        if marca.exists() and time.time() - marca.stat().st_mtime < 7 * 86400:
            return
        time.sleep(60)
        while any(x["estado"] == "rodando" for x in FILA):      # não troca no meio de um download
            time.sleep(120)
        uv = shutil.which("uv") or str(Path.home() / ".local" / "bin" / "uv")
        pacotes = ["-q", "-U", "yt-dlp[default]", "yt-dlp-ejs"]
        cmd = [uv, "pip", "install", "--python", sys.executable] + pacotes if Path(uv).exists() or shutil.which("uv") \
            else [sys.executable, "-m", "pip", "install"] + pacotes
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
        if r.returncode == 0:
            marca.write_text(time.strftime("%Y-%m-%d"), encoding="utf-8")
    except Exception:
        traceback.print_exc()


def atualizar_baixador_ja():
    """O YouTube recusou por todos os caminhos: adianta a atualização do baixador (no máximo uma vez por dia).
    A versão nova passa a valer na próxima vez que o app abrir."""
    marca = BASE / "kit" / ".ytdlp_atualizado"
    try:
        if marca.exists() and time.time() - marca.stat().st_mtime < 86400:
            return
        marca.unlink(missing_ok=True)
        threading.Thread(target=atualizar_baixador, daemon=True).start()
    except Exception:
        traceback.print_exc()


def arrumar_antigos():
    """Uma vez por abertura: tira o peso dos projetos de dublagem já prontos (áudio intermediário apagado,
    faixas em FLAC sem perda, vídeo duplicado entre Projetos e Dublados vira um só)."""
    time.sleep(40)
    try:
        import dublar
        with TRAVA_FILA:
            ativos = {x["id"] for x in FILA if x["estado"] in ("esperando", "rodando")}
            prontos = {x["id"]: x for x in FILA if x["estado"] == "pronto" and modo_de(x) == "dublar"}
        mudou = False
        for pasta in sorted(PROJETOS.glob("dublagem-*")):
            iid = pasta.name[len("dublagem-"):]
            if iid in ativos or not (pasta / "dublagem.json").exists():
                continue
            dublar.arrumar_faixas(pasta)
            it = prontos.get(iid)
            r = (it or {}).get("resultado") or {}
            dup, salvo = pasta / "dublado.mp4", Path(r.get("salvo_em", "") or "/nao-existe")
            if dup.exists() and salvo.exists() and salvo.stat().st_size == dup.stat().st_size:
                dup.unlink()
                r["url"] = "/dublados/" + quote(salvo.name)
                mudou = True
        if mudou:
            salvar_fila()
    except Exception:
        traceback.print_exc()


def carregar_fila():
    tarefa_pendente()
    threading.Thread(target=arrumar_antigos, daemon=True).start()
    threading.Thread(target=atualizar_baixador, daemon=True).start()
    if not _VIGIA["ok"]:
        _VIGIA["ok"] = True
        threading.Thread(target=vigiar_fila, daemon=True).start()
    try:
        itens = json.loads(FILA_ARQ.read_text(encoding="utf-8"))
    except Exception:
        return
    _FILA_MTIME["t"] = FILA_ARQ.stat().st_mtime
    for it in itens:
        if it.get("tentar_apos", 0):       # pausa do YouTube de versão antiga: não existe mais, tenta agora
            it.pop("tentar_apos", None)
            if "em pausa" in str(it.get("etapa", "")):
                it["etapa"] = "Na fila"
            if it.get("estado") == "esperando":
                it["etapa"] = "Na fila"
        if it.get("estado") == "rodando":          # o app fechou no meio: retoma esse (dublar.py continua de onde parou)
            it.update({"estado": "esperando", "etapa": "Na fila", "progresso": 0, "etapa_n": 0})
    FILA[:] = itens
    ler_estado_fila()
    if any(it["estado"] == "esperando" for it in FILA):
        iniciar_trabalhador()


def eh_playlist(link):
    return "list=" in link and "watch?v=" not in link or "/playlist" in link


def expandir_playlist(link):
    import yt_dlp
    import rede
    base = {"extract_flat": "in_playlist", "quiet": True, "no_warnings": True, **rede.opcoes()}

    def fazer(rota):
        with rede.vez_do_youtube(link), yt_dlp.YoutubeDL(rota(base)) as y:
            return y.extract_info(link, download=False)
    info = rede.com_remedio(link, fazer)
    saida = []
    for pos, e in enumerate(info.get("entries") or [], 1):
        url = e.get("url") or e.get("webpage_url")
        if url and not url.startswith("http"):
            url = "https://www.youtube.com/watch?v=" + url
        if url:
            saida.append({"link": url, "titulo": e.get("title") or "", "duracao": e.get("duration"),
                          "ordem": int(e.get("playlist_index") or pos), "playlist": info.get("title") or ""})
    return saida


MEDICOES_ARQ = DUBLADOS / "medicoes.json"
RITMO_PADRAO = {"rapido": 0.6, "equilibrado": 0.8, "caprichado": 1.7}   # segundos de trabalho por segundo de vídeo (M4, 24 GB)


def qualidade_de(it):
    if it.get("qualidade"):
        return it["qualidade"]
    return "equilibrado" if str(it.get("voz", "")).startswith("rapida") else "caprichado"


def ritmo_medido(q):
    try:
        lista = json.loads(MEDICOES_ARQ.read_text(encoding="utf-8")).get(q) or []
        if lista:
            return sum(lista) / len(lista)
    except Exception:
        pass
    return RITMO_PADRAO.get(q, 1.0)


def guardar_medicao(q, ritmo):
    try:
        d = json.loads(MEDICOES_ARQ.read_text(encoding="utf-8")) if MEDICOES_ARQ.exists() else {}
    except Exception:
        d = {}
    d[q] = (d.get(q, []) + [round(ritmo, 3)])[-6:]
    MEDICOES_ARQ.write_text(json.dumps(d), encoding="utf-8")


def previsao(it):
    """Segundos que faltam para este item (None se não dá para estimar ainda)."""
    dur = it.get("duracao")
    if modo_de(it) != "dublar" or not dur or it["estado"] not in ("esperando", "rodando"):
        return None
    import ritmo as _r
    total = float(dur) * ritmo_medido(qualidade_de(it)) * (100 / max(10, _r.potencia())) ** 0.8 + 20
    if it.get("revisar"):
        total = total * 0.35
    if it["estado"] == "rodando" and it.get("inicio"):
        passou = time.time() - it["inicio"]
        return max(total * 0.05, total - passou)
    return total


def completar_duracoes():
    """Lê a duração dos vídeos da fila que ainda não têm (sem baixar), para a previsão de término ficar completa."""
    with TRAVA_FILA:
        it = next((x for x in FILA if x["estado"] == "esperando" and not x.get("duracao") and not x.get("sem_duracao")
                   and x["link"].startswith("http") and not eh_playlist(x["link"])), None)
    if not it:
        return
    import rede
    if rede.eh_youtube(it["link"]):
        # não gasta um pedido extra no YouTube só para saber a duração: ela chega quando o vídeo começa a baixar
        it["sem_duracao"] = True
        return
    try:
        pasta_bin = str(Path(sys.executable).parent)      # o YouTube precisa do deno, que fica junto do Python do app
        if pasta_bin not in os.environ.get("PATH", ""):
            os.environ["PATH"] = pasta_bin + os.pathsep + os.environ.get("PATH", "")
        import yt_dlp
        with yt_dlp.YoutubeDL({"quiet": True, "no_warnings": True, "noplaylist": True, "skip_download": True}) as y:
            info = y.extract_info(it["link"], download=False)
        it["duracao"] = info.get("duration")
        it["titulo"] = it.get("titulo") or info.get("title") or ""
        if not it["duracao"]:
            it["sem_duracao"] = True
    except Exception:
        it["sem_duracao"] = True


def fila_com_previsao():
    with TRAVA_FILA:
        itens = [dict(x) for x in FILA]
    conhecidas = [float(x["duracao"]) for x in itens if x.get("duracao") and modo_de(x) == "dublar"]
    media = sum(conhecidas) / len(conhecidas) if conhecidas else None
    acum, fim, incompleto = 0.0, None, False
    for x in itens:
        if media and not x.get("duracao") and modo_de(x) == "dublar" and x["estado"] == "esperando":
            x["duracao"], x["duracao_estimada"] = media, True
        p = previsao(x)
        if p is not None:
            x["falta_s"] = round(p)
            acum += p
            fim = acum
        elif modo_de(x) == "dublar" and x["estado"] == "esperando":
            incompleto = True
    return itens, (time.time() + fim) if (fim and not incompleto) else None


def novo_item(link, voz, aj, titulo="", resolucao=1080, modo="dublar", opcoes=None, qualidade=None, referer=""):
    if referer or titulo:
        import rede
        rede.registrar(link, referer, titulo)
    return {"referer": referer, "titulo_pagina": titulo,
            "id": f"{time.strftime('%Y%m%d-%H%M%S')}-{uuid.uuid4().hex[:4]}", "link": link, "voz": voz, "ajustes": aj,
            "qualidade": qualidade,
            "titulo": titulo, "resolucao": resolucao, "modo": modo, "opcoes": opcoes or {},
            "estado": "esperando", "etapa": "Na fila", "progresso": 0, "etapa_n": 0}


EXTRAS = DUBLADOS / ".extras"        # o que o player usa para trocar de áudio e de legenda (fica fora da limpeza de 24 h)


def _vtt(falas, campo, arq):
    def t(x):
        h, m, sg = int(x // 3600), int(x % 3600 // 60), x % 60
        return f"{h:02d}:{m:02d}:{sg:06.3f}"
    linhas = ["WEBVTT", ""]
    for f in falas:
        txt = (f.get(campo) or "").strip()
        if txt:
            linhas += [f"{t(f['ini'])} --> {t(max(f['fim'], f['ini'] + 0.3))}", txt, ""]
    arq.write_text("\n".join(linhas), encoding="utf-8")


def fazer_extras(it, pasta, r, dublar):
    """Áudio original (m4a pequeno) e legendas em português e na língua original, para os botões do player."""
    d = EXTRAS / it["id"]
    d.mkdir(parents=True, exist_ok=True)
    base = "/dublados/.extras/" + it["id"] + "/"
    ex = dict(it.get("extras") or {})
    original = pasta / r.get("original", "original.mp4")
    if not (d / "original.m4a").exists() and original.exists():
        subprocess.run([dublar.ffmpeg(), "-y", "-loglevel", "error", "-i", str(original), "-vn", "-ac", "1", "-ar", "32000", "-c:a", "aac", "-b:a", "40k",
                        str(d / "original.m4a")], check=True)
    if (d / "original.m4a").exists():
        ex["audio"] = base + "original.m4a"
    dados = json.loads((pasta / "falas.json").read_text(encoding="utf-8"))
    _vtt(dados["falas"], "pt", d / "pt.vtt")
    ex["pt"] = base + "pt.vtt"
    idioma = (dados.get("idioma") or "")[:2]
    if idioma and idioma != "pt":
        _vtt(dados["falas"], "texto", d / "original.vtt")
        ex.update({"orig": base + "original.vtt", "idioma": idioma})
    it["extras"] = ex


def apagar_extras(ids):
    for i in ids:
        shutil.rmtree(EXTRAS / re.sub(r"[^0-9a-z-]", "", i), ignore_errors=True)


class Cancelado(BaseException):
    """Você apertou Cancelar. É BaseException para atravessar os 'except Exception' do caminho."""


CANCELAR = set()             # ids com cancelamento pedido


def conferir_cancelamento(it):
    if it["id"] in CANCELAR:
        raise Cancelado()


def depois_de_cancelar(it):
    """Tira o vídeo da fila e apaga o que ficou pela metade. Revisão cancelada: o vídeo pronto continua lá."""
    CANCELAR.discard(it["id"])
    if it.get("resultado"):
        it.pop("revisar", None)
        it.update({"estado": "pronto", "etapa": "Pronto", "progresso": 1, "fim": time.time()})
        return
    with TRAVA_FILA:
        FILA[:] = [x for x in FILA if x["id"] != it["id"]]
    shutil.rmtree(PROJETOS / f"dublagem-{it['id']}", ignore_errors=True)
    if modo_de(it) != "dublar":
        for base in {BAIXADOS, pasta_baixados(), Path((it.get("opcoes") or {}).get("pasta") or BAIXADOS)}:
            shutil.rmtree(pasta_do_item(it, base) / ".baixando", ignore_errors=True)


def nome_de_arquivo(it, titulo):
    """Título limpo para nome de arquivo; vídeo de playlist ganha o número da ordem na frente (01 - ...)."""
    nome = re.sub(r"\s{2,}", " ", re.sub(r'[\\/:*?"<>|\n\r\t]+', " ", titulo or "")).strip(" .")[:90] or "video"
    return f"{it['ordem_txt']} - {nome}" if it.get("ordem_txt") else nome


def pasta_do_item(it, base):
    """Vídeo de playlist vai para uma pasta com o nome da playlist; link solto fica direto na pasta geral."""
    nome = re.sub(r"\s{2,}", " ", re.sub(r'[\\/:*?"<>|\n\r\t]+', " ", it.get("playlist") or "")).strip(" .")[:80]
    d = base / nome if nome else base
    d.mkdir(parents=True, exist_ok=True)
    return d


def url_de(prefixo, base, arq):
    return prefixo + quote(str(Path(arq).relative_to(base)))


def livre_em(pasta, base, ext, proprio=None):
    """Caminho que não apaga outro arquivo: acrescenta (2), (3)... se já existir."""
    c = Path(pasta) / f"{base}{ext}"
    n = 2
    while c.exists() and (proprio is None or c.resolve() != Path(proprio).resolve()) and n < 999:
        c = Path(pasta) / f"{base} ({n}){ext}"
        n += 1
    return c


def baixar_item(it):
    import importlib
    import baixador
    importlib.reload(baixador)
    import rede
    rede.registrar(it["link"], it.get("referer"), it.get("titulo_pagina"))
    op = it.get("opcoes") or {}

    def aviso(fracao, vel=""):
        conferir_cancelamento(it)
        it["progresso"] = round(min(1.0, fracao), 3)
        it["etapa"] = f"Baixando · {int(fracao * 100)}%" + (f" · {vel}" if vel else "")
    it["etapa"] = "Começando o download"
    base = Path(op["pasta"]) if op.get("pasta") and Path(op["pasta"]).is_dir() else pasta_baixados()
    r = baixador.baixar_midia(it["link"], pasta_do_item(it, base), modo_de(it), int(it.get("resolucao", 1080)),
                              op.get("formato_audio", "mp3"), bool(op.get("legendas")), aviso,
                              prefixo=f"{it['ordem_txt']} - " if it.get("ordem_txt") else "")
    if op.get("compactar") in ("leve", "media", "forte") and modo_de(it) == "video":
        import compactar
        importlib.reload(compactar)
        it["etapa"] = "Compactando o vídeo"
        c = compactar.compactar_no_lugar(r["arquivo"], op["compactar"],
                                         lambda f: it.update({"progresso": round(f, 3), "etapa": f"Compactando o vídeo · {int(f * 100)}%"}))
        if c:
            r.update({"arquivo": c["arquivo"], "nome": Path(c["arquivo"]).name, "tamanho_mb": c["depois_mb"], "compactado": c})
    it["titulo"] = r["titulo"]
    it["resultado"] = {**r, "url": f"/baixado/{it['id']}/" + quote(Path(r["arquivo"]).name), "salvo_em": r["arquivo"]}


def dublar_item(it):
    import importlib
    import rede
    rede.registrar(it["link"], it.get("referer"), it.get("titulo_pagina"))
    import dublar
    import separar
    import traduzir
    for mod in (separar, traduzir, narrar, dublar):   # pega correções feitas nos arquivos sem reabrir o app
        importlib.reload(mod)
    rapida = narrar.VOZES_RAPIDAS.get(it["voz"], (None,))[0]
    qualidade = it.get("qualidade") or ("equilibrado" if rapida else "caprichado")
    if qualidade in ("rapido", "equilibrado") and not rapida:
        rapida = narrar.kokoro_da_voz(VOZES, it["voz"])     # voz clonada não tem versão rápida: segue natural
    # a voz escolhida vale também no modo rápido: o ZONOS3 fala com a impressão digital dela
    ref = VOZES / {"rapida-alex": "alex", "rapida-dora": "dora"}.get(it["voz"], it["voz"]) / "voz.wav"
    if not ref.exists():
        narrar.garantir_vozes_padrao(VOZES)
        ref = VOZES / it["voz"] / "voz.wav"
        if not ref.exists():
            ref = VOZES / "alex" / "voz.wav"
    cfg = {"provedor": "local"}       # dublagem sempre 100% local (sem créditos de IA)
    ev = BAIXANDO_IDS.get(it["id"])
    if ev:
        it["etapa"] = "Terminando de baixar"
        ev.wait()

    def aviso(etapa, fracao, texto):
        conferir_cancelamento(it)
        it["etapa_n"] = etapa
        it["progresso"] = round((etapa - 1 + min(1.0, fracao)) / len(ETAPAS_DUB), 3)
        it["etapa"] = texto

    pasta = PROJETOS / f"dublagem-{it['id']}"
    op = it.get("opcoes") or {}
    if it.get("revisar"):
        r = dublar.revisar_dublagem(pasta, ref, narrar.ajustes(it.get("ajustes")), cfg, aviso,
                                    pedido_usuario=str(it["revisar"].get("pedido", ""))[:500],
                                    mudancas=it["revisar"].get("mudancas"), remix=bool(it["revisar"].get("remix")))
        it.pop("revisar", None)
    else:
        r = dublar.dublar(it["link"], pasta, ref, narrar.ajustes(it.get("ajustes")), cfg, aviso,
                          resolucao=int(it.get("resolucao", 1080)), voz_rapida=rapida,
                          ao_saber_titulo=lambda tit: it.update({"titulo": tit}),
                          ao_saber_duracao=lambda d: it.update({"duracao": d}),
                          voz_original=float(op.get("voz_original", 0) or 0), legenda=op.get("legenda", "embutida"),
                          traducao_rapida=(qualidade == "rapido"), compactar=op.get("compactar") or None,
                          motor=op.get("motor") or "voxcpm2")
    DUBLADOS.mkdir(exist_ok=True)
    tpt = ""
    try:
        tpt = (pasta / "titulo_pt.txt").read_text(encoding="utf-8").strip()
    except Exception:
        pass
    if tpt:
        it["titulo_pt"] = tpt
    antigo = Path((it.get("resultado") or {}).get("salvo_em") or "/nao-existe")    # revisão: substitui a versão anterior
    destino = livre_em(pasta_do_item(it, DUBLADOS), nome_de_arquivo(it, tpt or r["titulo"]) + " (dublado)", ".mp4", antigo)
    shutil.move(str(pasta / r["video"]), str(destino))      # move (não copia): o vídeo fica só em Dublados
    shutil.copy2(pasta / r["legenda"], destino.with_suffix(".srt"))
    if antigo.exists() and DUBLADOS in antigo.parents and antigo.resolve() != destino.resolve():
        antigo.unlink()
        antigo.with_suffix(".srt").unlink(missing_ok=True)
    it["titulo"] = r["titulo"]
    it["resultado"] = {**r, "url": url_de("/dublados/", DUBLADOS, destino), "salvo_em": str(destino)}
    try:
        fazer_extras(it, pasta, r, dublar)
    except Exception:
        traceback.print_exc()
    if r.get("duracao") and r.get("segundos") and not r.get("revisadas") and "revisadas" not in r:
        import ritmo as _r
        if _r.potencia() >= 90:
            guardar_medicao(qualidade_de(it), r["segundos"] / max(30.0, float(r["duracao"])))


BAIXANDO_IDS = {}            # id -> Event (marcado quando o download adiantado termina)
_ADIANTAR = {"rodando": False}
INTERVALO_ADIANTADO = (40, 100)    # segundos sorteados entre um download adiantado e o próximo


def _proximo_para_baixar():
    agora = time.time()
    with TRAVA_FILA:
        for x in FILA:
            if (x["estado"] == "esperando" and modo_de(x) == "dublar" and not x.get("revisar")
                    and x["link"].startswith("http") and not eh_playlist(x["link"])
                    and x["id"] not in BAIXANDO_IDS and x.get("tentar_apos", 0) <= agora
                    and not (PROJETOS / f"dublagem-{x['id']}" / "baixado.json").exists()):
                return x
    return None


def adiantar_downloads():
    """Vai baixando os próximos vídeos da fila enquanto o atual é dublado: um por vez, com um intervalo
    sorteado entre eles (pedidos espaçados, do jeito que uma pessoa faria). O YouTube tem pausa própria em rede.py."""
    import random
    import rede
    try:
        while True:
            it = _proximo_para_baixar()
            if not it:
                break
            if rede.eh_youtube(it["link"]) and rede.em_pausa():
                break                                   # o vigia retoma depois da pausa
            ev = threading.Event()
            BAIXANDO_IDS[it["id"]] = ev
            it["pre"] = "baixando"
            try:
                import dublar
                pasta = PROJETOS / f"dublagem-{it['id']}"
                pasta.mkdir(parents=True, exist_ok=True)
                _, info = dublar.baixar(it["link"], pasta, None, int(it.get("resolucao", 1080)))
                it["titulo"] = it.get("titulo") or info.get("titulo", "")
                if info.get("duracao"):
                    it["duracao"] = info["duracao"]
                it["pre"] = "baixado"
                it.pop("tentar_apos", None)
                if it["estado"] == "esperando":
                    it["etapa"] = "Na fila"
            except Exception as e:
                it["pre"] = ""
                traceback.print_exc()
                if (rede.eh_bloqueio(str(e)) or isinstance(e, rede.YouTubePausado)) and not any(rede.PAUSAS):
                    # sem pausa automática: não insiste sozinho (insistir piora). Os do YouTube que ainda não
                    # baixaram viram erro de uma vez, e você decide quando apertar "Tentar de novo"
                    with TRAVA_FILA:
                        for x in FILA:
                            if x["estado"] == "esperando" and rede.eh_youtube(x["link"]) and \
                                    not (PROJETOS / f"dublagem-{x['id']}" / "baixado.json").exists():
                                x.pop("tentar_apos", None)
                                x.update({"estado": "erro", "etapa": mensagem_erro(e), "fim": time.time()})
                elif rede.eh_bloqueio(str(e)) or isinstance(e, rede.YouTubePausado):
                    hora = time.strftime("%H:%M", time.localtime(rede.pausa_ate()))
                    with TRAVA_FILA:
                        for x in FILA:
                            if x["estado"] == "esperando" and rede.eh_youtube(x["link"]) and \
                                    not (PROJETOS / f"dublagem-{x['id']}" / "baixado.json").exists():
                                x.update({"tentar_apos": rede.pausa_ate(), "etapa": f"YouTube em pausa até {hora}"})
            finally:
                ev.set()
                BAIXANDO_IDS.pop(it["id"], None)
                salvar_fila()
            time.sleep(random.uniform(*INTERVALO_ADIANTADO))
    finally:
        _ADIANTAR["rodando"] = False


def iniciar_pre_baixar():
    if _ADIANTAR["rodando"] or ESTADO_FILA.get("pausada"):
        return
    if not _proximo_para_baixar():
        return
    _ADIANTAR["rodando"] = True
    threading.Thread(target=adiantar_downloads, daemon=True).start()


def mensagem_erro(e):
    msg = str(e)
    if "confirm you" in msg or "not a bot" in msg:
        atualizar_baixador_ja()
    if "Private video" in msg or "private" in msg.lower() and "video" in msg.lower():
        return "Este vídeo é privado: só o dono consegue ver. O app não entra em contas."
    if "confirm you" in msg or "not a bot" in msg:
        return ("O YouTube recusou este vídeo por todos os caminhos que o app tentou (ele achou que era um robô). "
                "Espere uns minutos e clique em Tentar de novo. Se continuar, feche e abra o app: ele atualiza o baixador sozinho.")
    if "HTTP Error 403" in msg:
        return "O site negou o arquivo do vídeo no meio do download (erro 403). Clique em Tentar de novo: costuma passar na segunda vez."
    if "Sign in" in msg:
        return "Esse site só libera o vídeo com login. Por segurança o app não entra na sua conta."
    if "Unsupported URL" in msg or "is not a valid URL" in msg:
        return "Não reconheci esse link."
    if "Private video" in msg or "unavailable" in msg.lower():
        return "Esse vídeo está privado ou indisponível."
    if "instagram" in msg.lower() and ("login" in msg.lower() or "rate" in msg.lower() or "cookies" in msg.lower()):
        return "O Instagram só libera esse vídeo com login. Por segurança o app não entra na sua conta."
    if "login" in msg.lower() or "cookies" in msg.lower() or "authentication" in msg.lower():
        return "Esse site só libera o vídeo com login. Por segurança o app não entra na sua conta."
    if "HTTP Error 429" in msg or "Too Many Requests" in msg:
        return "O site pediu uma pausa (muitos pedidos seguidos). Tente de novo daqui a pouco."
    if "No space left" in msg:
        return "O disco do Mac está cheio."
    return msg[:300]


def youtube_pausou(it, e):
    """O YouTube pediu verificação: em vez de insistir (o que piora), pausa todos os downloads do YouTube
    e deixa os vídeos esperando. Os que já estão baixados continuam sendo dublados."""
    import rede
    if not (isinstance(e, rede.YouTubePausado) or rede.eh_bloqueio(str(e))) or it.get("resultado"):
        return False
    if not any(rede.PAUSAS):               # pausa automática desligada: o item vira erro, com "Tentar de novo"
        return False
    if not rede.em_pausa():
        rede.bloqueado()
    ate = rede.pausa_ate()
    hora = time.strftime("%H:%M", time.localtime(ate))
    with TRAVA_FILA:
        for x in FILA:
            if x["estado"] in ("esperando", "rodando") and rede.eh_youtube(x["link"]) and x is not it \
                    and not (PROJETOS / f"dublagem-{x['id']}" / "baixado.json").exists() and x["estado"] == "esperando":
                x.update({"tentar_apos": ate, "etapa": f"YouTube em pausa até {hora}"})
    it.update({"estado": "esperando", "tentar_apos": ate, "progresso": 0, "etapa": f"YouTube em pausa até {hora}"})
    threading.Timer(max(5, ate - time.time() + 5), iniciar_trabalhador).start()
    return True


def _proximo(dublagem):
    """Revisões pedidas passam na frente; depois a ordem da fila. Fila pausada não pega item novo."""
    with TRAVA_FILA:
        cands = [x for x in FILA if x["estado"] == "esperando" and (modo_de(x) == "dublar") == dublagem]
        if ESTADO_FILA.get("pausada"):
            return None
        agora = time.time()
        cands = [x for x in cands if x.get("tentar_apos", 0) <= agora
                 or (PROJETOS / f"dublagem-{x['id']}" / "baixado.json").exists()]     # já baixado: pode dublar
        it = next((x for x in cands if x.get("revisar")), None) or (cands[0] if cands else None)
        if it:
            it.update({"estado": "rodando", "etapa": "Começando", "progresso": 0, "etapa_n": 0, "inicio": time.time()})
        return it


def _expandir(it):
    it["etapa"] = "Lendo a playlist"
    videos = expandir_playlist(it["link"])
    if not videos:
        raise RuntimeError("Não encontrei vídeos nessa playlist.")
    novos = [novo_item(v["link"], it["voz"], it.get("ajustes"), v["titulo"], it.get("resolucao", 1080),
                       modo_de(it), it.get("opcoes"), it.get("qualidade")) for v in videos]
    largura = max(2, len(str(max(v["ordem"] for v in videos))))
    for n, v in zip(novos, videos):
        if v.get("duracao"):
            n["duracao"] = v["duracao"]
        n.update({"ordem": v["ordem"], "ordem_txt": str(v["ordem"]).zfill(largura), "playlist": v.get("playlist", "")})
    with TRAVA_FILA:
        i = FILA.index(it)
        FILA[i:i + 1] = novos
    salvar_fila()


def trabalhador_fila():
    """Dublagens: uma por vez (memória do Mac)."""
    try:
        while True:
            it = _proximo(True)
            if not it:
                break
            salvar_fila()
            try:
                if eh_playlist(it["link"]):
                    _expandir(it)
                    continue
                iniciar_pre_baixar()
                with TRAVA_DUBLAR:
                    dublar_item(it)
                it.update({"estado": "pronto", "etapa": "Pronto", "progresso": 1, "fim": time.time()})
                notificar("Vídeo dublado", it.get("titulo") or "Pronto")
            except Cancelado:
                depois_de_cancelar(it)
            except Exception as e:
                traceback.print_exc()
                it.pop("revisar", None)
                if youtube_pausou(it, e):
                    pass
                else:
                    it.update({"fim": time.time(), "estado": "erro" if not it.get("resultado") else "pronto",
                               "etapa": mensagem_erro(e)})
            salvar_fila()
    finally:
        _TRABALHADOR["rodando"] = False


def trabalhador_baixar():
    """Downloads (só vídeo ou só áudio): fila própria, não espera as dublagens."""
    try:
        while True:
            it = _proximo(False)
            if not it:
                break
            salvar_fila()
            try:
                if eh_playlist(it["link"]):
                    _expandir(it)
                    continue
                baixar_item(it)
                it.update({"estado": "pronto", "etapa": "Pronto", "progresso": 1, "fim": time.time()})
                if not any(x["estado"] == "esperando" and modo_de(x) != "dublar" for x in FILA):
                    notificar("Download pronto", it.get("titulo") or "Pronto")
            except Cancelado:
                depois_de_cancelar(it)
            except Exception as e:
                traceback.print_exc()
                if not youtube_pausou(it, e):
                    it.update({"estado": "erro", "etapa": mensagem_erro(e), "fim": time.time()})
            salvar_fila()
    finally:
        _BAIXADOR["rodando"] = False


LIC_MSG = {"vencido": "O período do seu serial acabou. Fale com a Galdino para renovar.",
           "relogio": "A data do computador parece atrasada. Acerte o relógio para continuar.",
           "outra_maquina": "Este serial é de outro computador. Fale com a Galdino.",
           "invalido": "O serial salvo não é válido. Cole o seu serial de novo."}
LIBERADAS_SEM_SERIAL = {"/api/licenca/ativar", "/api/licenca/chave", "/api/potencia", "/api/fila/pausar",
                        "/api/fila/cancelar", "/api/fila/remover", "/api/fila/limpar", "/api/fila/posicao",
                        "/api/mostrar", "/api/abrir_link", "/api/pasta/abrir", "/api/pasta/padrao", "/api/pasta/escolher",
                        "/api/espaco/limpar", "/api/espaco/sobras", "/api/espaco/dias", "/api/espaco/remover",
                        "/api/modulos/remover"}


def lic(cache=True):
    """Estado do serial neste computador (o master não precisa de serial)."""
    try:
        return licenca.estado(extra=(FILA_ARQ,), usar_cache=cache)
    except Exception:
        traceback.print_exc()
        return {"ok": False, "admin": False, "motivo": "invalido", "codigo_maquina": ""}


def licenciado():
    return lic().get("ok", False)


def escolher_arquivo_chave():
    """Janelinha do sistema para escolher o arquivo da chave do master (chave-de-convites.key)."""
    if sys.platform == "darwin":
        r = subprocess.run(["osascript", "-e", "activate", "-e",
                            'POSIX path of (choose file with prompt "Escolha o arquivo da chave de convites (o mesmo do Seletor)")'],
                           capture_output=True, text=True, timeout=600)
    elif sys.platform.startswith("win"):
        ps = ("Add-Type -AssemblyName System.Windows.Forms; [Console]::OutputEncoding = [Text.Encoding]::UTF8; "
              "$f = New-Object System.Windows.Forms.OpenFileDialog; $f.Filter = 'Chave (*.key)|*.key|Todos|*.*'; "
              "$j = New-Object System.Windows.Forms.Form -Property @{TopMost = $true}; "
              "if ($f.ShowDialog($j) -eq 'OK') { Write-Output $f.FileName }")
        r = subprocess.run(["powershell", "-NoProfile", "-STA", "-Command", ps], capture_output=True, text=True,
                           encoding="utf-8", timeout=600, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    else:
        return None
    return r.stdout.strip() or None


def iniciar_trabalhador():
    if not licenciado():
        return
    if not _TRABALHADOR["rodando"]:
        _TRABALHADOR["rodando"] = True
        threading.Thread(target=trabalhador_fila, daemon=True).start()
    if not _BAIXADOR["rodando"]:
        _BAIXADOR["rodando"] = True
        threading.Thread(target=trabalhador_baixar, daemon=True).start()


TRAVA_DUBLAR = threading.Lock()


# ---------------------------------------------------------------- http -----

class Manipulador(SimpleHTTPRequestHandler):
    def __init__(self, *a, **kw):
        super().__init__(*a, directory=str(UI), **kw)

    def log_message(self, *a):
        pass

    def _json(self, dados, codigo=200):
        corpo = json.dumps(dados, ensure_ascii=False).encode("utf-8")
        self.send_response(codigo)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(corpo)))
        self.end_headers()
        self.wfile.write(corpo)

    def _corpo_json(self):
        n = int(self.headers.get("Content-Length", 0))
        return json.loads(self.rfile.read(n) or b"{}")

    def _de_casa(self):
        if guarda.permitido(self.headers):
            return True
        self._json({"erro": "Pedido recusado: só o app e a extensão Multi Estúdio podem falar com este servidor."}, 403)
        return False

    def do_GET(self):
        if not self._de_casa():
            return
        if self.path.startswith("/api/status"):          # a extensão e a janela usam isto para saber se o app está aberto
            return self._json({"app": "multi-estudio", "versao": VERSAO, "motor": False, "projetos": [],
                               "sistema": modulos.SISTEMA, "modulos": sorted(modulos.instalados()),
                               "licenciado": licenciado()})
        if self.path.startswith("/api/licenca"):
            return self._json(lic(cache=False))
        if self.path.startswith("/api/modulos"):
            return self._json(modulos.resumo())
        if self.path.startswith("/api/potencia"):
            import ritmo
            return self._json({"potencia": ritmo.potencia()})
        if self.path.startswith("/api/fila"):
            itens, fim = fila_com_previsao()
            import rede
            pa = rede.pausa_ate()
            return self._json({"fila": itens, "etapas": ETAPAS_DUB, "pausada": bool(ESTADO_FILA.get("pausada")),
                               "youtube_pausa": time.strftime("%H:%M", time.localtime(pa)) if pa > time.time() else None,
                               "termina_em": time.strftime("%H:%M", time.localtime(fim)) if fim else None})
        if self.path.startswith("/api/pronuncia"):
            return self._json({"itens": ler_pronuncia()})
        if self.path.startswith("/api/espaco"):
            import importlib
            importlib.reload(espaco)                 # pega ajustes sem reiniciar o app
            return self._json(espaco.resumo(ocupados()))
        if self.path.startswith("/api/vozes"):
            semear_vozes()
            if not any(VOZES.glob("*/voz.json")):
                try:
                    narrar.garantir_vozes_padrao(VOZES)
                except Exception:
                    traceback.print_exc()
            try:
                narrar.atualizar_vozes_padrao(VOZES)
                refazer_demos_padrao()
            except Exception:
                traceback.print_exc()
            return self._json({"vozes": vozes_publicas()})
        if self.path.startswith("/vozes/"):
            caminho = (VOZES / unquote(self.path[len("/vozes/"):].split("?")[0])).resolve()
            if VOZES.resolve() not in caminho.parents or not caminho.is_file():
                return self._json({"erro": "Arquivo não encontrado"}, 404)
            self.send_response(200)
            self.send_header("Content-Type", "audio/wav")
            self.send_header("Content-Length", str(caminho.stat().st_size))
            self.end_headers()
            with open(caminho, "rb") as f:
                shutil.copyfileobj(f, self.wfile)
            return
        if self.path.startswith("/api/trabalho/"):
            tid = self.path.rsplit("/", 1)[1]
            return self._json(TRABALHOS.get(tid, {"estado": "erro", "etapa": "Trabalho não encontrado"}))
        if self.path.startswith("/api/dublagem/falas"):
            from urllib.parse import parse_qs, urlparse
            iid = re.sub(r"[^0-9a-z-]", "", (parse_qs(urlparse(self.path).query).get("id") or [""])[0])
            arq = PROJETOS / f"dublagem-{iid}" / "falas.json"
            if not iid or not arq.exists():
                return self._json({"erro": "Falas não encontradas."}, 404)
            fl = json.loads(arq.read_text(encoding="utf-8"))["falas"]
            return self._json({"falas": [{"i": i, "ini": round(f["ini"], 2), "fim": round(f["fim"], 2), "texto": f["texto"],
                                          "pt": f.get("pt", ""), "cortou": bool(f.get("cortou"))} for i, f in enumerate(fl)]})
        if self.path.startswith("/dublados/"):
            caminho = (DUBLADOS / unquote(self.path[len("/dublados/"):].split("?")[0])).resolve()
            if DUBLADOS.resolve() not in caminho.parents or not caminho.is_file():
                return self._json({"erro": "Arquivo não encontrado"}, 404)
            return self._enviar_arquivo(caminho)
        if self.path.startswith("/baixado/"):          # arquivo de um item da fila, em qualquer pasta que você escolheu
            iid = self.path.split("/")[2] if self.path.count("/") >= 2 else ""
            it = next((x for x in FILA if x.get("id") == iid and x.get("resultado")), None)
            caminho = Path(it["resultado"].get("salvo_em") or "") if it else None
            if not caminho or not caminho.is_file():
                return self._json({"erro": "Arquivo não encontrado"}, 404)
            return self._enviar_arquivo(caminho)
        if self.path.startswith("/api/pasta"):
            return self._json({"pasta": str(pasta_baixados()), "padrao": pasta_baixados() == BAIXADOS})
        if self.path.startswith("/baixados/"):
            caminho = (BAIXADOS / unquote(self.path[len("/baixados/"):].split("?")[0])).resolve()
            if BAIXADOS.resolve() not in caminho.parents or not caminho.is_file():
                return self._json({"erro": "Arquivo não encontrado"}, 404)
            return self._enviar_arquivo(caminho)
        if self.path.startswith("/arquivos/"):
            caminho = (PROJETOS / unquote(self.path[len("/arquivos/"):].split("?")[0])).resolve()
            if PROJETOS.resolve() not in caminho.parents or not caminho.is_file():
                return self._json({"erro": "Arquivo não encontrado"}, 404)
            return self._enviar_arquivo(caminho)
        return super().do_GET()

    def _enviar_arquivo(self, caminho):
        """Com suporte a Range, que o player de vídeo exige para avançar e voltar."""
        tipos = {".wav": "audio/wav", ".mp3": "audio/mpeg", ".mp4": "video/mp4", ".m4a": "audio/mp4", ".srt": "text/plain; charset=utf-8",
                 ".vtt": "text/vtt; charset=utf-8"}
        tamanho = caminho.stat().st_size
        ini, fim = 0, tamanho - 1
        m = re.match(r"bytes=(\d*)-(\d*)", self.headers.get("Range", ""))
        if m and (m.group(1) or m.group(2)):
            if m.group(1):
                ini = int(m.group(1))
                fim = min(fim, int(m.group(2))) if m.group(2) else fim
            else:
                ini = max(0, tamanho - int(m.group(2)))
            if ini > fim:
                self.send_response(416)
                self.send_header("Content-Range", f"bytes */{tamanho}")
                self.end_headers()
                return
            self.send_response(206)
            self.send_header("Content-Range", f"bytes {ini}-{fim}/{tamanho}")
        else:
            self.send_response(200)
        self.send_header("Content-Type", tipos.get(caminho.suffix.lower(), "application/octet-stream"))
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Length", str(fim - ini + 1))
        self.end_headers()
        try:
            with open(caminho, "rb") as f:
                f.seek(ini)
                resto = fim - ini + 1
                while resto > 0:
                    bloco = f.read(min(1 << 16, resto))
                    if not bloco:
                        break
                    self.wfile.write(bloco)
                    resto -= len(bloco)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def do_POST(self):
        if not self._de_casa():
            return
        if self.path not in LIBERADAS_SEM_SERIAL and not licenciado():
            e = lic(cache=False)
            if not e.get("ok"):
                return self._json({"erro": LIC_MSG.get(e.get("motivo"), "Ative o Multi Estúdio com o seu serial (abra o app e cole o serial)."),
                                   "licenca": e}, 403)
        try:
            if self.path == "/api/licenca/ativar":
                try:
                    e = licenca.ativar(str(self._corpo_json().get("codigo", "")), extra=(FILA_ARQ,))
                except ValueError as x:
                    return self._json({"erro": str(x)}, 400)
                if e.get("ok"):
                    iniciar_trabalhador()
                return self._json(e)
            if self.path == "/api/licenca/chave":
                arq = escolher_arquivo_chave()
                if arq:
                    try:
                        licenca.instalar_chave(arq)
                    except ValueError as x:
                        return self._json({"erro": str(x)}, 400)
                return self._json(lic(cache=False))
            if self.path == "/api/licenca/gerar":
                k = licenca.chave_admin()
                if not k:
                    return self._json({"erro": "A chave de convites não está neste computador."}, 403)
                d = self._corpo_json()
                nome = str(d.get("nome", "")).strip()[:40]
                if not nome:
                    return self._json({"erro": "Digite o nome do amigo."}, 400)
                dias = d.get("dias")
                dias = int(dias) if dias not in (None, "", 0, "0") else None
                try:
                    serial = licenca.gerar(k, nome, dias, str(d.get("maquina", "")))
                except ValueError as x:
                    return self._json({"erro": str(x)}, 400)
                s = licenca.ler(serial)
                if not s:
                    return self._json({"erro": "Não consegui conferir o serial gerado."}, 500)
                v = licenca.data_txt(s["fim"])
                return self._json({"serial": serial, "validade": v, "mensagem": licenca.mensagem(nome, serial, v)})
            if self.path == "/api/vozes":
                if self.headers.get("X-Autorizo") != "sim":
                    return self._json({"erro": "Confirme que a voz é sua ou que você tem autorização para usá-la."}, 400)
                nome = unquote(self.headers.get("X-Nome", "Minha voz"))
                ext = Path(unquote(self.headers.get("X-Arquivo", "voz.wav"))).suffix.lower() or ".wav"
                n = int(self.headers.get("Content-Length", 0))
                VOZES.mkdir(exist_ok=True)
                tmp = VOZES / f"_envio_{uuid.uuid4().hex[:6]}{ext}"
                tmp.write_bytes(self.rfile.read(n))
                try:
                    voz = narrar.criar_voz_clonada(VOZES, nome, tmp)
                finally:
                    tmp.unlink(missing_ok=True)
                fazer_demo(voz["id"])
                return self._json({"voz": voz, "vozes": vozes_publicas()})
            if self.path == "/api/vozes/desenhar":
                d = self._corpo_json()
                nome = str(d.get("nome", "")).strip()[:40] or "Minha voz"
                voz = narrar.criar_voz_desenhada(VOZES, nome, str(d.get("genero", "homem")), str(d.get("idade", "adulto")),
                                                 str(d.get("timbre", "medio")), str(d.get("estilo", "locutor")))
                fazer_demo(voz["id"])
                return self._json({"voz": voz, "vozes": vozes_publicas()})
            if self.path == "/api/vozes/apagar":
                vid = re.sub(r"[^a-z0-9-]", "", str(self._corpo_json().get("id", "")))
                pasta = VOZES / vid
                info = pasta / "voz.json"
                if vid and info.exists() and json.loads(info.read_text(encoding="utf-8")).get("tipo") in ("clonada", "criada"):
                    shutil.rmtree(pasta)
                return self._json({"vozes": vozes_publicas()})
            if self.path == "/api/narrar":
                if not modulos.tem("narracao"):
                    return self._json({"erro": "Instale o módulo \"Narração e voz natural\" na tela Módulos."}, 400)
                d = self._corpo_json()
                texto = str(d.get("texto", "")).strip()
                if len(texto) < 3:
                    return self._json({"erro": "Cole o texto da narração."}, 400)
                nid = f"{time.strftime('%Y%m%d-%H%M%S')}-{uuid.uuid4().hex[:4]}"
                n = {"id": nid, "voz": re.sub(r"[^a-z0-9-]", "", str(d.get("voz", ""))),
                     "motor": d.get("motor") if d.get("motor") in ("voxcpm2", "zonos3", "chatterbox") else "voxcpm2",
                     "ajustes": narrar.ajustes(d.get("ajustes")),
                     "estilo": d.get("estilo") if d.get("estilo") in narrar.ESTILOS else "neutro",
                     "direcao": str(d.get("direcao") or "")[:200],
                     "trechos": narrar.dividir(texto), "final": None}
                salvar_narracao(n)
                tid = uuid.uuid4().hex[:10]
                TRABALHOS[tid] = {"id": tid, "estado": "rodando", "etapa": "Carregando a voz", "progresso": 0,
                                  "narracao": narracao_publica(n)}
                threading.Thread(target=trabalho_narrar, daemon=True, args=(tid, nid, list(range(len(n["trechos"]))))).start()
                return self._json({"id": tid, "narracao": nid})
            if self.path in ("/api/modulos/instalar", "/api/modulos/remover"):
                mid = str(self._corpo_json().get("id", ""))
                try:
                    (modulos.instalar if self.path.endswith("instalar") else modulos.remover)(mid)
                except (ValueError, RuntimeError) as e:
                    return self._json({"erro": str(e)}, 400)
                return self._json(modulos.resumo())
            if self.path == "/api/potencia":
                import ritmo
                return self._json({"potencia": ritmo.definir(self._corpo_json().get("potencia", 100))})
            if self.path == "/api/dublar":
                d = self._corpo_json()
                links = re.findall(r"https?://\S+", str(d.get("links", "")) + " " + str(d.get("link", "")))
                if not links:
                    return self._json({"erro": "Cole pelo menos um link de vídeo."}, 400)
                voz = re.sub(r"[^a-z0-9-]", "", str(d.get("voz", "alex"))) or "alex"
                aj = d.get("ajustes") or {}
                try:
                    res = int(d.get("resolucao", 1080))
                except Exception:
                    res = 1080
                res = res if res in (0, 360, 480, 720, 1080, 1440, 2160) else 1080
                modo = d.get("modo") if d.get("modo") in MODOS else "dublar"
                if modo == "dublar" and not modulos.tem("dublagem"):
                    return self._json({"erro": "Para dublar, instale o módulo \"Dublar vídeos\" na tela Módulos do app."}, 400)
                qualidade = d.get("qualidade") if d.get("qualidade") in ("rapido", "equilibrado", "caprichado") else None
                if modo == "dublar" and qualidade in (None, "caprichado") and not modulos.tem("narracao"):
                    qualidade = "equilibrado"            # o Caprichado usa a voz natural, que é do módulo Narração
                o = d.get("opcoes") or {}
                opcoes = {"formato_audio": o.get("formato_audio") if o.get("formato_audio") in ("mp3", "m4a", "wav") else "mp3",
                          "legendas": bool(o.get("legendas")),
                          "legenda": o.get("legenda") if o.get("legenda") in ("embutida", "queimada", "nenhuma") else "embutida",
                          "voz_original": max(0.0, min(0.4, float(o.get("voz_original") or 0))),
                          "compactar": o.get("compactar") if o.get("compactar") in ("leve", "media", "forte") else "",
                          "motor": o.get("motor") if o.get("motor") in ("voxcpm2", "chatterbox") else "voxcpm2"}
                referer = str(d.get("referer") or "")[:500] if str(d.get("referer") or "").startswith("http") else ""
                titulo_pg = re.sub(r"[\r\n\t]+", " ", str(d.get("titulo") or "")).strip()[:150]
                if d.get("direto") and str(d.get("link", "")).startswith("http"):
                    links = [str(d["link"]).strip()]          # endereço do arquivo achado pela extensão: vai inteiro
                if d.get("perguntar_pasta") and modo in ("video", "audio") and sys.platform != "linux":
                    try:
                        escolhida = perguntar_pasta("Onde salvar este download?")
                    except Exception as e:
                        return self._json({"erro": f"Não consegui usar essa pasta: {str(e)[:120]}"}, 400)
                    if not escolhida:
                        return self._json({"cancelado": True})
                    opcoes["pasta"] = str(escolhida)
                with TRAVA_FILA:
                    for link in dict.fromkeys(links):
                        FILA.append(novo_item(link if d.get("direto") else link.rstrip(".,;)"), voz, aj, titulo=titulo_pg if len(links) == 1 else "",
                                              resolucao=res, modo=modo, opcoes=opcoes, qualidade=qualidade,
                                              referer=referer if len(links) == 1 else ""))
                salvar_fila()
                iniciar_trabalhador()
                return self._json({"fila": FILA, "adicionados": len(set(links))})
            if self.path == "/api/fila/posicao":
                d = self._corpo_json()
                for x in FILA:
                    if x["id"] == str(d.get("id", "")):
                        x["posicao"] = round(float(d.get("t", 0) or 0), 1)
                        salvar_fila()
                return self._json({"ok": True})
            if self.path == "/api/fila/cancelar":
                iid = str(self._corpo_json().get("id", ""))
                for x in FILA:
                    if x["id"] == iid and x["estado"] == "rodando":
                        CANCELAR.add(iid)
                        x["etapa"] = "Cancelando…"
                return self._json({"fila": FILA})
            if self.path == "/api/fila/remover":
                iid = str(self._corpo_json().get("id", ""))
                with TRAVA_FILA:
                    apagar_extras([x["id"] for x in FILA if x["id"] == iid and x["estado"] != "rodando"])
                    FILA[:] = [x for x in FILA if not (x["id"] == iid and x["estado"] != "rodando")]
                salvar_fila()
                return self._json({"fila": FILA})
            if self.path == "/api/fila/limpar":
                with TRAVA_FILA:
                    apagar_extras([x["id"] for x in FILA if x["estado"] not in ("esperando", "rodando")])
                    FILA[:] = [x for x in FILA if x["estado"] in ("esperando", "rodando")]
                salvar_fila()
                return self._json({"fila": FILA})
            if self.path == "/api/fila/tentar":
                iid = str(self._corpo_json().get("id", ""))
                with TRAVA_FILA:
                    for x in FILA:
                        if x["id"] == iid and x["estado"] == "erro":
                            x.update({"estado": "esperando", "etapa": "Na fila", "progresso": 0, "etapa_n": 0})
                salvar_fila()
                iniciar_trabalhador()
                return self._json({"fila": FILA})
            if self.path == "/api/youtube/liberar":
                import rede
                rede.liberar()                    # se o YouTube recusar de novo, a pausa volta sozinha (10 min)
                with TRAVA_FILA:
                    for x in FILA:
                        if x.get("tentar_apos"):
                            x.pop("tentar_apos", None)
                            if x["estado"] == "esperando":
                                x["etapa"] = "Na fila"
                salvar_fila()
                iniciar_trabalhador()
                return self._json({"ok": True})
            if self.path == "/api/pasta/escolher":
                try:
                    p = escolher_pasta()
                except Exception as e:
                    return self._json({"erro": f"Não consegui usar essa pasta: {str(e)[:120]}"}, 400)
                return self._json({"pasta": str(pasta_baixados()), "padrao": pasta_baixados() == BAIXADOS, "mudou": bool(p)})
            if self.path == "/api/pasta/abrir":
                pasta_baixados().mkdir(parents=True, exist_ok=True)
                abrir_no_sistema(pasta_baixados())
                return self._json({"ok": True})
            if self.path == "/api/pasta/padrao":
                PASTA_ARQ.unlink(missing_ok=True)
                return self._json({"pasta": str(BAIXADOS), "padrao": True})
            if self.path == "/api/fila/pausar":
                ESTADO_FILA["pausada"] = bool(self._corpo_json().get("pausada"))
                salvar_estado_fila()
                if not ESTADO_FILA["pausada"]:
                    iniciar_trabalhador()
                return self._json({"fila": FILA, "pausada": ESTADO_FILA["pausada"]})
            if self.path == "/api/fila/revisar":
                d = self._corpo_json()
                iid = str(d.get("id", ""))
                with TRAVA_FILA:
                    for x in FILA:
                        if x["id"] == iid and x["estado"] == "pronto" and modo_de(x) == "dublar":
                            x.update({"estado": "esperando", "etapa": "Revisão na fila", "progresso": 0, "etapa_n": 0,
                                      "revisar": {"pedido": str(d.get("pedido", ""))[:500]}})
                salvar_fila()
                iniciar_trabalhador()
                return self._json({"fila": FILA})
            if self.path == "/api/aovivo/ligar":
                return self._json(ligar_aovivo())
            if self.path.startswith("/api/espaco/"):
                d = self._corpo_json()
                acao = self.path.rsplit("/", 1)[-1]
                livre = 0
                if acao == "limpar":
                    livre = espaco.limpar_projetos(ocupados=ocupados(), agora=True)
                elif acao == "sobras":
                    livre = espaco.apagar_sobras()
                elif acao == "remover":
                    livre = espaco.remover_modulo(str(d.get("id", "")))
                elif acao == "dias":
                    espaco.salvar_dias(max(0, min(365, int(d.get("dias", 7)))))
                    _LIMPEZA["t"] = 0
                return self._json({**espaco.resumo(ocupados()), "livre_gb": espaco.gb(livre)})
            if self.path == "/api/dublagem/editar":
                d = self._corpo_json()
                iid = str(d.get("id", ""))
                if espaco.foi_limpo(PROJETOS / f"dublagem-{re.sub(r'[^0-9a-z-]', '', iid)}"):
                    return self._json({"erro": "Os arquivos de trabalho deste vídeo já foram apagados para liberar espaço. "
                                               "Para editar, coloque o vídeo para dublar de novo."}, 400)
                mud = {str(int(k)): str(v)[:600] for k, v in (d.get("mudancas") or {}).items() if str(k).isdigit()}
                if not mud:
                    return self._json({"erro": "Nenhuma fala mudou."}, 400)
                with TRAVA_FILA:
                    for x in FILA:
                        if x["id"] == iid and x["estado"] == "pronto" and modo_de(x) == "dublar":
                            x.update({"estado": "esperando", "etapa": "Refazendo falas editadas", "progresso": 0,
                                      "etapa_n": 0, "revisar": {"mudancas": mud}})
                salvar_fila()
                iniciar_trabalhador()
                return self._json({"fila": FILA})
            if self.path == "/api/dublagem/remixar":
                iid = str(self._corpo_json().get("id", ""))
                if iid != "todos" and espaco.foi_limpo(PROJETOS / f"dublagem-{re.sub(r'[^0-9a-z-]', '', iid)}"):
                    return self._json({"erro": "Os arquivos de trabalho deste vídeo já foram apagados para liberar espaço."}, 400)
                with TRAVA_FILA:
                    for x in FILA:
                        if (x["id"] == iid or iid == "todos") and x["estado"] == "pronto" and modo_de(x) == "dublar" \
                                and (PROJETOS / f"dublagem-{x['id']}" / "vozes").exists():
                            x.update({"estado": "esperando", "etapa": "Refazendo a mixagem", "progresso": 0,
                                      "etapa_n": 0, "revisar": {"remix": True}})
                salvar_fila()
                iniciar_trabalhador()
                return self._json({"fila": FILA})
            if self.path == "/api/dublagem/pacote":
                import dublar
                iid = re.sub(r"[^0-9a-z-]", "", str(self._corpo_json().get("id", "")))
                it = next((x for x in FILA if x["id"] == iid and x.get("resultado")), None)
                if not it:
                    return self._json({"erro": "Vídeo não encontrado."}, 404)
                if espaco.foi_limpo(PROJETOS / f"dublagem-{iid}"):
                    return self._json({"erro": "Os arquivos de trabalho deste vídeo já foram apagados para liberar espaço."}, 400)
                nome = Path(it["resultado"].get("salvo_em", "video")).stem.replace(" (dublado)", "")
                dest = dublar.pacote_premiere(PROJETOS / f"dublagem-{iid}", DUBLADOS / f"{nome} (Premiere)")
                abrir_no_sistema(dest)
                return self._json({"pasta": str(dest)})
            if self.path == "/api/abrir_link":
                url = str(self._corpo_json().get("url", ""))
                if re.match(r"^https?://[^\s]+$", url) and sys.platform == "darwin":
                    subprocess.Popen(["open", url])          # abre no navegador padrão (o seu Chrome)
                return self._json({"ok": True})
            if self.path == "/api/mostrar":
                caminho = Path(str(self._corpo_json().get("caminho", ""))).resolve()
                da_fila = any(str(caminho) == str(Path((x.get("resultado") or {}).get("salvo_em") or "/x").resolve()) for x in FILA)
                if (BASE.resolve() in caminho.parents or da_fila) and caminho.exists():
                    abrir_no_sistema(caminho, mostrar=True)
                return self._json({"ok": True})
            if self.path == "/api/pronuncia":
                itens = [{"de": str(x.get("de", "")).strip()[:60], "para": str(x.get("para", "")).strip()[:80]}
                         for x in (self._corpo_json().get("itens") or [])][:300]
                itens = [x for x in itens if x["de"] and x["para"]]
                PRONUNCIA_ARQ.write_text(json.dumps(itens, ensure_ascii=False, indent=1), encoding="utf-8")
                return self._json({"itens": itens})
            if self.path == "/api/narrar/voltar":
                d = self._corpo_json()
                nid = re.sub(r"[^a-z0-9-]", "", str(d.get("narracao", "")))
                n = ler_narracao(nid)
                i = int(d.get("indice", -1))
                if not 0 <= i < len(n["trechos"]):
                    return self._json({"erro": "Trecho inválido"}, 400)
                narrar.voltar_trecho(n["trechos"][i])
                n["final"] = narrar.montar(PROJETOS / f"narracao-{nid}", n["trechos"], narrar.ajustes(n.get("ajustes")))
                salvar_narracao(n)
                return self._json({"narracao": narracao_publica(n)})
            if self.path == "/api/narrar/remontar":
                d = self._corpo_json()
                nid = re.sub(r"[^a-z0-9-]", "", str(d.get("narracao", "")))
                n = ler_narracao(nid)
                novo = narrar.ajustes({**(n.get("ajustes") or {}), **{k: v for k, v in (d.get("ajustes") or {}).items()
                                                                       if k in ("clareza", "pausa_frase", "pausa_paragrafo", "volume")}})
                n["ajustes"] = novo
                n["final"] = narrar.montar(PROJETOS / f"narracao-{nid}", n["trechos"], novo)
                salvar_narracao(n)
                return self._json({"narracao": narracao_publica(n)})
            if self.path == "/api/narrar/trecho":
                d = self._corpo_json()
                nid = re.sub(r"[^a-z0-9-]", "", str(d.get("narracao", "")))
                n = ler_narracao(nid)
                i = int(d.get("indice", -1))
                if not 0 <= i < len(n["trechos"]):
                    return self._json({"erro": "Trecho inválido"}, 400)
                if str(d.get("texto", "")).strip():
                    n["trechos"][i]["texto"] = str(d["texto"]).strip()[:600]
                if d.get("estilo") in narrar.ESTILOS:            # refazer com o estilo que está na tela agora
                    n["estilo"] = d["estilo"]
                    n["direcao"] = str(d.get("direcao") or "")[:200]
                if d.get("motor") in ("voxcpm2", "zonos3"):
                    n["motor"] = d["motor"]
                salvar_narracao(n)
                tid = uuid.uuid4().hex[:10]
                TRABALHOS[tid] = {"id": tid, "estado": "rodando", "etapa": "Refazendo o trecho", "progresso": 0,
                                  "narracao": narracao_publica(n)}
                threading.Thread(target=trabalho_narrar, daemon=True, args=(tid, nid, [i])).start()
                return self._json({"id": tid, "narracao": nid})
            return self._json({"erro": "Rota desconhecida"}, 404)
        except Exception as e:
            traceback.print_exc()
            return self._json({"erro": str(e)}, 500)


def main():
    porta = int(sys.argv[1]) if len(sys.argv) > 1 else 8790
    PROJETOS.mkdir(exist_ok=True)
    carregar_fila()
    servidor = ThreadingHTTPServer(("127.0.0.1", porta), Manipulador)
    print(f"Multi Estúdio em http://127.0.0.1:{porta}")
    servidor.serve_forever()


if __name__ == "__main__":
    main()
