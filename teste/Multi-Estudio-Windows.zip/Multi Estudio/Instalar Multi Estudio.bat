@echo off
rem Multi Estudio: clique duas vezes para instalar (na primeira vez) e abrir.
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0programa\iniciar.ps1"
if errorlevel 1 pause
