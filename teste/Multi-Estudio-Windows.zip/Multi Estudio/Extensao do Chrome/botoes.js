// Botões "Dublar" e "Baixar" embaixo do vídeo do YouTube: um clique e o vídeo entra na fila do app Multi Estúdio.
(() => {
  const VOZES_PADRAO = [{ id: 'alex', nome: 'Thiago' }, { id: 'dora', nome: 'Leonor' }];
  let vozes = null;
  let aberto = null;

  function mandar(m) {
    return new Promise(res => {
      try { chrome.runtime.sendMessage(m, r => res(r || { ok: false, erro: 'Abra o app Multi Estúdio no computador.' })); }
      catch (e) { res({ ok: false, erro: 'Recarregue a página (a extensão foi atualizada).' }); }
    });
  }
  function guardado() { return new Promise(res => chrome.storage.local.get({ envio: {} }, d => res(d.envio || {}))); }
  async function listaVozes() {
    if (vozes) return vozes;
    const r = await mandar({ tipo: 'api', url: 'http://127.0.0.1:8790/api/vozes' });
    vozes = (r.ok && r.dados && r.dados.vozes && r.dados.vozes.length) ? r.dados.vozes : null;
    return vozes || VOZES_PADRAO;
  }
  function temPlaylist() { return new URL(location.href).searchParams.has('list'); }

  function el(tag, cls, txt) { const e = document.createElement(tag); if (cls) e.className = cls; if (txt) e.textContent = txt; return e; }
  function icone() {
    const i = el('span', 'ti-ico');
    i.innerHTML = '<svg viewBox="0 0 24 24" width="16" height="16"><rect width="24" height="24" rx="6" fill="#F5A524"/>' +
                  '<path d="M5 16l4.5-6 3.5 4 2.5-3L19 16" fill="none" stroke="#111" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    return i;
  }

  function fecharMenu() { if (aberto) { aberto.remove(); aberto = null; } }
  document.addEventListener('click', ev => { if (aberto && !ev.target.closest('.ti-menu, .ti-barra')) fecharMenu(); }, true);

  function aviso(botao, r) {
    const txt = botao.querySelector('.ti-txt');
    const antes = txt.dataset.rotulo;
    botao.classList.remove('ti-ok', 'ti-erro');
    if (r.ok) {
      botao.classList.add('ti-ok');
      txt.textContent = r.playlist ? 'Playlist na fila ✓' : 'Na fila ✓';
    } else if (r.cancelado) {
      txt.textContent = 'Cancelado';
    } else {
      botao.classList.add('ti-erro');
      txt.textContent = r.erro || 'Não deu certo';
    }
    clearTimeout(botao._t);
    botao._t = setTimeout(() => { botao.classList.remove('ti-ok', 'ti-erro'); txt.textContent = antes; }, r.ok ? 4000 : 6000);
  }

  async function abrirMenu(botao, acao) {
    if (aberto && aberto.dataset.acao === acao) { fecharMenu(); return; }
    fecharMenu();
    const menu = el('div', 'ti-menu');
    menu.dataset.acao = acao;
    const g = await guardado();
    let playlist = false;

    if (temPlaylist()) {
      const lin = el('label', 'ti-linha ti-check');
      const cb = el('input');
      cb.type = 'checkbox';
      cb.onchange = () => { playlist = cb.checked; };
      lin.append(cb, el('span', null, 'A playlist inteira'));
      menu.append(lin);
    }

    async function ir(acaoFinal, ajustes) {
      fecharMenu();
      const txt = botao.querySelector('.ti-txt');
      txt.textContent = (acaoFinal !== 'dublar' && g.perguntarPasta !== false) ? 'Escolha a pasta na janelinha…' : 'Mandando…';
      const r = await mandar({ tipo: 'enviar', url: location.href, acao: acaoFinal, playlist, ajustes });
      aviso(botao, r, acaoFinal);
    }

    if (acao === 'dublar') {
      const lin = el('label', 'ti-linha');
      lin.append(el('span', 'ti-rot', 'Voz'));
      const sel = el('select', 'ti-sel');
      (await listaVozes()).forEach(v => {
        const o = el('option', null, v.nome + (v.estilo ? ' · ' + v.estilo : ''));
        o.value = v.id;
        sel.append(o);
      });
      sel.value = g.voz || 'alex';
      if (!sel.value) sel.selectedIndex = 0;
      lin.append(sel);
      menu.append(lin);
      [['rapido', 'Rápido', 'voz rápida, pronto logo'], ['equilibrado', 'Equilibrado', 'tradução mais caprichada'],
       ['caprichado', 'Caprichado', 'voz mais natural, demora mais']].forEach(([q, nome, dica]) => {
        const b = el('button', 'ti-opcao' + ((g.qualidade || 'equilibrado') === q ? ' ti-atual' : ''));
        b.append(el('b', null, nome), el('small', null, dica));
        b.onclick = () => ir('dublar', { qualidade: q, voz: sel.value });
        menu.append(b);
      });
    } else {
      const lin = el('label', 'ti-linha ti-check');
      const cb = el('input');
      cb.type = 'checkbox';
      cb.checked = g.perguntarPasta !== false;
      cb.onchange = () => { g.perguntarPasta = cb.checked; chrome.storage.local.set({ envio: { ...g, perguntarPasta: cb.checked } }); };
      lin.append(cb, el('span', null, 'Escolher a pasta na hora'));
      menu.append(lin);
      [['video', 1080, 'Vídeo em 1080p'], ['video', 720, 'Vídeo em 720p (menor)'], ['video', 0, 'Vídeo na melhor qualidade'],
       ['audio', null, 'Só o áudio (mp3)']].forEach(([a, res, nome]) => {
        const b = el('button', 'ti-opcao');
        b.append(el('b', null, nome));
        b.onclick = () => ir(a, res === null ? {} : { resolucao: res });
        menu.append(b);
      });
    }
    document.body.append(menu);
    const r = botao.getBoundingClientRect();
    menu.style.top = (window.scrollY + r.bottom + 6) + 'px';
    menu.style.left = Math.max(8, Math.min(window.scrollX + r.left, window.scrollX + document.documentElement.clientWidth - menu.offsetWidth - 8)) + 'px';
    aberto = menu;
  }

  function botao(acao, rotulo) {
    const b = el('button', 'ti-botao');
    b.append(icone());
    const t = el('span', 'ti-txt', rotulo);
    t.dataset.rotulo = rotulo;
    b.append(t);
    b.onclick = ev => { ev.preventDefault(); ev.stopPropagation(); abrirMenu(b, acao); };
    return b;
  }

  // "Ao vivo": liga e desliga a dublagem em tempo real aqui mesmo (a mesma chave do ícone da extensão)
  function botaoAoVivo() {
    const b = el('button', 'ti-botao ti-aovivo');
    b.title = 'Dublagem em tempo real enquanto você assiste';
    b.append(el('span', 'ti-ponto-vivo'));
    const t = el('span', 'ti-txt', 'Ao vivo');
    t.dataset.rotulo = 'Ao vivo';
    b.append(t);
    const pintar = ligado => b.classList.toggle('ti-ligado', !!ligado);
    chrome.storage.local.get({ ligado: false }, c => pintar(c.ligado));
    b.onclick = ev => {
      ev.preventDefault(); ev.stopPropagation(); fecharMenu();
      chrome.storage.local.get({ ligado: false }, c => chrome.storage.local.set({ ligado: !c.ligado }));
    };
    chrome.storage.onChanged.addListener(m => { if (m.ligado) pintar(m.ligado.newValue); });
    return b;
  }

  function montar() {
    if (!location.pathname.startsWith('/watch')) { document.querySelectorAll('.ti-barra').forEach(x => x.remove()); return; }
    if (document.querySelector('.ti-barra')) return;
    const alvo = document.querySelector('ytd-watch-metadata #actions') || document.querySelector('#above-the-fold #top-row');
    if (!alvo) return;
    const barra = el('div', 'ti-barra');
    barra.append(botaoAoVivo(), botao('dublar', 'Dublar e salvar'), botao('baixar', 'Baixar'));
    alvo.prepend(barra);
    temDublagem().then(sim => { if (!sim) barra.querySelectorAll('.ti-aovivo, .ti-botao:nth-child(2)').forEach(b => b.remove()); });
  }

  // computador sem o módulo de dublagem (ex.: Windows): fica só o botão Baixar
  let dublagem = null;
  function temDublagem() {
    if (dublagem) return dublagem;
    dublagem = new Promise(res => {
      try {
        chrome.runtime.sendMessage({ tipo: 'api', url: 'http://127.0.0.1:8790/api/status' }, r => {
          const mods = r && r.ok && r.dados && r.dados.modulos;
          if (!Array.isArray(mods)) { dublagem = null; res(true); return; }      // app fechado: mostra tudo, pergunta de novo depois
          res(mods.includes('dublagem'));
        });
      } catch (e) { dublagem = null; res(true); }
    });
    return dublagem;
  }

  let agendado = false;
  new MutationObserver(() => {
    if (agendado) return;
    agendado = true;
    setTimeout(() => { agendado = false; montar(); }, 400);
  }).observe(document.documentElement, { childList: true, subtree: true });
  window.addEventListener('yt-navigate-finish', () => { fecharMenu(); setTimeout(montar, 300); });
  chrome.runtime.onMessage.addListener(m => {
    if (m && m.tipo === 'enviado') {
      const b = document.querySelector('.ti-barra .ti-botao');
      if (b) aviso(b, m, m.acao);
    }
  });
  montar();
})();
